
# hash value = 153469889
hello.hello_world='Hello, world!'


# hash value = 1323310
hello.running_as='This program is running as process number %d.'

