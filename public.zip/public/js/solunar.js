moment.tz.add([
    'America/Los_Angeles|PST PDT|80 70|0101|1Lzm0 1zb0 Op0',
    'America/New_York|EST EDT|50 40|0101|1Lz50 1zb0 Op0'
]);

var moondata = [];
var moonPoints = [];
var moonImg = [0,1,4,6,10,13,17,22,25,32,34,43,50,52,62,66,69,71,79,86,87,92,97,98,99,100];

var selectedDate = moment().format("YYYY-MM-DD");
var url = window.location.href;
var region_id = url.substring(url.lastIndexOf('/') + 1);
var monthNames = [
    "Jan", "Feb", "Mar",
    "Apr", "May", "Jun", "Jul",
    "Aug", "Sep", "Oct",
    "Nov", "Dec"
];
//Setting todays date
var now = new Date();
var day = ("0" + now.getDate()).slice(-2);
var month = ("0" + (now.getMonth() + 1)).slice(-2);
var today = now.getFullYear()+"-"+(month)+"-"+(day) ;
$("#cal").val(today);
updateGraph(today);

$("#cal").on('change',function () {

    selectedDate = $(this).val();
    labelDate = getLabelDate();
    updateGraph(selectedDate);
});

function closest (num, arr) {

    var curr = arr[0];
    var diff = Math.abs (num - curr);
    for (var val = 0; val < arr.length; val++) {
        var newdiff = Math.abs (num - arr[val]);
        if (newdiff <= diff) {
            diff = newdiff;
            curr = arr[val];
        }
    }
    return curr;
}


var labelDate = getLabelDate();
function getLabelDate(){
    var date = "";
    if($("#cal").val().length){
        date = new Date($("#cal").val());
    }else{
        date = new Date();
    }
    return monthNames[date.getMonth()] +" " + date.getDate()+", ";
}

function getLabelNextDay(){
    var date = "";
    if($("#cal").val().length){
        date = new Date($("#cal").val());
    }else{
        date = new Date();
    }
    return monthNames[date.getMonth()] +" " + (date.getDate()+1)+", ";
}

function meterToFt(meters) {
    return (meters/0.3048);
}

function updateGraph(selectedDate){


    if(!moment(selectedDate).isValid()){
        return false;
    }
    var date = new Date(selectedDate);
    // var finalDate = date.getDate() +"-"+ monthNames[date.getMonth()] +"-"+ date.getFullYear();
    var finalDate = moment(selectedDate).format('DD-MM-YYYY');
    $.ajax({
        url: "/getGraphData",
        type: "GET", //send it through get method
        data: {
            date: finalDate,
            region_id: region_id,
        },
        error: function(){
            alert('No data found against this date');
        },
        success: function(response) {

            var src = $("#moonImg").attr("src"); // get the src
            var currentImg =  closest(response.percentfull,moonImg)+".jpg";
            // var path = src.substring(0,src.lastIndexOf('/'));
            // $("#moonImg").attr("src",path +"/"+ currentImg);
            // $(".fc_moon_img span").text(parseInt(response.percentfull) + "% Full");

            config.options.scales.xAxes[0].time.min = setTime("00:00:00");
            config.options.scales.xAxes[0].time.max = setTime("24:00:00");
            window.myLine.update();

            tidesAnnotations.annotations[0].xMin = setTime("00:00:00");
            tidesAnnotations.annotations[0].xMax = setTime(response.sunrise);
            tidesAnnotations.annotations[1].xMin = setTime(response.sunrise);
            tidesAnnotations.annotations[1].xMax = setTime(response.sunset);
            tidesAnnotations.annotations[2].xMin = setTime(response.sunset);
            tidesAnnotations.annotations[2].xMax = setTime("24:00");

            //Setting labels for tides
            // tidesAnnotations.annotations[3].value = setTime(response.moonrise);
            // tidesAnnotations.annotations[4].value = setTime(response.moonoverhead);
            // tidesAnnotations.annotations[5].value = setTime(response.moonunderfoot);
            // tidesAnnotations.annotations[6].value = setTime(response.moonset);


            fishingAnnotations.annotations[0].xMax = setTime(response.sunrise);
            fishingAnnotations.annotations[0].xMin = setTime("00:00:00");
            fishingAnnotations.annotations[1].xMin = setTime(response.sunrise);
            fishingAnnotations.annotations[1].xMax = setTime(response.sunset);
            fishingAnnotations.annotations[2].xMin = setTime(response.sunset);
            fishingAnnotations.annotations[2].xMax = setTime("24:00");


            function compare(a,b) {
                if (a.x <= b.x)
                    return -1;
                if (a.x >=  b.x)
                    return 1;
                // return 0;
            }


            moondata.forEach(function(data,i){
                config.data.datasets[0].data[i] = data;
            });

            //updating second dataset of moon chart
            config.data.datasets[1].data = [];
            var totalTidesData = response.tidesData.length;
            if(totalTidesData > 0){
                var heightUnit = response.regionOptions.height_unit;
                for(var i=0;i<=totalTidesData;i++){
                    var value = "";
                    // in case of cicese server we are getting 23 hours point
                    if(typeof response.tidesData[i] == 'undefined') {
                        //if unit is in meters then convert to fts
                        if(heightUnit == 0){
                            value = meterToFt(response.tidesData[i-1].v);
                        }else{
                            value = response.tidesData[i-1].v;
                        }
                        config.data.datasets[1].data.push({x: setTime("24:00"),y:0.5});
                    }else{
                        //if unit is in meters then convert to fts
                        if(heightUnit == 0){
                            value = meterToFt(response.tidesData[i].v);
                        }else{
                            value = response.tidesData[i].v;
                        }
                        var xVal = response.tidesData[i].t.split(" "); // fetching time only
                        config.data.datasets[1].data.push({x: setTime(xVal[1]),y:value});
                    }
                }
            }

            var moonData =  [];
            for(var time in response.moonpoints){
                moonData.push({x:setTime(time+":00"),y:(response.moonpoints[time]*2)+7});
            }

            var moonDataSize = moonData.length;
            if(setTime(response.moonoverhead).minutes() != 0 || setTime(response.moonoverhead).hours() != 0){
                moonData.push({x:setTime(response.moonoverhead),y:6,name:'moonoverhead'});
            }else if(response.moonoverhead == "0:00"){
                moonData[0]['name'] = "moonoverhead";
            }else if(response.moonoverhead == "24:00"){
                moonData[moonDataSize]['name'] = "moonoverhead";
            }

            if(setTime(response.moonset).minutes() != 0 || setTime(response.moonset).hours() != 0){
                moonData.push({x:setTime(response.moonset),y:5,name:'moonset'});
            }else if(response.moonset == "0:00"){
                moonData[0]['name'] = "moonset";
            }else if(response.moonset == "24:00"){
                moonData[moonDataSize]['name'] = "moonset";
            }

            if(setTime(response.moonrise).minutes() != 0 || setTime(response.moonrise).hours() != 0){
                moonData.push({x:setTime(response.moonrise),y:5,name:'moonrise'});
            }else if(response.moonrise == "0:00"){
                moonData[0]['name'] = "moonrise";
            }else if(response.moonrise == "24:00"){
                    console.log(moonData,moonDataSize);

                moonData[moonDataSize]['name'] = "moonrise";
                console.log(moonData[moonData[moonDataSize]]);
            }

            if(setTime(response.moonunderfoot).minutes() != 0 || setTime(response.moonunderfoot).hours() != 0){
                moonData.push({x:setTime(response.moonunderfoot),y:3,name:'moonunderfoot'});
            }else if(response.moonunderfoot == '0:00'){
                moonData[0]['name'] = 'moonunderfoot';
            }else if(response.moonunderfoot == "24:00"){
                alert(moondata.length);
                moonData[moonDataSize]['name'] = "moonunderfoot";
            }

            moonData.sort(compare);
// console.log('there',moonData);return;
            moonPoints = [];
            for(var key in moonData){
                if(moonData[key].hasOwnProperty('name')){
                    var test = key;
                    var p2 = moonData[parseFloat(test)+1];
                    var p1 = moonData[parseFloat(test)-1];

                    moonPoints.push(moonData[key]);
                    // making moon points y axis
                    if(typeof p1 !== 'undefined' && typeof p2 !== 'undefined'){
                        //fetching each minute fraction
                        var oneMinFraction = (parseFloat(p2.y)-parseFloat(p1.y))/120;
                        var timeDiff = moonData[key].x.diff(p1.x,'minutes');
                        moonData[key].y = (timeDiff * oneMinFraction) + p1.y;
                    }

                    if(typeof p2 !== 'undefined' ){
                        var timeDiff2 = p2.x.diff(moonData[key].x,'minutes');
                        // alert(timeDiff2);

                        if(timeDiff2 < 23 ){
                            moonData[parseFloat(test)+1].y = moonData[parseFloat(test)].y;
                            // 15th is the last point of 24 hours as we are getting points with 2 hour difference
                            // and 4 points are moon points
                            if(key < 15){
                                moonData[parseFloat(test)+1].x = moonData[parseFloat(test)].x;
                            }
                        }

                    }
                    // ius



                    if(timeDiff < 25){
                        moonData[parseFloat(test)-1].y = moonData[parseFloat(test)].y;
                        moonData[parseFloat(test)-1].x = moonData[parseFloat(test)].x;
                        if(timeDiff == 0){
                            // delete moonData[parseFloat(test+1)];
                        }else{

                        }

                    }

                }
            }


            // moonData.forEach(function(data,index){
            //     console.log(data);
            //         // if(data[index+1].x.diff(data.x,'minutes').diff < 15){
            //         //     data[index+1] = data[index];
            //         // }
            // });
            // moonData.push({x:setTime("24:00"),y:(response.moonpoints[25]*2)+7});
            config.data.datasets[0].data = moonData;
            moonPoints.sort(compare);
            console.log(moonPoints);
            config.data.datasets[2].data = moonPoints;

            window.myLine.update();
            fishingConfig.options.scales.xAxes[0]['time'].max = setTime("24:00:00");
            fishingConfig.options.scales.xAxes[0]['time'].min = setTime("00:00:00");
            window.myBar.update();

            var majorHeight = response.percentgoodday;
            var minorHeight =  response.percentgoodday;
            var fishingTime = [setTime(response.minorfishingtime1),setTime(response.minorfishingtime2),setTime(response.majorfishingtime1),setTime(response.majorfishingtime2),
                setTime(response.minorfishingtime3),setTime(response.minorfishingtime4),setTime(response.majorfishingtime3),setTime(response.majorfishingtime4)];

            var newAnnotations = [
                {
                    type: "box",
                    xScaleID: "x-axis-0",
                    yScaleID: "y-axis-0",
                    xMin: fishingTime[0],
                    xMax: fishingTime[1],
                    yMin: 0,
                    yMax: minorHeight,
                    backgroundColor: "rgba(51, 63, 80, 1)",
                    borderColor: "rgba(51, 63, 80, 1)",
                    borderWidth: 1,
                },
                {
                    type: "box",
                    xScaleID: "x-axis-0",
                    yScaleID: "y-axis-0",
                    xMin: fishingTime[2],
                    xMax: fishingTime[3],
                    yMin: 0,
                    yMax: majorHeight,
                    backgroundColor: "rgba(51, 63, 80, 1)",
                    borderColor: "rgba(51, 63, 80, 1)",
                    borderWidth: 1,
                },
                {
                    type: "box",
                    xScaleID: "x-axis-0",
                    yScaleID: "y-axis-0",
                    xMin: fishingTime[4],
                    xMax: fishingTime[5],
                    yMin: 0,
                    yMax: minorHeight,
                    backgroundColor: "rgba(51, 63, 80, 1)",
                    borderColor: "rgba(51, 63, 80, 1)",
                    borderWidth: 1,
                },
                {
                    type: "box",
                    xScaleID: "x-axis-0",
                    yScaleID: "y-axis-0",
                    xMin: fishingTime[6],
                    xMax: fishingTime[7],
                    yMin: 0,
                    yMax: majorHeight,
                    backgroundColor: "rgba(51, 63, 80, 1)",
                    borderColor: "rgba(51, 63, 80, 1)",
                    borderWidth: 1,
                },
                // {
                //     drawTime: "afterDatasetsDraw",
                //     id: "hline",
                //     type: "line",
                //     mode: "horizontal",
                //     scaleID: "y-axis-0",
                //     value: 3,
                //
                //     borderColor: "black",
                //     borderWidth: 5,
                //     label: {
                //         backgroundColor: 'red',
                //         fontFamily: 'sans-serif',
                //         fontSize: 12,
                //         fontStyle: 'bold',
                //         fontColor: '#fff',
                //         xPadding: 12,
                //         yPadding: 6,
                //         cornerRadius: 4,
                //         position: 'center',
                //         yAdjust: 23,
                //         xAdjust: -330,
                //         enabled: true,
                //         content: 'Test Label',
                //         // xMin: fishingTime[6],
                //         // xMax: fishingTime[7],
                //         // yMin: 0,
                //         // yMax: majorHeight,
                //     },
                // }
            ];

            var fishingLineData = [
                {x:fishingTime[0],y:majorHeight},
                {x:fishingTime[1],y:majorHeight},
                {x:fishingTime[2],y:majorHeight},
                {x:fishingTime[3],y:majorHeight},
                {x:fishingTime[4],y:majorHeight},
                {x:fishingTime[5],y:majorHeight},
                {x:fishingTime[6],y:majorHeight},
                {x:fishingTime[7],y:majorHeight},
            ];

            fishingConfig.data.datasets[0].data = fishingLineData;
            fishingConfig.options.annotation.annotations.splice(3,4);
            newAnnotations.forEach(function(newAnnotation){
                fishingConfig.options.annotation.annotations.push(newAnnotation);
            });
            window.myBar.update();
        },
    });
}

function setTime(time){

    var hours = time.split(":");
    if(hours[0] < 10){
        hours[0] = "0"+hours[0];
        hours[0] =  hours[0].slice(-2);
        // alert(hours[0]);
    }
    if(hours[0] == 24){
        time = hours[0]+":00";
    }else{
        time = hours.join(":");
    }

    return moment.tz(selectedDate + " "+time,"America/Los_Angeles");

    // return selectedDate + " "+time;
}

var tidesAnnotations = {
    annotations: [
        {
            type: "box",
            xScaleID: "x-axis-0",
            yScaleID: "y-axis-0",
            xMin: setTime("00:00"),
            xMax: setTime("06:30"),
            yMin: -2,
            yMax: 10,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            borderColor: "rgba(0, 0, 0, 0.5)",
            borderWidth: 1,
        },
        {
            type: "box",
            xScaleID: "x-axis-0",
            yScaleID: "y-axis-0",
            xMin: setTime("06:30"),
            xMax: setTime("18:00"),
            yMin: -2,
            yMax: 10,
            backgroundColor: "rgba(255,255,224,0.5)",
            borderColor: "rgba(255,255,224,0.5)",
            borderWidth: 1,

        },
        {
            type: "box",
            xScaleID: "x-axis-0",
            yScaleID: "y-axis-0",
            xMin: setTime("18:00"),
            xMax: setTime("24:00"),
            yMin: -2,
            yMax: 10,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            borderColor: "rgba(0, 0, 0, 0.5)",
            borderWidth: 1,

        },
        // {
        //     type: 'line',
        //     mode: 'vertical',
        //     scaleID: 'x-axis-0',
        //     value: setTime("00:00"),
        //     borderColor: 'transparent',
        //     borderWidth: 0,
        //     borderDash: [5,5],
        //     // endValue: 6,
        //     label: {
        //         xAdjust: -20,
        //         yAdjust: -170,
        //         fontSize: 14,
        //         fontColor: 'black',
        //         backgroundColor: 'transparent',
        //         content: "+20%",
        //         enabled: true
        //     }
        // },
        // {
        //     type: 'line',
        //     mode: 'vertical',
        //     scaleID: 'x-axis-0',
        //     value: setTime("00:00"),
        //     borderColor: 'transparent',
        //     borderWidth: 0,
        //     borderDash: [5,5],
        //     // endValue: 6,
        //     label: {
        //         xAdjust: -20,
        //         yAdjust: -170,
        //         fontSize: 16,
        //         fontColor: 'black',
        //         backgroundColor: 'transparent',
        //         content: "+20%",
        //         enabled: true
        //     }
        // },
        // {
        //     type: 'line',
        //     mode: 'vertical',
        //     scaleID: 'x-axis-0',
        //     value: setTime("00:00"),
        //     borderColor: 'transparent',
        //     borderWidth: 0,
        //     borderDash: [5,5],
        //     // endValue: 6,
        //     label: {
        //         xAdjust: -20,
        //         yAdjust: -170,
        //         fontSize: 16,
        //         fontColor: 'black',
        //         backgroundColor: 'transparent',
        //         content: "+20%",
        //         enabled: true
        //     }
        // },
        // {
        //     type: 'line',
        //     mode: 'vertical',
        //     scaleID: 'x-axis-0',
        //     value: setTime("00:00"),
        //     borderColor: 'transparent',
        //     borderWidth: 0,
        //     borderDash: [5,5],
        //     // endValue: 6,
        //     label: {
        //         xAdjust: -20,
        //         yAdjust: -170,
        //         fontSize: 16,
        //         fontColor: 'black',
        //         backgroundColor: 'transparent',
        //         content: "+20%",
        //         enabled: true
        //     }
        // }

    ]
};

var fishingAnnotations = {
    annotations: [
        {
            type: "box",
            xScaleID: "x-axis-0",
            yScaleID: "y-axis-0",
            xMin: setTime("00:00"),
            xMax: setTime("06:30"),
            yMin: 0,
            yMax: 5,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            borderColor: "rgba(0, 0, 0, 0.5)",
            borderWidth: 1,
        },
        {
            type: "box",
            xScaleID: "x-axis-0",
            yScaleID: "y-axis-0",
            xMin: setTime("06:30"),
            xMax: setTime("18:00"),
            yMin: 0,
            yMax: 5,
            backgroundColor: "rgba(255,255,224,0.5)",
            borderColor: "rgba(255,255,224,0.5)",
            borderWidth: 1,

        },
        {
            type: "box",
            xScaleID: "x-axis-0",
            yScaleID: "y-axis-0",
            xMin: setTime("18:00"),
            xMax: setTime("24:00"),
            yMin: 0,
            yMax: 5,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            borderColor: "rgba(0, 0, 0, 0.5)",
            borderWidth: 1,

        },

    ]
};


var color = Chart.helpers.color;
var config = {
    type: 'line',
    responsive: true,
    data: {
        datasets: [
            {
            backgroundColor: color(window.chartColors.black).alpha(0.5).rgbString(),
            borderColor: window.chartColors.blue,
            fill: false,
            data: [],
            pointRadius: 0,
            label: "Tides",
        },{
                backgroundColor: color(window.chartColors.black).alpha(0.5).rgbString(),
                borderColor: window.chartColors.blue,
                fill: false,
                data: [],
                label: "Tides",
            },{
                label: 'Tides',
                backgroundColor: window.chartColors.red,
                borderColor: window.chartColors.red,
                data: [],
                fill: false,
                pointRadius: 5,
                pointHoverRadius: 10,
                showLine: false // no line shown
            }]
    },
    options: {
        elements: {
            point: {
                pointStyle: 'circle',
            }
        },
        responsive: true,
        title: {
            display: true,
            text: 'Tides and fishing data'
        },
        legend: {
            display: false
        },
        tooltips: {
            enabled: true,
            mode: 'single',
            callbacks: {
                label: function(tooltipItems, data) {

                    if(tooltipItems.xLabel == moonPoints[0].x){
                        return moonPoints[0].name;
                    }else if(tooltipItems.xLabel == moonPoints[1].x){
                        return moonPoints[1].name;
                    }else if(tooltipItems.xLabel == moonPoints[2].x){
                        return moonPoints[2].name;
                    }else if(tooltipItems.xLabel == moonPoints[3].x){
                        return moonPoints[3].name;
                    }
                    return "Tides";
                }
            }
        },
        scales: {
            xAxes: [{
                type: 'time',
                display: true,
                distribution: 'series',
                time: {
                    unit: 'hour',
                    // displayFormats: {
                    //     quarter: 'hA',
                    // },
                    min: setTime("00:00:00"),
                    max: setTime("24:00:00"),
                },
                ticks: {
                    major: {
                        fontStyle: 'bold',
                        fontColor: '#FF0000'
                    },
                    callback: function(value, index, values) {
                        // return value;
                        switch(value){
                            // case labelDate+"12AM":
                            //     return "0";
                            case labelDate+"6AM":
                                return '6am';
                            case labelDate+"12PM":
                                return '12am';
                            case labelDate+"6PM":
                                return '6pm';
                            case getLabelNextDay()+"12AM":
                                return '24am';
                        }
                    },
                }
            }],
            yAxes: [{
                display: true,

                ticks:{
                    callback: function(value, index, values) {
                        // return value;
                        switch(value){
                            case -2:
                                return '-2';
                            case 0:
                                return '0';
                            case 2:
                                return '2';
                            case 4:
                                return '4';
                            case 6:
                                return '6';
                            case 8:
                                return '8';
                        }
                    },
                },

            }]
        },
        annotation: tidesAnnotations,
    }
};

var fishingConfig = {
    type: 'line',
    responsive: true,

    data: {
        datasets: [{
            type: 'line',
            label: 'Fishing Data',
            backgroundColor: color(window.chartColors.black).alpha(0.5).rgbString(),
            borderColor: window.chartColors.blue,
            // borderDash: [5,5],
            // fill: false,
            showLine: false, // no line shown
            data: [],
        }]
    },
    options: {

        // title: {
        //     display: true,
        //     text: 'Chart.js Time Point Data'
        // },
        legend: {
            display: false
        },
        tooltips: {
            callbacks: {
                // label: function(tooltipItem) {
                //     return '';
                // }
            }
        },
        scales: {
            xAxes: [{
                type: 'time',
                display: true,
                distribution: 'series',

                time: {
                    unit: 'hour',
                    // displayFormats: {
                    //     quarter: 'hA',
                    // },
                    min: setTime("00:00:00"),
                    max: setTime("24:00:00"),
                },
                ticks: {
                    beginAtZero: true,

                    major: {
                        fontStyle: 'bold',
                        fontColor: '#FF0000'
                    },
                    callback: function(value, index, values) {
                        // return value;
                        switch(value){
                            // case labelDate+"12AM":
                            //     return "0";
                            case labelDate+"6AM":
                                return '6am';
                            case labelDate+"12PM":
                                return '12am';
                            case labelDate+"6PM":
                                return '6pm';
                            case getLabelNextDay()+"12AM":
                                return '24am';
                        }
                    },
                }
            }],
            yAxes: [{
                display: true,
                ticks: {
                    stepSize:1,
                    beginAtZero: true,
                    callback: function(value, index, values) {
                        // return value;
                        switch(value){
                            case 1:
                                return 'Poor';
                            case 2:
                                return 'Fair';
                            case 3:
                                return 'Good';
                            case 4:
                                return 'Better';
                            case 5:
                                return 'Best';
                        }
                    }
                },

            }]
        },
        annotation: fishingAnnotations,
    }
};



window.onload = function() {
    var ctx = document.getElementById('canvas').getContext('2d');
    var ctx2 = document.getElementById('fishing').getContext('2d');
    window.myLine = new Chart(ctx, config);
    window.myBar = new Chart(ctx2, fishingConfig);
};
