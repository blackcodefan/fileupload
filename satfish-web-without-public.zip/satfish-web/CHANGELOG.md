# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.95] - 2018-09-31
# Changed
- Wind Server is in php from Python
- Layer Control Design Improvements
- Bouy markers on map
- Design improvements
- Upload size of upto 50 mb

### Added
- Wind Layer History controls
- Slug added to Regions CSV import
- Added new sst_3dc from old server
- KML File reading for bathy & conture layers
- geoJson reading on map


### Fixes
- Login Fixes
- Security Fix: Admin Login for selected users
- History Layer Loading
- Grid rendering improved
- Time-zone conversion
- printing related fixes


## [0.91] - 2018-07-11
# Changed
- History layer loading improved
- Layers image view in backend justified
- All JS & CSS is local now
- Removed Bootstrap from front end
- Tooltips on front-end improved with js
- webfonts moved to root public directory
### Added
- Moved assets to mix & babel parsing added
- Laravel collective added to hotbites
- Added new s3sf drive
- Google analytics integrated
- Forced default timezone as per laravel's config
- Layer caching for mobile apps
- Login created with Laravel auth by replicating user
- get regions added to ajax
- Styling improvements
- Zoom based labels visibillity
- Hotbites table front-end
- Edge buffer for extra tile load
- Labels zoom range option introduced to csv
- Buoys stations command added
- Buoys data command added
- Buoys added to cron
- Location service for web
### Fixes
- Player Bug fixes
- Logout redirect fix
- Stripe class call fixed
- Label's zoom based issue fixed
- Range & Bearings fix
- Colors fixed for front end buttons & sidebar
- Routing z-index fixed
- Stabillity improvement

## [0.86] - 2018-06-12
## Changed
- Validators removed from Region form
### Added
- Enabled Status filter for front end
- Enabled S3 integration
- Added new s3sf drive
### Fixes
- Stripe autoload fix 
- Design/Css fixes
- Logout fix
- User login synced users with amember and laravel
- User forget password synced with amember and laravel

## [0.85] - 2018-06-10
## Changed
- Admin top bar color
- Size of admin Logo
- Admin layer image preview URL fixed
- Layer Player new version added
- Date format changed a bit
- Logout button fixed 
- Add local production check on AmemberAuth middleware 
### Added
- Dynamic Map canvas size
- Labels on icon collapsed
- Highlight to currently selected player item
- Mobile devices crosshairs icon
- Mobile device tap for temp reading & coordinates update
- Canvas resizing with orientation change & browser resizing
- User redirect to actual page after login on frontend
### Fixes
- Layer Player fixed completely
- Sprite fix for hotbite icon
- Double tap was leading to iOS zoom

## [0.82] - 2018-06-08
### Changed
- changed urls from http to https
- fixed admin panel
- user subscriptions check added 
- layer request message updated 
- Reset button check added on create page in admin panel
- admin panel general design fixes 

## [0.81] - 2018-06-07
### Added
- amember login added 
- amember url redirects implemented 
- Hotbite crud added on frontend 
### Changed
- login layouts changed
- login design implemneted 
- regions request fixed

## [0.8] - 2018-06-07
### Added
- Vue based Admin Panel
- App's front end for map tiles
- Nodejs wind server
- Pythong Tiling scripts


[Unreleased]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/branch/develop
[0.8]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.8
[0.81]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.81
[0.82]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.82
[0.83]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.83
[0.84]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.84
[0.85]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.85
[0.86]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.86
[0.91]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.91
[0.95]: https://deploy.karigar.pk/deployer/satfish-web/repository/content/tag/0.95
