<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class AmemberData extends Model
{
    protected $table = 'amember_data';
    protected $fillable = ['cc_expires','cc_masked','stripe_token','rebill_date','rebill_amount','binded'];

    public function user()
    {
        return $this->belongsTo('Satfish\User');
    }
}
