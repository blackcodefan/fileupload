<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;
use Satfish\Traits\BoundsFilter;
use Satfish\Traits\VueTableSearch;

class Buoy extends Model
{
	use VueTableSearch, BoundsFilter;

	protected $fillable = ['sid', 'name', 'lat', 'lng', 'type', 'owner', 'program', 'data_time' ,'status' ,'data'];

	protected $casts = [
		'data'  =>  'array',
		'status' => 'boolean'
	];

	protected $dates = [
		'created_at',
		'updated_at',
		'data_time'
	];

	protected $appends = ['content'];

	public function getContentAttribute() {
		if(!isset($this->data) || !$this->data) {
			return '';
		}

		$str = [];
		$data = $this->data;
		$dataConfig = config('satfish.buoys');
		if($this->name) {
			$str[] = '<strong>' . $this->name . '</strong>';
		}

//		dd($this->data_time);
		if($this->data_time) {
			$str[] = $this->data_time->setTimezone(config('satfish.timezone'))->format('M d, Y. h:m a');
		}

		foreach($dataConfig as $slug => $item) {
			if(isset($data[$slug]) && $data[$slug] && $data[$slug] != 'MM') {
				$str[] = $item['title'] . ': ' . $this->filterValue($data[$slug] , $item);
			}
		}

		return implode('<br>', $str);
	}

	private function filterValue($value, $item) {
		$rtrStr = $value . $item['unit'];
		if(isset($item['type']) && $item['type']) {
			switch($item['type']) {
				case 'temp' :
					$rtrStr = round(($value * 9/5) + 32, 2);
					$rtrStr .= '°F';
					$rtrStr .= ' (' . $value . $item['unit'] .' )';
				break;
				case 'speed' :
					$rtrStr = round($value * 1.94384, 2);
					$rtrStr .= ' knots';
					break;
				case 'height' :
					$rtrStr = round(floatval($value) * 3.2808399, 2);
					$rtrStr .= ' ft';
					break;
			}
		}

		return $rtrStr;
	}
}
