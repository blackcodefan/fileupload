<?php

namespace Satfish\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Satfish\Buoy;

class BuoysData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:new-buoys';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Populate data for the buoy stations';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
	    $client = new \GuzzleHttp\Client();
	    try {
		    $res    = $client->request( 'GET', 'https://www.ndbc.noaa.gov/data/latest_obs/latest_obs.txt' );

	    } catch (\Exception $exception) {
		    \Log::error('Error Communicating with ndbc noaa server for latest data');
		    die();
	    }
	    if($res->getStatusCode() == 200) {
	    	$csvSet = str_getcsv($res->getBody()->getContents(), "\n");

	    	$csvArray = [];

	    	//Configure CSV to Array set
	    	foreach($csvSet as $index => $line) {
			    $parts = preg_split('/\s+/', $line);

	    		if($index == 0) {
	    			$title = $parts;
	    			continue;
			    }

			    if($index == 1) {
				    $units = $parts;
				    continue;
			    }

			    $parts = array_combine($title, $parts);
			    $csvArray[$parts['#STN']] = $parts;
		    }


		    foreach($csvArray as $stn => $data) {
	    		$dbData = [
	    			'lat'   => $data['LAT'],
				    'lng'   => $data['LON'],
				    'data'  =>  $data,
				    'data_time' => $this->dataTime($data)
			    ];
			    //Update db with latest data
			    Buoy::updateOrCreate(['sid' => $stn], $dbData);
		    }

	    }
    }

    private function dataTime($data) {
    	$dateRtr = null;
		if(isset($data['YYYY']) && isset($data['MM']) &&
		   isset($data['DD']) && isset($data['hh']) &&
		   isset($data['mm'])) {
//			Carbon::parse($request->get('date_time'), config('app.timezone'))
			$dateRtr = Carbon::create($data['YYYY'], $data['MM'], $data['DD'], $data['hh'], $data['mm'], null, 'UTC')->setTimezone(config('app.timezone'));
		}

		return $dateRtr;
    }
}
