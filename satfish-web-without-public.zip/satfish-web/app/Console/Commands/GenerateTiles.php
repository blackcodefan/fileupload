<?php

namespace Satfish\Console\Commands;

use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Storage;
use Satfish\Helpers\General;
use Satfish\Helpers\MapTiler;
use Image;
use Satfish\Layers;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;
use Illuminated\Console\WithoutOverlapping;

class GenerateTiles extends Command
{
	use WithoutOverlapping;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:generate-tiles';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate tiles for pending layers';

    protected $layers = false;
    protected $layersCount = 0;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //Get layers those are not tiled yet with region & type details
        $this->layers = Layers::whereTiled(false)->with('region', 'type', 'media')->get();
        $this->layersCount = $this->layers->count();

        if($this->layersCount > 0) {
            //Converting Layers
            $bar = $this->output->createProgressBar($this->layersCount);

            foreach ($this->layers as $layer) {

	            $mediaObj = $layer->getFirstMedia('layers');

	            if(isset($mediaObj->mime_type) && ($mediaObj->mime_type == 'text/xml' || $mediaObj->mime_type == 'application/xml')) {
					$this->kmlToGeojson($layer, $mediaObj);
	            } else {
		            $this->generateLayer($layer);
	            }
                $tableSet[] = [
                    'region' => $layer->region->name,
                    'layer'  => $layer->type->name,
                    'file'   => $layer->getFirstMediaPath('layers'),
                    'created' => $layer->created_at
                ];

	            $layer->tiled = true;
                $layer->save();
	            $bar->advance();
            }

            $bar->finish();

            $this->line('');
            $this->line('');
            $this->info('Following layers got tiled version');

            //Print Layer Table
            $headers = ['Region', 'Layer', 'media', 'Created At'];

            $this->table($headers, $tableSet);
        } else {
            $this->info('No Pending layer to convert');
        }
    }


    /*
     * This method will accept an layers object as argument & will create tiles for that particular object
     *
     */
    protected function generateLayer($layer) {
        //TODO: commenting for test purposes
        //logger("Layer: " . $layer->region->name . ' | ' . $layer->type->slug);
        $storage_path = General::layerPath($layer);
        //If S3 is configured, we need to look into S3 for files

	    if(General::s3Configured()) {
		    $image      = Image::make( $layer->getFirstMediaUrl( 'layers' ) );
		    $imageMime = $image->mime();
		    Storage::disk('local')->put( $layer->getFirstMediaPath( 'layers' ), (string) $image->encode());
		    if(Storage::disk('local')->exists($layer->getFirstMediaPath( 'layers' ))) {
			    $localFile = storage_path('app/' . $layer->getFirstMediaPath( 'layers' ));
		    }
	    } else {
	    	$image = $layer->getFirstMedia('layers');
		    $imageMime = $image->mime_type;

		    $localFile = $layer->getFirstMediaPath('layers');
	    }

        $geoTif = './storage/app/tifs/' . $layer->region->id . '-' . $layer->type->id . '.tif';
        $geoTif3857 = './storage/app/tifs/' . $layer->region->id . '-' . $layer->type->id . '-3857.vrt';

        //Create a geoTiff file with expanded rgba
        $cordinates =  $layer->region->left_lng  . ' ' . $layer->region->upper_lat . ' ' . $layer->region->right_lng . ' ' . $layer->region->bottom_lat;
        $baseCommand = "gdal_translate -of GTiff -co 'TILED=YES' -a_ullr $cordinates -a_srs EPSG:4326 ";


        if($imageMime == 'image/jpg' || $imageMime == 'image/jpeg') {
	        $expand = '';
        } else {
	        $expand = '-expand rgba ';
        }

	    $layersPath = $localFile . ' ' . $geoTif;

	    $process = new Process($baseCommand . $expand . $layersPath, null, null, null, 3600);
	    $process->run();

	    if (!$process->isSuccessful()) {
		    $process = new Process($baseCommand . $layersPath, null, null, null, 3600);
		    $process->run();

		    //If not successfull we should try running without color expand
		    if (!$process->isSuccessful()) {
			    throw new ProcessFailedException($process);
		    }
	    }

	    //If not succesfull we should try running without color expand
	    if (!$process->isSuccessful()) {
		    throw new ProcessFailedException($process);
	    }

	    $zoom = General::getZoom($layer->region);

	    //Clear the storage path first
	    $command = 'rm -rf ' . $storage_path;
	    $python = config('satfish.python');
	    $command .= ' && ' . $python . ' mapping/gdal2tiles.py -z '. $zoom['min'] . '-' . $zoom['max'] . ' -w none -n -q ' . $geoTif . ' ' . $storage_path;
	    $process = new Process($command, null, null, null, 3600);
	    $process->run();

	    if (!$process->isSuccessful()) {
		    throw new ProcessFailedException($process);
	    }

	    //Get EPSG:3857 based png first for mobile apps
	    $command = 'gdalwarp -of VRT -s_srs EPSG:4326 -t_srs EPSG:3857 -overwrite ' . $geoTif . ' ' . $geoTif3857;

	    $process = new Process($command, null, null, null, 3600);
	    $process->run();

	    if ($process->isSuccessful()) {
		    //Once we have new geoTiff we need to work on our png file
		    $fullPng = $storage_path . '/' . 'full.png';
		    $command = 'gdal_translate -of png ' . $geoTif3857 . ' ' . $fullPng;
		    $process = new Process($command, null, null, null, 3600);
		    $process->run();

		    if (!$process->isSuccessful()) {
			    throw new ProcessFailedException($process);
		    }
	    }

	    //Now Put newly created files to S3 if configured
	    if(General::s3Configured()) {
		    $basePath = General::layerBase($layer);
		    Storage::disk('s3sf')->delete($basePath); //Get Rid of old files first if any
		    Storage::disk('s3sf')->put($storage_path, $basePath); //Put new files in
	    }

    }

    protected function kmlToGeojson($layer) {
	    //@TODO: commenting for temporary purpose
        //logger("Layer: " . $layer->region->name . ' | ' . $layer->type->slug);

	    //If S3 is configured, we need to look into S3 for files
	    if(General::s3Configured()) {
	    	$client = new Client();
		    $res = $client->request('GET', $layer->getFirstMediaUrl( 'layers' ));
		    $fileContent = $res->getBody();
//		    $fileContent = file_get_contents($layer->getFirstMediaUrl( 'layers' ));
		    Storage::disk('local')->put( $layer->getFirstMediaPath( 'layers' ), (string) $fileContent);
		    if(Storage::disk('local')->exists($layer->getFirstMediaPath( 'layers' ))) {
			    $localFile = storage_path('app/' . $layer->getFirstMediaPath( 'layers' ));
		    }
	    } else {
		    $localFile = $layer->getFirstMediaPath('layers');
	    }

	    //Clear the storage path first
	    if (App::environment('production')) {
		    $command = '/usr/local/bin/togeojson ' . $localFile;
	    } else {
		    $command = 'togeojson ' . $localFile;
	    }

	    $process = new Process($command, null, null, null, 3600);
	    $process->run();

	    if (!$process->isSuccessful()) {
		    throw new ProcessFailedException($process);
	    }

	    //Now Put newly created files to S3 if configured
	    if(General::s3Configured()) {
		    $basePath = General::layerBase($layer) . '/gj/' . $layer->id . '.js' ;
		    Storage::disk('s3sf')->delete($basePath); //Get Rid of old files first if any
		    Storage::disk('s3sf')->put($basePath, $process->getOutput()); //Put new files in
	    }

    }
}
