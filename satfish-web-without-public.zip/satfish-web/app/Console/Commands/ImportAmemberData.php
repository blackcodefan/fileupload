<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use Satfish\AmemberData;
use Satfish\CouponBatch;
use Satfish\Coupon;
use Carbon\Carbon;
use Satfish\User;
use Stripe\Plan;
use DateTime;
use Storage;
use File;
use DB;

class ImportAmemberData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:ImportAmemberData';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import User subscriptions,coupons and invoices record';

    protected $connection;

    protected $plans;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
//        \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
//        $plans = Plan::all()->data;
//        foreach($plans as $plan){
//            $this->plans[$plan->id] = $plan->id;
//        }
//        return;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if($this->confirm("Have you imported amember users from before")){

            $this->output->progressStart(3);
            //@TODO: change plans from stripe
            //2nd step import coupons and generate coupons

            $this->info("  Importing coupons ... ");
            $this->importCoupons();

            $this->output->progressAdvance();
            $this->info("  Importing stripe data ... ");
            //$this->importStripeData();


            $this->output->progressAdvance();

            $this->info("  Making subscription with coupons ... ");
            //$this->makeSubscriptionsWithCoupons();
            $this->output->progressFinish();
        }else{
            $this->info("  Please import users first ... ");
        }
    }

    protected function importCoupons(){

        \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        $this->connection = DB::connection('amember');
        $couponsBatch = $this->connection->table('am_coupon_batch')->get();

        foreach($couponsBatch as $batch){

            $batchInput = [

                'discount_type' => $batch->discount_type,
                'discount' => $batch->discount,
                'begin_date' => (!empty($batch->begin_date) AND $batch->begin_date !== '0000-00-00') ? $batch->begin_date:NULL,
                'expire_date' => !empty($batch->expire_date)? $batch->expire_date:NULL,
                'is_disabled' => $batch->is_disabled,
                'is_recurring' => $batch->is_recurring,
                'product_ids' => !empty($batch->product_ids)? $this->getProductPlans($batch->product_ids):NULL,
                'use_count' => $batch->use_count,
                'user_count' => $batch->user_use_count,
                'require_product' => !empty($batch->require_product)? $this->getProductPlans($batch->require_product):NULL,
                'prevent_if_product' => !empty($batch->prevent_if_product)? $this->getProductPlans($batch->prevent_if_product):NULL,
            ];

            $coupons = $this->connection->table('am_coupon')->where('batch_id',$batch->batch_id)->get();

            $couponDuration = $this->getDuration($batchInput);
            $batchInput['duration'] = $couponDuration;
            foreach($coupons as $coupon){
                $couponCode = $coupon->code;
                $couponInput = [
                    'code' => $coupon->code,
                    'used_count' => $coupon->used_count,
//                    'user_id' => !empty($coupon->user_id)? $coupon->user_id:NULL,
                    'user_id' => $coupon->user_id,
                ];
            }
            $batchCoupon = CouponBatch::create($batchInput);

            $batchCoupon->coupon()->create($couponInput);

            // Generating coupon on stripe here

            $stripeCouponInput = [
                'duration' => $couponDuration ,
                'id' => $couponCode,
                'max_redemptions' => $batch->use_count,
            ];

            if($batch->discount_type == 'number'){
                $type = 'amount_off';
                $stripeCouponInput['currency'] = 'USD';
            }else{
                $type = $batch->discount_type."_off";
            }

            $stripeCouponInput[$type] = round($batch->discount);



            if($couponDuration == 'repeating'){
                $stripeCouponInput['duration_in_months'] = $this->dateDiffIntoMonths($batch->begin_date,$batch->expire_date);

            }

            if(!empty($batchInput['expire_date'])){
                $expiry = Carbon::parse($batchInput['expire_date'], config('app.timezone'));
                if($expiry->isPast()){
                    //  $stripeCouponInput['valid'] = false;
                }else{
                    // $stripeCouponInput['redeem_by'] = Carbon::parse($batchInput['expire_date'])->timestamp;
                }

            }

            // if already exist error check then delete than and create again
            try{
                \Stripe\Coupon::create($stripeCouponInput);
            }catch (\Exception $e){

                try{
                    $cpn = \Stripe\Coupon::retrieve($stripeCouponInput['id']);
                    $cpn->delete();
                    \Stripe\Coupon::create($stripeCouponInput);
                }catch(\Exception $e){
                    // date error than it should not be greater than 5 years or so
                    //dd($batchCoupon,$stripeCouponInput);
                    \Stripe\Coupon::create($stripeCouponInput);
                }


            }

        }

        return;

    }

    protected function getProductPlans($products){
        $plans = [];
        $productIds = (preg_replace("/[^0-9,.]/", "", $products));
        $plans = $this->connection->table('am_billing_plan')
                             ->join('am_product', 'am_billing_plan.product_id', '=', 'am_product.product_id')
                            ->whereIn('am_billing_plan.product_id',explode(",",$productIds))
                            ->where('am_product.is_disabled','!=',1)
                            ->pluck('am_product.title');
        //dd($planPrices);
        if(!empty($plans)){
            foreach($plans as $plan){

                $stripePlan[] = $this->getPlan($plan);
            }
        }

        return $stripePlan;
    }

    protected function getPlan($planName){

        // conver plan name to slug
        $planName = $this->makeSlug(strtolower($planName));

        return $this->plans[$planName];
    }

    public function divideFloat($a, $b, $precision=3) {
        $a*=porw(10, $precision);
        $result=(int)($a / $b);
        if (strlen($result)==$precision) return '0.' . $result;
        else return preg_replace('/(\d{' . $precision . '})$/', '.\1', $result);
    }

    public function makeSlug($planName){
        $planName = str_replace(' ', '_', $planName);
        $planName = str_replace('-', '_', $planName);
        return $planName;
    }

    protected function getDuration($coupon){
        if($coupon['is_recurring']){
            return 'repeating';
        }

        if($coupon['expire_date']){
            return 'once';
        }

        if(empty($coupon['expire_date']) AND empty($coupon['begin_date'])){
            return 'forever';
        }
    }

    protected function dateDiffIntoMonths($date1,$date2){
        $datetime1 = new DateTime($date1);
        $datetime2 = new DateTime($date2);
        $interval = $datetime1->diff($datetime2);
        $months =  $interval->format('%y') * 12 + $interval->format('%m');
        return $months;
    }

    protected function importStripeData(){

        $this->connection = DB::connection('amember');
        $users = $this->connection->table('am_user')->get();

        foreach($users as $user){
            $userData = [];
            //get current recurring invoice of user
            $invoice = $this->connection->table('am_invoice')->where('status',2)->where('paysys_id','stripe')->whereNull('tm_cancelled')->where('user_id',$user->user_id)->first();
            if($invoice){
                //get user fields from am_data table
                $amData = $this->connection->table('am_data')->where('id',$user->user_id)->pluck('value','key');
                if(isset($amData['stripe_token'])){
                    $userData = [
                        'user_id' => !empty($user->user_id)? $user->user_id:NULL,
                        'cc_expires' => isset($amData['stripe_cc_expires'])? $amData['stripe_cc_expires']:NULL,
                        'cc_masked'  => isset($amData['stripe_cc_masked'])? $amData['stripe_cc_masked']:NULL,
                        'stripe_token' => $amData['stripe_token'],
                        'binded'     => 0,
                        'rebill_amount' => $invoice->second_subtotal,
                        'rebill_date' => $invoice->rebill_date,
                        'coupon_id' => $invoice->coupon_id,
                    ];
                    AmemberData::create($userData);
                }
            }
        }

        //AmemberData::insert($userData);
        return;
    }

    protected function makeSubscriptionsWithCoupons(){
        \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        $recurringUsers = AmemberData::with('user')->where('binded',0)->get();

        $allImportedCoupons = Coupon::get()->keyBy('id');
        foreach($recurringUsers as $user){


            $trialEndsAt = $this->getTrialDate($user->rebill_date);

            if($trialEndsAt){
                $subscriptionInput = array(
                    "customer" => $user->stripe_token,
                    "plan" => $this->getPlan($user->rebill_amount),
                    'trial_end' => $trialEndsAt->timestamp,
                    //
                );
                if(!empty($user->coupon_id)){
                    $subscriptionInput['coupon'] = $allImportedCoupons[$user->coupon_id]->code;
                }

                $subscription = \Stripe\Subscription::create($subscriptionInput);

                $userObj = $user->user;
                $userObj->stripe_id = $user->stripe_token;
                $userObj->card_last_four = substr($user->cc_masked, -4);
                $userObj->trial_ends_at  =  $trialEndsAt;
                $userObj->subscriptions()->create([
                    'name' => 'Satfish',
                    'stripe_id' => $subscription->id,
                    'stripe_plan' => $subscription->items->data[0]->plan->id,
                    'quantity' => 1,
                    'trial_ends_at' => $trialEndsAt,
                    'ends_at' => null,
                ]);
                $userObj->save();
                $user->binded = true;
                $user->save();
            }

        }
    }

    protected function getTrialDate($date){

        $dStart = new \DateTime($date);
        $dEnd  = new \DateTime(date('Y-m-d h:i:s', time()));
        $dDiff = $dEnd->diff($dStart);
        $days =  $dDiff->format('%R'); // use for point out relation: smaller/greater
        $diff = $dDiff->days;
        $totalDays = $days.$diff;

        if($totalDays > 0){
            return Carbon::now()->addDays($diff);
        }
        return false;
    }




}
