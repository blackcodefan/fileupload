<?php

namespace Satfish\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use ParseCsv\Csv;
use Satfish\Helpers\BulkInsert;

class ImportCsv extends Command {
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'satfish:csv';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Import all pending CSV files into Database';

	/**
	 * @var array
	 */
	protected $allowedEntities = ['hotbites', 'markers', 'regions', 'layers','users'];

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function handle() {
		//List of all files
		$files = Storage::files( 'csv' );

		foreach ( $files as $file ) {
			if($model = $this->fileToModel($file)) {
				$csv = Storage::get( $file );
				$csv = new Csv( $csv );

				//After loading data we need to confirm the numbers
				if(count($csv->data) > 0) {

					$bulkInsert = BulkInsert::insert( $csv, $model, $file );

					//Based on the status, decide filename
					if($bulkInsert->status) {
						Storage::move($file, 'trash/success/' . $model . '-' . Carbon::now(config('app.timezone'))->timestamp . '.csv');
						continue;
					}
				}

			}

			//Move folder for failed files
			Storage::move($file, 'trash/' . $file);
		}
	}

	/**
	 * @param $file
	 *
	 * @return bool
	 */
	protected function fileToModel($file) {
		$dir = explode('/', $file);

		if(isset($dir[1])) {
			$entity = explode('-', $dir[1]);

			return in_array($entity[0], $this->allowedEntities) ? $entity[0] : false;
		}

		return false;
	}
}