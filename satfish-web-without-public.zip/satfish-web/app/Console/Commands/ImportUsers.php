<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use ParseCsv\Csv;
use Satfish\Helpers\BulkInsert;

class ImportUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:importusers';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Users from amember exported CSV';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $files = Storage::files( 'users' );
        if(!empty($files)){

            $file = Storage::get(  $files[0]);
            $csv = new Csv( $file );
            //$csv->save();
            if(count($csv->data) > 0) {

                $bulkInsert = BulkInsert::insert( $csv, 'users',$file,false,$this->output);
                //Based on the status, decide filename
                if($bulkInsert->status) {
                    $this->output->write('Users imported successfully');
                }else{
                    $this->output->write('Got some issue while import users');
                }
            }
            //$this->output->progressFinish();

        }
    }
}
