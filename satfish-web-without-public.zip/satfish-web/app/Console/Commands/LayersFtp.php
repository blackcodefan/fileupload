<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;

use Satfish\Layers;
use Satfish\Region;
use Satfish\Type;
use Carbon\Carbon;
use Storage;
use File;
use DB;

class LayersFtp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:layers-ftp';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Load files from FTP and generate layers';
    protected $importedLayers = [];
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $oldSlugs = config('satfish.old_slugs');
        $this->info("Converting slugs");
        $types = Type::whereIn('slug', $oldSlugs)->get()->keyBy('slug');
        $this->info("Grabbing layers from db");
        $this->importedLayers = Layers::get()->keyBy('imported')->toArray();
        //Let's process each region one by one

        $this->info('Grabbing all regions from db');
        foreach(Region::all() as $region) {
            $this->info("Getting FTP Files for: " . $region->name);
            $allFiles = Storage::disk('fishdop')->files($region->slug);

            $finalFiles = [];
            //Loop through all files
            $totalFiles = count($allFiles);
	        $bar = $this->output->createProgressBar($totalFiles);
            foreach(array_chunk($allFiles,100) as $key=>$files) {
                foreach($files as $file){
                    $dirFile = explode('/', $file);
                    //dd(explode('_' , explode('.', $dirFile[1])[0]));
                    // if(isset($dirFile[0]) && $fileName = explode('_' , explode('.', $dirFile[1])[0])) {
                    if(isset($dirFile[0]) && $fileName = explode('_' , basename($dirFile[1], "." . pathinfo($dirFile[1], PATHINFO_EXTENSION)))) {
                        // $this->info("\ndirfile " . var_export(basename($dirFile[1]), true) . " \n");
                        // $this->info("\nfile name   " . var_export($fileName, true) . "  \n\n");

                        //If we have slug in old slugs && the file is from last 2 weeks
                        if(isset($fileName[1]) &&
                            isset($oldSlugs[$fileName[1]]) &&
                            isset($fileName[2]) &&
                            $fileName[2] > Carbon::now(config('satfish.timezone'))->subDays(14)->format("ymd")
                        ) {
                            $newSlug = $oldSlugs[$fileName[1]];
                            $fileName[] = $file;
                            $finalFiles[$newSlug][] = $fileName;
                        }
                    }

	                $bar->advance();
                }

                foreach ( $finalFiles as $slug => $layers ) {
                    $this->info("Inserting layer with slug " . $slug . " into DB");
                    // $this->info("\n\nSlug " . var_export($slug, true) . "\n\n");
                    // $this->info("Layers " . var_export($layers, true));
                    if(isset($types[$slug])) {
                        foreach ( $layers as $layer ) {
                            if(!isset($this->importedLayers[$layer[6]])){
                                $temp = $layer[4] ? [
                                    'start' =>  $layer[4]/10,
                                    'end'   =>  $layer[5]/10,
                                ] : null;

                                $data = [
                                    'region_id'  => $region->id,
                                    'type_id'    => $types[$slug]->id,
                                    'status'     => 1,
                                    'temp'     => $temp,
                                    'tiled'      => 0,
                                    'imported' => $layer[6],
                                    'created_at' => Carbon::createFromFormat('ymdHi', $layer[2] . $layer[3] , config('satfish.timezone'))->timezone('UTC')
                                ];

                                $this->importedLayers[$layer[6]] = true;



                                $layerObj = new Layers( $data );
                                $image = Storage::disk('fishdop-local')->put($layer[6], Storage::disk('fishdop')->get($layer[6]));
                                $layerObj->addMedia( Storage::disk('fishdop-local')->url($layer[6]) )
                                    ->toMediaCollection( 'layers' );

                                $layerObj->save();
                            }
                        }
                    }
                }
            } // array chunk end


	        $bar->finish();

	        $this->line('');
	        $this->line('');
	        $this->info("$totalFiles files imported for region: " . $region->name);

        } // Region loop end
    }
}
