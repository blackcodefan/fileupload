<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use Satfish\Helpers\Notifier;
use Satfish\User;

class PendingInvoices extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:pending-invoices';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sending pending invoices to users';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $users = User::whereNotNull('stripe_id')->get();
        $allInvoices = [];

        foreach($users as $user)
        {
            $pendingInvoices = [];
            foreach($user->invoices() as $invoice)
            {
                if($invoice->status == 'pending' || $invoice->status == 'open' || $invoice->status == 'uncollectible')
                {
                    $pendingInvoices[] = $invoice;
                }
            }

            if(!empty($pendingInvoices))
            {
                $allInvoices[$user->id]['user'] = $user;
                $allInvoices[$user->id]['invoices'] = $pendingInvoices;
            }
        }

        if(!empty($allInvoices))
        {
            $admin =  User::with( 'roles' )->whereHas( 'roles', function ( $q ) {
                $q->where( 'name', 'admin' );
            } )->where( 'id', '!=', $user->id )->first();

            Notifier::notify('membership.pending_invoices',['invoices' => $allInvoices],$admin);
        }
        return;
    }
}
