<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use Satfish\UserTrial;

class ProcessTrials extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:trials';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Activate Trials on valid dates';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
		$userTrials = UserTrial::with('user')->effective()->get();

		foreach ($userTrials as $userTrial) {
			$userTrial->user->trial_ends_at = $userTrial->valid_to;
			$userTrial->user->save();
		}
    }
}
