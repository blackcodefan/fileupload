<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use GuzzleHttp\Client;
use Satfish\Buoy;

class SyncBuoys extends Command {
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'satfish:stations';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Grab list of active stations';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function handle() {
		$client = new \GuzzleHttp\Client();
		try {
			$res    = $client->request( 'GET', 'https://www.ndbc.noaa.gov/activestations.xml' );

		} catch (\Exception $exception) {
			\Log::error('Error Communicating with ndbc noaa server');
			die();
		}

		if($res->getStatusCode() == 200) {
			$xml = \XmlParser::extract($res->getBody()->getContents());
			$buoys = $xml->parse([
				'stations' => ['uses' => 'station[::id>sid,::lat>lat,::lon>lng,::name>name,::owner>owner,::pgm>program,::type>type]'],
			]);

			foreach($buoys['stations'] as $buoy) {
				Buoy::updateOrCreate(['sid' => $buoy['sid']], $buoy);
			}

			\Log::info('Stations Updated');
		}

	}
}
