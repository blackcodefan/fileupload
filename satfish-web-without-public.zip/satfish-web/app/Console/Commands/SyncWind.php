<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use Satfish\Helpers\WindProcess;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;

class SyncWind extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:wind';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Grab latest Wind data and process it';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
    	$windProcess = new WindProcess();
	    $windProcess->startProcess();
    }
}
