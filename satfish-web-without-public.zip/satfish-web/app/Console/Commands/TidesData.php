<?php

namespace Satfish\Console\Commands;

use Illuminate\Console\Command;
use Satfish\RegionOptions;
use Satfish\TidesData as TidesDataModel;
use Carbon\Carbon;
class TidesData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'satfish:tidesData';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch Noaa Data';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $regionOptions = RegionOptions::with('region')->get();
        foreach($regionOptions as $regionOption) {
            $today = Carbon::today();
            $dataUpdated = Carbon::parse($regionOption->data_updated);
            $diff = $dataUpdated->diffInDays($today);
            if ($regionOption->frequency <= $diff) {
                $dateFrom = Carbon::today()->subDays(15);
                $dateTo = Carbon::today()->addDays(15);
                if($regionOption->server == 1){
                    $this->upodateNoaaData($dateFrom, $dateTo,$regionOption->station_id,$regionOption->region_id,$regionOption->id,1);
                }else{
                    $this->updateCiceseData($dateFrom,$dateTo,$regionOption->location_id);
                }

            }
        }

    }


    public function updateCiceseData($from,$to,$channelId){

        $from = Carbon::parse($from)->format("m/d/Y");
        $to = Carbon::parse($to)->format("m/d/Y");

        $client = new \GuzzleHttp\Client();
        $endpoint = "http://redmar.cicese.mx/cgi-bin/predmar.txt";
        $regionOptionId = 1;
        $data = [
            'datei' => $from,
            'datef' => $to,
            'dt' => '60',
            'estacion' => $channelId,
            'accion' => 'Predecir',
            'href' => 2,
            'opcion' => 1,
            'zt' => 0
        ];
        $response =  $client->request('POST',$endpoint,['form_params' => $data],['Content-Type' => 'application/x-www-form-urlencoded']);
        $statusCode = $response->getStatusCode();
        if($statusCode == 200) {
            $content = $response->getBody()->getContents();
            $counter = "";
            $dateData = $finalData =  [];
            foreach(preg_split("/((\r?\n)|(\r\n?))/", $content) as $line){
                // do stuff with $line
                $counter++;
                if($counter > 7){
                    $line = preg_replace("/\s+/","-",$line);
                    $line = explode("-",$line);
                    if(isset($line[0]) && !empty($line[0])){
                        $date = $line[0]."-".$line[1]."-".$line[2];
                        $value = $line[6];
                        if(empty($value) && isset($line[7])){
                            $value = "-".$line[7];
                        }
                        $dateData[$date][] = ['t' => $date." ".$line[3].":".$line[4],"v" => $value];
                    }
                }
            }


            foreach($dateData as $key=>$data){
                // checking if we are getting full day record
                if(count($data) >= 23 ){
                    $input = [
                        'data_date' => $key,
                        'data' => $data,
                        'region_options_id' => $regionOptionId,
                        'server' => 0,
                    ];
                    TidesDataModel::create($input);
                }
            }
        }

    }

    public function upodateNoaaData($from,$to,$stationId,$regionId,$regionOptionId){
        $from = Carbon::parse($from)->format("Ymd");
        $to = Carbon::parse($to)->format("Ymd");
        $endpoint = "https://tidesandcurrents.noaa.gov/api/datagetter?product=predictions&begin_date=$from&end_date=$to&datum=MLLW&station=$stationId&time_zone=GMT&units=english&interval=&format=json&application=NOS.COOPS.TAC.WL";
        $client = new \GuzzleHttp\Client();
        $response =  $client->request('GET', $endpoint);
        $statusCode = $response->getStatusCode();
        if($statusCode == 200){
            $content = $response->getBody()->getContents();
            $content = json_decode($content);
            if(isset($content->predictions)){
                $predictions = $content->predictions;

                foreach($predictions as $prediction){
                    $date = explode(" ",$prediction->t);
                    $sortedPredictions[$date[0]][] = $prediction;
                }

                foreach($sortedPredictions as $key=>$predictions){
                    $insertData = ['region_options_id' => $regionOptionId,'server' => 1, 'data_date' => $key,'data' => $predictions];
                    TidesDataModel::create($insertData);
                }
                return $sortedPredictions;
            }
        }


    }
}
