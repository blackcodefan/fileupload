<?php

namespace Satfish\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel {
	/**
	 * The Artisan commands provided by your application.
	 *
	 * @var array
	 */
	protected $commands = [
		//
	];

	/**
	 * Define the application's command schedule.
	 *
	 * @param  \Illuminate\Console\Scheduling\Schedule $schedule
	 *
	 * @return void
	 */
	protected function schedule( Schedule $schedule ) {



		$schedule->command( 'satfish:layers-ftp' )
		         ->hourly()
		         ->before( function () {
			         logger( 'Started FTP Layers Import...' );
		         } )
		         ->after( function () {
			         logger( 'Ended FTP Layer Import...' );
		         } )
		         ->withoutOverlapping();


		$schedule->command( 'satfish:generate-tiles' )
		         ->everyFifteenMinutes()
		         ->before( function () {
			         logger( 'Started Tiling...' );
		         } )
		         ->after( function () {
			         logger( 'Ended Tiling.' );
		         } )
		         ->withoutOverlapping(5 * 60);


		$schedule->command( 'satfish:csv' )
		         ->everyMinute()
		         ->withoutOverlapping();


		$schedule->command( 'satfish:new-buoys' )
		         ->everyFifteenMinutes()
		         ->withoutOverlapping();

		$schedule->command( 'satfish:wind' )
		         ->hourly()
		         ->before( function () {
			         logger( 'Processing Wind' );
		         } )
		         ->after( function () {
			         logger( 'Processing Wind End' );
		         } )
		         ->withoutOverlapping();


		$schedule->command('satfish:stations')
            ->daily();


        $schedule->command('satfish:pending-invoices')
            ->daily();

        $schedule->command( 'satfish:sync-coupons' )
            ->everyFifteenMinutes()
            ->withoutOverlapping();


		$schedule->command('cloudflare:reload')->daily();

		//Clear Trials every hour
		$schedule->command('satfish:trials')->hourly();

		//Clear Expired Bans
		$schedule->command('ban:delete-expired')->everyMinute();

	}

	/**
	 * Register the commands for the application.
	 *
	 * @return void
	 */
	protected function commands() {
		$this->load( __DIR__ . '/Commands' );

		require base_path( 'routes/console.php' );
	}
}
