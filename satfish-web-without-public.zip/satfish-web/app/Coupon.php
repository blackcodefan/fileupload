<?php

namespace Satfish;
use Satfish\Traits\VueTableSearch;
use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    use VueTableSearch;
    protected $table = "coupons";
    protected $fillable = ['id','batch_id','code','used_count','user_id'];

    /**
     * Get the post that owns the comment.
     */
    public function batch()
    {
        return $this->belongsTo('Satfish\CouponBatch');
    }

}
