<?php

namespace Satfish;

use Satfish\Helpers\Brand;
use Satfish\Traits\VueTableSearch;
use Illuminate\Database\Eloquent\Model;

class CouponBatch extends Model
{
    use VueTableSearch;
    protected $table = "coupon_batch";
    protected $fillable = ['id','discount_type','code', 'brand', 'discount','expire_date','begin_date','is_disabled','is_recurring','product_ids','use_count','coupon_id','require_product','prevent_if_product','duration'];
    protected $casts = ['require_product'=> 'array','prevent_if_product' => 'array','product_ids' => 'array'];

	protected $appends = [
		'branded'
	];

    public function coupon(){
        return $this->hasMany('Satfish\Coupon','batch_id');
    }

	public function getBrandedAttribute() {
		return Brand::getDetails($this->brand);
	}

}
