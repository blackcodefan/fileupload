<?php

namespace Satfish\Exceptions;
use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $e)
    {

//        return parent::render($request, $e);
        // if request ajax or wants json or exception is not coming from laravel validation as laravel handle that by itself  
        if (($request->wantsJson() OR $request->ajax() )) {

            // Define the response
            $response = [
                'errors' => 'Sorry, something went wrong.'
            ];

            if($e instanceOf \Illuminate\Validation\ValidationException)
            {
                $response['errors'] = $e->errors();
            }
    
            // If the app is in debug mode
            if (config('app.debug')) {
                
                // Add the exception class name, message and stack trace to response
                $response['exception'] = get_class($e); // Reflection might be better here
                $response['message'] = $e->getMessage();
                $response['trace'] = $e->getTrace();
            }
            
            //default error 
            $status = 400;
    
            // If this exception is an instance of HttpException
            if ($this->isHttpException($e)) {
                // Grab the HTTP status code from the Exception
                $status = $e->getStatusCode();
            }

    
            // Return a JSON response with the response array and status code
            return response()->json($response, $status);
        }


        if ($this->isHttpException($e))
        {
            return $this->renderHttpException($e);
        }
        return parent::render($request, $e);
    }

    /**
     * Render the given HttpException.
     *
     * @param  \Symfony\Component\HttpKernel\Exception\HttpException  $e
     * @return \Symfony\Component\HttpFoundation\Response
     */
    protected function renderHttpException(HttpExceptionInterface $e)
    {
        if(env('APP_ENV') == 'local'){
            return $this->convertExceptionToResponse($e);
        }else{
            return response()->view('errors.error', ['e' => $e], $e->getStatusCode());
        }


    }

    protected function getJsonMessage($e){
        // You may add in the code, but it's duplication
        return  [
                  'status' => 'false',
                  'message' => $e->getMessage()
               ];
               
    }

    protected function getExceptionHTTPStatusCode($e){
        // Not all Exceptions have a http status code
        // We will give Error 500 if none found
        return method_exists($e, 'getStatusCode') ? 
                         $e->getStatusCode() : 500;
    }
}
