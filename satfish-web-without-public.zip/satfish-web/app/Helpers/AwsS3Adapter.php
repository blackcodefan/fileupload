<?php

namespace Satfish\Helpers;

use Illuminate\Support\Facades\File;
use League\Flysystem\AwsS3v3\AwsS3Adapter as OriginalAwsAdapter;
use League\Flysystem\Config;
use League\Flysystem\Util;


class AwsS3Adapter extends OriginalAwsAdapter {

	/**
	 * This method is override to support directory upload as well.
	 *
	 * So when the provided path is actually a directory system will do that automatically
	 *
	 * @param        $path
	 * @param        $body
	 * @param Config $config
	 *
	 * @return array
	 */
	protected function upload($path, $body, Config $config)
	{
		$key = $this->applyPathPrefix($path);
		$slashKey = '/' . $key;
		$options = $this->getOptionsFromConfig($config);
		$acl = array_key_exists('ACL', $options) ? $options['ACL'] : 'private';

		if(File::isDirectory($slashKey)) {
			$options = $this->getOptionsFromConfig($config);
			$this->s3Client->uploadDirectory($slashKey, $this->bucket, $body, ['force' => 'true', 'concurrency' => 10]);
			$this->normalizeResponse($options, $key);
		} else {
			return parent::upload($path, $body, $config);
		}

	}


	/**
	 * Customization for deleting directory objects as well
	 *
	 * @param string $path
	 *
	 * @return bool
	 */
	public function delete($path)
	{
		//If this is a directory
		if(preg_match('/^([-\.\w]+)$/', $path) > 0) {
			$response = $this->s3Client->deleteMatchingObjects($this->bucket, $path);

			return is_null($response) ? true : false;
		} else {
			parent::delete($path);
		}
	}

}