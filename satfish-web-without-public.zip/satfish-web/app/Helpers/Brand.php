<?php


namespace Satfish\Helpers;


class Brand {
	/**
	 * Return the active brand name's slug
	 *
	 * @return bool|string
	 */
	public static function active ($param = false) {

		foreach (config('satfish.brands') as $brand) {
			if(self::parsedUrl() == $brand['app_host']) {
				return self::getDetails($brand, $param);
			}
		}

		return false;
	}

	public static function getDetails($brand, $param = false) {


		$brand = is_array($brand) ? $brand :  config('satfish.brands.'.$brand);

		if($param) {

			return isset($brand[$param]) ? $brand[$param] : false;
		} else {
			return $brand;
		}
	}

	protected static function parsedUrl($scheme = 'host') {
		$url = url()->current();
		return parse_url($url)[$scheme];
	}
}