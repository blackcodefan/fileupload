<?php

namespace Satfish\Helpers;

use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Log;
use ParseCsv\Csv;
use Satfish\HotBites;
use Satfish\Layers;
use Satfish\Markers;
use Satfish\Region;
use Satfish\User;


class BulkInsert {
	protected $model;
	protected $file;
	public $status;
	private $output;



	public function __construct(Csv $csv, $model, $file,$normalize,$output) {
		$this->model = $model;
		$this->file = $file;
		$this->output = $output;
		//Normalize Data && Pass data
        $data = $csv->data;

        if($normalize){

            $data = $this->normalizeData($data);
        }
		return $this->$model($data);
	}

	protected function normalizeData($data) {
		$newArray = [];
		$subElements = [];
		foreach($data[0] as $key => $value) {

			//Check each column
			$keyArr = explode('.', $key);
			if (count($keyArr) > 1) {
				$subElements[$key] = $keyArr;
			}
		}


		//If we have anything in subElements
		if($subElements) {
			foreach ($data as $index => $entry) {
				//Combine in associated array
				foreach ($entry as $key => $value) {
					if(isset($subElements[$key])) {
						$newArray[$index][$subElements[$key][0]][$subElements[$key][1]] = $value;
					} else {
						$newArray[$index][$key] = $value;
					}
				}

				//For encoding sub arrays to JSON
				foreach ($newArray[$index] as $key => $value) {
					if(is_array($value)) {
						$newArray[$index][$key] = json_encode($value);
					}
				}
			}

			return $newArray;
		}

		return $data;
	}


	protected function hotbites($data) {
		try {
			HotBites::insert($data);
			return $this->status = true;
		} catch (QueryException $e) {
			$this->logError($e->getMessage());
		} catch (\PDOException $e) {
			$this->logError($e->getMessage());
		}
	}

	protected function layers($data) {
		try {
			Layers::insert($data);
			return $this->status = true;
		} catch (QueryException $e) {
			$this->logError($e->getMessage());
		} catch (\PDOException $e) {
			$this->logError($e->getMessage());
		}
	}

	protected function regions($data) {
		try {
//			$data['extra'] = [
//				'zoom_default'  => $data['zoom_default'],
//				'zoom_max'      =>  $data['zoom_max'],
//				'zoom_min'      =>  $data['zoom_min']
//			];
//
//			unset($data['zoom_default']);
//			unset($data['zoom_max']);
//			unset($data['zoom_min']);
			
			Region::insert($data);
			return $this->status = true;
		} catch (QueryException $e) {
			$this->logError($e->getMessage());
		} catch (\PDOException $e) {
			$this->logError($e->getMessage());
		}
	}

	protected function markers($data) {
		try {
			Markers::insert($data);
			return $this->status = true;
		} catch (QueryException $e) {
			$this->logError($e->getMessage());
		} catch (\PDOException $e) {
			$this->logError($e->getMessage());
		}
	}


	protected function users($data){


        $data = collect($data);

        foreach($data->chunk(5000) as $users){
            foreach($users as $user){
                $userInput[] = [
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['name'],
                        'email' => $user['email'],
                        'password' => bcrypt('test123'),
                        'created_at' => $user['created_at'],
                    ],
                    'person' => [
                        'first_name' => $user['first_name'],
                        'last_name'  => $user['last_name'],
                        'street'     => $user['street'],
                        'city'       => $user['city'],
                        'state_title' => $user['state_title'],
                        'zip_code'   => $user['zip_code'],
                        'country'    => $user['country'],
                        'country_title' => $user['created_at'],
                        'phone' => $user['phone'],
                        'state' => $user['state'],
                        'referral' => 22,

                    ],
                ];
            }

        }



        try {
            $userInput = collect($userInput);

            //if($this->output) $this->output->progressStart(count($userInput));
            foreach($userInput->chunk(1000) as $users){
                // sleep(1);
                foreach($users as $user){
                    $userCreated = User::create($user['user']);
                    $userCreated->person()->create($user['person']);
                }

                //  if($this->output) $this->output->progressAdvance();
            }
            return $this->status = true;


        } catch (QueryException $e) {
            $this->logError($e->getMessage());
        } catch (\PDOException $e) {
            $this->logError($e->getMessage());
        }

    }

	protected function logError($message) {
		Log::error('CSV Import Failed for ' . $this->file);
		Log::error($message);

		return $this->status = false;
	}

	/**
	 * This method will be starting this class from static point
	 * @param array $data
	 * @param $file
	 *
	 * @return static
	 */
	public static function insert(Csv $csv, $model, $file,$normalize = true,$output = false) {

		$obj = new static($csv, $model, $file,$normalize,$output);
		return $obj;
	}
}