<?php
/**
 * Created by PhpStorm.
 * User: team
 * Date: 7/17/19
 * Time: 4:22 PM
 */

namespace Satfish\Helpers;

use Illuminate\Pagination\Paginator;
use Satfish\CouponBatch;
use Satfish\Coupon;
use DB;

class CouponsSync
{

    private $hasMore = true;
    private $perPage = 20;
    private $pagination = [
        'starting_after' => '',
        'limit' => 20,
    ];

    private $lastId = false;
    private $brand = false;

    public function sync()
    {

    	//Empty table before starting
        DB::table('coupon_batch')->delete();

        //Loop all available brands to grab coupons
	    foreach ( config('satfish.brands') as $brand ) {
		    \Stripe\Stripe::setApiKey($brand['stripe_secret']);

		    $this->hasMore = true;
		    $this->brand = $brand;
		    $this->grabCoupons();
	    }

	    return true;
    }

    protected function grabCoupons($pagination = []) {
	    if($this->hasMore)
	    {
		    $coupons = \Stripe\Coupon::all($pagination);
		    $this->insertCoupons($coupons, $this->brand['slug']);
	    }

	    if($coupons->has_more)
	    {
		    $this->hasMore = true;
		    $this->grabCoupons(['starting_after' => $this->lastId,'limit' => $this->perPage]);
	    }

	    $this->hasMore = false;
    }

    public function insertCoupons($coupons, $brand)
    {

        foreach ($coupons->data as $coupon)
        {
            $discountType = 'amount';
            if(!empty($coupon->percent_off))
            {
                $discountType = 'percent';
            }

            $discount = $discountType."_off";
            $batchCouponInput = [
                'discount_type' => $discountType,
                'discount' => $coupon->{$discount},
                'use_count' => $coupon->max_redemptions ? $coupon->max_redemptions : 0,
                'is_disabled' => $coupon->valid,
                'product_ids' => [],
                'is_recurring' => ($coupon->duration == 'repeating')? 1:0,
                'duration' => $coupon->duration,
                'code' => $coupon->id,
                'brand' => $brand,
                'user_use_count' => $coupon->times_redeemed,
            ];

            $this->lastId = $coupon->id;
            CouponBatch::create($batchCouponInput);
        }

        return;
    }

}