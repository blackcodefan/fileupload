<?php

namespace Satfish\Helpers;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use Satfish\HotBites;
use Satfish\Layers;
use Satfish\Markers;
use Satfish\Region;
use Request;

class General {

	/**
	 * Method for getting extension for files
	 *
	 * @param $mime_type
	 *
	 * @return mixed
	 */
	public static function getExtension( $mime_type ) {
		$extensions = array(
			'image/jpeg' => 'jpeg',
			'image/jpg'  => 'jpg',
			'image/png'  => 'png'
		);

		// Add as many other Mime Types / File Extensions as you like
		return $extensions[ $mime_type ];
	}

	/**
	 * Organizing Layers order
	 *
	 * @param Collection $layers
	 * @param Markers|null $markers
	 * @param HotBites|null $hotbites
	 *
	 * @return array
	 */
	public static function orderLayers( Region $region, Collection $layers, Collection $markers = null, Collection $hotbites = null, Collection $buoys = null ) {
		$arrangedLayers = [];
		$layers         = $layers->keyBy( 'type.slug' );

		$layersOrder = config( 'satfish.layers' );

		//Sort Arrays based on order attribute
		uasort( $layersOrder, function ( $x, $y ) {
			$x['order'] = isset( $x['order'] ) ? $x['order'] : 1000;
			$y['order'] = isset( $y['order'] ) ? $y['order'] : 1000;

			return $x['order'] - $y['order'];
		} );

		//Arranging Arrays better
		foreach ( $layersOrder as $slug => $layerSettings ) {
			switch ( $slug ) {
				case 'lab_lay':
					if ( $markers && $markers->count() > 0 ) {
						$arrangedLayers[ $slug ] = $markers;
					}
					break;

				case 'hob_lay' :
					if ( $hotbites && $hotbites->count() > 0 ) {
						foreach ( $hotbites as $hotbite ) {
							$newSlug                      = $slug . $hotbite->time_slug;
							$arrangedLayers[ $newSlug ][] = $hotbite;
						}
					}

					break;

				case 'hob_list' :
					if ( $hotbites && $hotbites->count() > 0 ) {
						$arrangedLayers[ $slug ] = [ 'active' => false ];
					}

					break;

				case 'buoys' :
					if ( $buoys && $buoys->count() > 0 ) {
						$arrangedLayers[ $slug ] = $buoys;
					}

					break;

				case 'geo_lay' :
					$arrangedLayers[ $slug ] = [ 'active' => true ];
					break;


				case 'wnd_lay' :
					$arrangedLayers[ $slug ] = config( 'satfish.layers.' . $slug );
					break;

				default :
					if ( isset( $layers[ $slug ] ) ) {
						$arrangedLayers[ $slug ] = $layers[ $slug ];

						//if media is loaded
						if ( $layers[ $slug ]->relationLoaded( 'media' ) ) {
							$arrangedLayers[ $slug ]->image_url = $arrangedLayers[ $slug ]->full_image;
						}

					}
					break;

			}
		}

//		dd($arrangedLayers);
		return $arrangedLayers;
	}

	/**
	 * Wrapper for LayerBase for Path
	 *
	 * @param Layers $layer
	 * @param bool $regionId
	 *
	 * @return string
	 */
	public static function layerPath( $layer, $regionId = false ) {
		return storage_path( 'app/public/' . self::layerBase( $layer, $regionId ) );
	}

	/**
	 * Wrapper for LayerBase for URL
	 *
	 * @param Layers $layer
	 * @param bool $regionId
	 *
	 * @return string
	 */
	public static function layerUrl( $layer, $regionId = false ) {
		if ( self::s3Configured() ) {
			return Storage::url( self::layerBase( $layer, $regionId ) );
		}

		return asset( 'storage/' . self::layerBase( $layer, $regionId ) );
	}

	/**
	 * Wrapper for Tiles Url
	 *
	 * @param Layers $layer
	 * @param bool $regionId
	 *
	 * @return string
	 */
	public static function tilesUrl( $layer, $regionId = false ) {
		return self::layerUrl( $layer, $regionId ) . '/{z}/{x}/{y}.png';
	}

	/**
	 * Wrapper for Tiles Url
	 *
	 * @param Layers $layer
	 * @param bool $regionId
	 *
	 * @return string
	 */
	public static function fullImgUrl( $layer, $regionId = false ) {
		return self::layerUrl( $layer, $regionId ) . '/full.png';
	}

	/**
	 * Wrapper for LayerBase for URL
	 *
	 * @param Layers $layer
	 * @param bool $regionId
	 *
	 * @return string
	 */
	public static function kmlUrl( $layer, $regionId = false ) {
		if ( self::s3Configured() && Storage::exists( self::layerBase( $layer, $regionId ) . '/gj/' . $layer->id . '.js' ) ) {
			return Storage::url( self::layerBase( $layer, $regionId ) . '/gj/' . $layer->id . '.js' );
		}

		return self::tilesUrl( $layer, $regionId );
	}

	/**
	 * Generating proper structure for Tiled layers
	 *
	 * @param Layers $layer
	 * @param bool $regionId
	 *
	 * @return string
	 */
	public static function layerBase( $layer, $regionId = false ) {
		$regionId = $regionId ? $regionId : $layer->region->id;

		$path = 'layers' . '/' . $regionId . '/' . $layer->type->id;

		if ( $layer->history ) {
			$path .= '/' . $layer->created_at->format( 'ymdHi' );
		}

		return $path;
	}

	/**
	 * Arrange Layers config in such a way that is easily renderable on front menu
	 *
	 * @param array $menuItems
	 *
	 * @return array
	 */
	public static function menuArray( Array $menuItems ) {
		$rtrArr = [];

		foreach ( $menuItems as $slug => $item ) {
			if ( isset( $item['parent'] ) && $item['parent'] ) {
				$rtrArr[ $item['parent'] ]['children'][ $slug ] = $item;
			} else {
				$rtrArr[ $slug ] = $item;
			}
		}

		return $rtrArr;
	}

	/**
	 * Capturing individual attribute from layers config
	 *
	 * @param $attribute
	 * @param String $slug
	 *
	 * @return bool
	 */
	public static function getConfigAttribute( $attribute, String $slug ) {
		$layersConfig = config( 'satfish.layers' );
		if ( isset( $layersConfig[ $slug ][ $attribute ] ) ) {
			return $layersConfig[ $slug ][ $attribute ];
		}

		return false;
	}

	public static function getZoom( Region $region ) {
		$zoom = config( 'satfish.zoom' );

		if ( isset( $region->extra ) && $extra = $region->extra ) {
			$zoom = [
				'min'     => isset( $extra['min_zoom'] ) ? $extra['min_zoom'] : $zoom['min'],
				'max'     => isset( $extra['max_zoom'] ) ? $extra['max_zoom'] : $zoom['max'],
				'default' => isset( $extra['default_zoom'] ) ? $extra['default_zoom'] : $zoom['default']
			];
		}

		return $zoom;
	}

	public static function getB64Filename( $str ) {
		// $str should start with 'data:' (= 5 characters long!)
		$imgType = substr( $str, 5, strpos( $str, ';' ) - 5 );
		$ext     = 'jpg';
		switch ( $imgType ) {
			case 'image/png':
				$ext = 'png';
				break;
			case 'image/gif':
				$ext = 'gif';
				break;
			case 'image/jpeg':
			case 'image/jpg':
				$ext = 'jpg';
				break;
			case 'image/tiff':
				$ext = 'tiff';
				break;
			case 'image/svg+xml':
				$ext = 'svg';
				break;
			case 'image/webp':
				$ext = 'webp';
				break;

			case 'application/octet-stream':
			case 'application/vnd.google-earth.kml+xml':
			case 'application/xml':
			case 'application/kml':
			case 'text/kml':
			case 'text/xml':
				$ext = 'kml';
				break;
			default :
				$ext = 'jpg';
				break;
		}

		$fileName = str_random( 15 ) . '.' . $ext;

		return $fileName;
	}

	/**
	 * Return to url with a message
	 *
	 * @param $redirectTo url
	 * @param $msg redirect message to be displayed
	 *
	 * @return redirectUrl
	 */

	public static function redirectTo( $redirectTo, $msg = 'Request Processed Successfully', $error = false ) {
		if ( $error ) {
			if ( Request::ajax() ) {
				return response()->json( [ 'errors' => [ $msg ] ], 401 );
			}

		} else {
			session()->flash( 'success_msg', $msg );
			if ( Request::ajax() ) {
				return [ 'message' => $msg, 'redirectUrl' => $redirectTo ];
			}
		}

		switch ( $redirectTo ) {
			case 'back':
				if ( $error ) {
					return back()->withErrors( [ $msg ] );
				}

				return back();
				break;

			default:
				if ( $error ) {
					return redirect( $redirectTo )->withErrors( [ $msg ] );
				}

				return redirect( $redirectTo );

				break;
		}

	}

	public static function s3Configured() {
		return config( 'filesystems.disks.s3sf.bucket', false );
	}

	public static function DMStoDD( $dec ) {
		$dec = explode( '.', $dec );
		$dec = array_merge( $dec, [ 0, 0, 0 ] );

		// Converting DMS ( Degrees / minutes / seconds ) to decimal format
		return $dec[0] + ( ( ( $dec[1] * 60 ) + ( $dec[2] ) ) / 3600 );
	}

	public static function DDtoDMS( $dec ) {
		// Converts decimal format to DMS ( Degrees / minutes / seconds )
		$vars   = explode( ".", $dec );
		$vars   = array_merge( $vars, [ 0, 0 ] );
		$deg    = $vars[0];
		$tempma = "0." . $vars[1];

		$tempma = $tempma * 3600;
		$min    = floor( $tempma / 60 );
		$sec    = round( $tempma - ( $min * 60 ) );

//		return array("deg"=>$deg,"min"=>$min,"sec"=>$sec);
		return $deg . '.' . $min . '.' . $sec;
	}

	public static function layerThumbs( $obj ) {
		if ( $obj->media && $obj->media->first() && ( $obj->media->first()->mime_type == 'text/xml' || $obj->media->first()->mime_type == 'application/xml' ) ) {
			return 'https://placehold.it/90x70?text=KML';
		} else {
			return url( $obj->getFirstMediaUrl( 'layers', 'thumb' ) );
		}
	}


	/**
	 * Converting time to UTC standards
	 *
	 * @param $timeStamp
	 * @param $tz
	 *
	 * @return Carbon
	 */
	public static function timeZoneToUtc( $timeStamp = false, $tz = false ) {
		$tz        = empty( $tz ) ? config( 'satfish.timezone' ) : $tz;
		$timeStamp = empty( $timeStamp ) ? Carbon::now() : $timeStamp;

		return Carbon::parse( $timeStamp, $tz )->timezone( 'UTC' );
	}


	/*
	* This method will help us to parse Blade templates retreived from db
	*
	* @param $string (string) The conent text that needs to be parsed
	* @param $args (array) The array set which is used within blade template
	*
	* @return $content (string) The parsed string
	*/
	public static function parseBladeCode( $string, array $args = array() ) {

		$generated = \Blade::compileString( $string );

		ob_start();
		extract( $args, EXTR_SKIP );

		try {
			eval( '?>' . $generated );
			$content = ob_get_clean();

			return html_entity_decode( $content );
		} catch ( \Exception $e ) {
			ob_get_clean();
			throw $e;
			$content = ob_get_clean();

			return html_entity_decode( $content );
		}
	}

	/**
	 * Recursively removes null value items from associate array
	 *
	 * @param $data
	 */
	public static function cleanArray( $array ) {
		foreach ( $array as $key => &$value ) {
			if ( is_array( $value ) ) {
				$value = self::cleanArray( $value );
			}
			if ( empty( $value ) ) {
				unset( $array[ $key ] );
			}
		}

		return $array;
	}
}