<?php

namespace Satfish\Helpers;

use Spatie\MediaLibrary\PathGenerator\BasePathGenerator;
//use Spatie\MediaLibrary\PathGenerator\PathGenerator;
//use Spatie\MediaLibrary\Media;
use Spatie\MediaLibrary\Models\Media;



class MediaPath extends BasePathGenerator
{
	/**
	 * Get the path for the given media, relative to the root storage path.
	 *
	 * @param \Spatie\MediaLibrary\Models\Media $media
	 *
	 * @return string
	 */
	public function getPath(Media $media) : string {
		$dirname = $media->collection_name ? $media->collection_name : 'other';
		return "media/$dirname/$media->id/";
	}

	/**
	 * Get the path for conversions of the given media, relative to the root storage path.
	 *
	 * @param \Spatie\MediaLibrary\Models\Media $media
	 *
	 * @return string
	 */
	public function getPathForConversions(Media $media) : string {
		$dirname = $media->collection_name ? $media->collection_name : 'other';
		return "media/$dirname/$media->id/";
	}
}