<?php

namespace Satfish\Helpers;

use Spatie\MediaLibrary\UrlGenerator\BaseUrlGenerator;

class MediaUrls extends BaseUrlGenerator
{
	/**
	 * Get the url for the profile of a media item.
	 *
	 * @return string
	 */
	public function getUrl() : string
	{
		return url('/') . '/storage/' . $this->getPathRelativeToRoot();
	}
}