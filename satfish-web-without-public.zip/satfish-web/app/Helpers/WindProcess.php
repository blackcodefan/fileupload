<?php

namespace Satfish\Helpers;

use Carbon\Carbon;
use GuzzleHttp\TransferStats;
use Satfish\Region;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Satfish\Wind;
use Symfony\Component\Process\Process;

class WindProcess {

	/**
	 * Initialize process for processing ncep data
	 *
	 * @throws GuzzleException
	 */
	public function startProcess() {
		$regions     = Region::get();
		$currentTime = Carbon::now( 'UTC' )->minute(00)->second(00);

		//Go back upto 12 hours for searching grib data
		for ( $i = 0; $i < 12; $i ++ ) {
			if ( $this->gribExists( $currentTime ) ) {
				//Forecast hours
				$forecast = config( 'wind.forecast' );
				foreach ( $regions as $region ) {
					foreach ( $forecast as $forecastHour ) {
						$this->captureData( $region, $currentTime, $forecastHour );
					}

					//New data added, clean any previously held wind data
//					$winds = Wind::whereRegionId($region->id)->where('captured_at', '<', $currentTime->subDays(25))->delete();
					$winds = Wind::whereRegionId($region->id)->where('captured_at', '<', $currentTime)->delete();
//					dd($winds);
				}

				break;
			}

			$currentTime->subHour();
		}
	}

	/**
	 * Check if grib file exists in ncep servers for given hour
	 * @param $time
	 *
	 * @return bool
	 * @throws GuzzleException
	 */
	private function gribExists( $time ) {
		$resolution = config('wind.resolution');
		$baseUrl    = 'http://nomads.ncep.noaa.gov/cgi-bin/filter_gfs_' . $resolution . '.pl';

		$client = new Client();

		$res = $client->request( 'GET', $baseUrl, [
			'http_errors' => false,
			'query'       => $this->getParams($time),
		] );

		if ( $res->getStatusCode() == '200' ) {
			return true;
		}

		return false;
	}

	/**
	 *
	 * Start capturing data from ncep server and convert that data to json
	 * @param $region
	 * @param $time
	 * @param string $forecast
	 *
	 * @return bool
	 * @throws GuzzleException
	 */
	private function captureData( $region, $time, $forecast = '000' ) {
		$resolution = config('wind.resolution');
		$baseUrl    = 'http://nomads.ncep.noaa.gov/cgi-bin/filter_gfs_' . $resolution . '.pl';

		//Capture grib file
		$path = storage_path( 'app/gribs/' . $region->slug . '/' );
		if ( ! \File::exists( $path ) ) {
			\File::makeDirectory( $path, 0777, true );
		}

		$path .= $time->format( 'YmdH' ) . '.f' . $forecast . '.grib';

		//If we already have this file in system
		if ( \File::exists( $path ) ) {
//			return true;
			unlink( $path );
		}

		$file_path   = fopen( $path, 'w' );
		$client      = new Client();

		$res = $client->request( 'GET', $baseUrl, [
			'http_errors' => false,
			'query'       => $this->getParams($time, $forecast) + $this->normalizeCoordinates($region),
			'sink'        => $file_path,
			'on_stats' => function (TransferStats $stats) use (&$url) {
		    //@TODO: commenting this for now
				//\Log::info($stats->getEffectiveUri());

			}
		] );



		if ( $res->getStatusCode() == '200' ) {
			//Grib created, get json
			if ( $jsonData = $this->gribToJson( $path ) ) {
				$data = [
					'region_id'   => $region->id,
					'forecast'    => $forecast,
					'data'        => $jsonData,
					'captured_at' => $time,
					'created_at'  => ( clone $time )->addHours( (int) $forecast )
					                                ->setTimezone( config( 'app.timezone' ) )
				];

				$wind = Wind::whereRegionId($region->id)
				            ->where('captured_at', $time)
				            ->whereForecast($forecast)
				            ->get();

				if(!$wind->count()) {
					//Store wind data to database
					Wind::create( $data );
				}

			}

			return true;
		}

		unlink( $path );

		return false;
	}

	/**
	 * Convert Grib to JSON using command line
	 * @param $gribFile
	 *
	 * @return bool|mixed
	 */
	private function gribToJson( $gribFile ) {
		$gribConvertor = 'windserver/converter/bin/grib2json';
		$command       = $gribConvertor . ' --data --names --compact ' . $gribFile;
		$process       = new Process( $command, null, null, null, 120 );
		$process->run();

		if ( ! $process->isSuccessful() ) {
			return false;
//			throw new ProcessFailedException($process);
		}

		$jsonData = json_decode( $process->getOutput() );

		if ( json_last_error() == JSON_ERROR_NONE ) {
			return $jsonData;
		}

		return false;
	}

	/**
	 * Get params for ncep
	 * @param Carbon $time
	 *
	 * @return array
	 */
	private function getParams(Carbon $time, $forecast = '000') {
		return [
			'file'                  => 'gfs.t' . $time->format( 'H' ) . 'z.pgrb2.0p25.f' . $forecast,
			'lev_10_m_above_ground' => 'on',
			'var_UGRD'              => 'on',
			'var_VGRD'              => 'on',
			'subregion'             => 'on',
			'dir'                   => '/gfs.' . $time->format( 'Ymd/H' )
		];
	}

	/**
	 * Convert region coordinates to ncep friendly subregion
	 * @param Region $region
	 *
	 * @return array
	 */
	private function normalizeCoordinates(Region $region) {
		$coordinates = [
			'leftlon'   => $region->left_lng,
			'rightlon'  => $region->right_lng,
			'toplat'    => $region->upper_lat,
			'bottomlat' => $region->bottom_lat,
		];

		if ( $coordinates['leftlon'] > $coordinates['rightlon'] ) {
			$coordinates['leftlon']  = (int) ceil( $coordinates['leftlon'] ) + 1;
			$coordinates['rightlon'] = (int) floor( $coordinates['rightlon'] ) - 1;
		} else {
			$coordinates['leftlon']  = (int) floor( $coordinates['leftlon'] ) - 1;
			$coordinates['rightlon'] = (int) ceil( $coordinates['rightlon'] ) + 1;
		}

		if ( $coordinates['toplat'] > $coordinates['bottomlat'] ) {
			$coordinates['toplat']    = (int) ceil( $coordinates['toplat'] ) + 1;
			$coordinates['bottomlat'] = (int) floor( $coordinates['bottomlat'] ) - 1;
		} else {
			$coordinates['toplat']    = (int) floor( $coordinates['toplat'] ) - 1;
			$coordinates['bottomlat'] = (int) ceil( $coordinates['bottomlat'] ) + 1;
		}

		return $coordinates;
	}
}