<?php

namespace Satfish;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Satfish\Traits\BoundsFilter;
use Satfish\Traits\VueTableSearch;

class HotBites extends Model
{
    use VueTableSearch, BoundsFilter;

    protected $table = 'hot_bites';
    protected $fillable = ['date_time', 'category_id', 'title', 'lat', 'lng', 'type', 'note'];

    protected $filterJoins = ['categories' => ['name']];
	/**
	 * The attributes that should be mutated to dates.
	 *
	 * @var array
	 */
	protected $dates = [
		'date_time'
	];

	protected $appends = ['time_slug', 'marker_class'];

    /**
     * Get the comments for the blog post.
    */
    public function categories()
    {
        return $this->belongsTo('Satfish\Type','category_id','id');
    }

	/**
	 *
	 * Filter Results based on joined table data
	 *
	 * @param $query
	 * @param $table
	 * @param $column
	 * @param $dir
	 *
	 * @return mixed
	 */
	public function scopeSortJoin( $query, $table, $column, $dir ) {
		switch($table) {
			case 'categories' :
				$query
					->join( 'types as categories', 'categories.id', '=', $this->getTable() . '.category_id' );
				break;
		}


		return $query
			->select($this->getTable() .  '.*', $column)
			->orderBy(DB::raw($column), $dir);
	}

	/**
	 * Slug append based on time
	 *
	 * @return string
	 */
	public function getTimeSlugAttribute() {
		$hoursDiff = $this->date_time->diffInHours( Carbon::now());

		if($hoursDiff < 24) {
			return '_1';
		}  else if($hoursDiff >= 24 && $hoursDiff < 48) {
			return '_2';
		} else if($hoursDiff >= 48 && $hoursDiff < 72) {
			return '_3';
		} else if($hoursDiff >= 72 && $hoursDiff < 96) {
			return '_4';
		} else {
			return '_5';
		}
	}

	/**
	 * Class based on time & type of item
	 *
	 * @return string
	 */
	public function getMarkerClassAttribute() {
		$class = $this->type ? 'fishreport' : 'spotter';
		return $class . $this->time_slug . ' hotbite-icon stl-hob_lay' . $this->time_slug;
	}
}
