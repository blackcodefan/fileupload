<?php

namespace Satfish\Http\Controllers;

use Illuminate\Http\Request;
use Satfish\User;
use Satfish\UserTrial;
use Stripe\Charge;

class AdminController extends Controller
{

    public function index() {
        return view('admin');
    }
}
