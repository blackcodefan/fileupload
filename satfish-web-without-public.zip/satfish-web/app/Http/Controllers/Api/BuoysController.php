<?php

namespace Satfish\Http\Controllers\Api;

use Illuminate\Http\Request;
use Satfish\Buoy;
use Satfish\Http\Controllers\Controller;
use Satfish\Http\Resources\BuoysResource;

class BuoysController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return BuoysResource::collection(Buoy::vueTable());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return new BuoysResource(Buoy::findorfail($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    	$buoy = Buoy::findorfail($id);

	    $buoy->status = $request->status;

	    $buoy->save();

	    return new BuoysResource($buoy);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $buoy = Buoy::findorfail($id);
	    $buoy->status = false;
	    $buoy->save();
        return response()->json('Bouy disabled successfully');
    }

    /**
     * Remove the specified resources from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyAll(Request $request)
    {
	    dd(Buoy::whereIn('id',$request->ids)->update(['status' => false]));
        return response()->json('Markers deleted successfully', 200);
    }


}
