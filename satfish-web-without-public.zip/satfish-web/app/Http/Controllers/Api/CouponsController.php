<?php

namespace Satfish\Http\Controllers\Api;
use Satfish\CouponBatch;
use Satfish\Helpers\Brand;
use Satfish\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Satfish\Http\Requests\CouponRequest;
use Satfish\Coupon;
use Stripe\Plan;
use Satfish\Http\Resources\CouponBatchResource;
use Satfish\Http\Resources\CouponResource;

class CouponsController extends Controller
{
    public function index(Request $request){
        return CouponResource::collection(CouponBatch::vueTable());
    }


    public function syncCoupons()
    {
//        \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
        \Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));
        $coupons = \Stripe\Coupon::all();
    }

    public function store(CouponRequest $request){

        \Stripe\Stripe::setApiKey(Brand::getDetails($request->brand, 'stripe_secret'));

        $type = $request->type."_off";
        $couponInputStripe = [
            'duration' => $request->duration,
            'id' => !empty($request->code)? $request->code: $this->generateRandomString(6),
            $type => $request->discount,
        ];

        if($request->type == 'amount'){
            $couponInputStripe['currency'] = 'USD';
        }
        if($request->has('usage')){
            $couponInputStripe['max_redemptions'] = $request->usage;
        }

        $coupon = \Stripe\Coupon::create($couponInputStripe);

        $batchCouponInput = [
            'discount_type' => $request->type,
            'discount' => $request->discount,
            'use_count' => $request->usage,
            'is_disabled' => $request->is_disabled,
            'product_ids' => [$request->plans['id']],
            'is_recurring' => 0,
            'duration' => $request->duration,

        ];

        $couponInput = [
            'code' =>$request->code,
        ];

        $batch = CouponBatch::create($batchCouponInput);
        $coupon = $batch->coupon()->create($couponInput);
        return new CouponResource(Coupon::with('batch')->where('id',$coupon->id)->first());

    }

    public function update(Request $request,$id){
		//@TODO: Any action on local batch must be updated to Stripe
        $coupon = CouponBatch::with('coupon')->findOrFail($id);
        $coupon->is_disabled = !$coupon->is_disabled;
        $coupon->save();
        return response()->json(['message'=> 'Updated successfully']);

    }

    public  function generateRandomString($length = 20) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function destroy(Request $id){
        $coupon = Coupon::findOrFail($id);
        $stripeCoupon = \Stripe\Coupon::retrieve($coupon->code);
        $stripeCoupon->delete();
        $coupon->delete();
        return response()->json('Hot bite deleted successfully');
    }
}
