<?php

namespace Satfish\Http\Controllers\Api;
use ParseCsv\Csv;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Satfish\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class CsvController extends Controller
{
	public function process(Request $request) {
		$fileName = $request->entity . '-' . Carbon::now(config('app.timezone'))->timestamp . '.csv';
		$stored = $request->file('csvFile')->storeAs('csv', $fileName);

		if($stored) {
			return ['message' => 'File stored successfully for processing in next 10 minutes'];
		}
	}

	public function reProcess(Request $request){
        $file = basename($request->file);

        Storage::move($request->file, 'csv/'.$file);
    }


	public function csvFiles(){

	    //success files
        $csv = [];
        $files = Storage::files( 'trash/success' );
        if($files){
            foreach ( $files as $key=>$file ) {

                $csv[] = [
                    'name' => basename($file),
                    'data' => Storage::get($file),
                    'status' => 'success',
                ];
            }
        }


        //error files
        $files = Storage::files( 'trash/csv' );
        if($files){
            foreach ( $files as $key=>$file ) {

                $csv[] = [
                    'name' => $file,
                    'data' => Storage::get($file),
                    'status' => 'error',
                ];
            }

        }

        //pending files
        $files = Storage::files( 'csv' );
        if($files){
            foreach ( $files as $key=>$file ) {

                $csv[] = [
                    'name' => $file,
                    'data' => Storage::get($file),
                    'status' => 'pending',
                ];
            }
        }

        //$csv = $this->paginate($csv,5);
        return response()->json($csv,200);

    }

//    public function paginate($items,$perPage)
//    {
//        $pageStart = \Request::get('page', 1);
//        // Start displaying items from this number;
//        $offSet = ($pageStart * $perPage) - $perPage;
//
//        // Get only the items you need using array_slice
//        $itemsForCurrentPage = array_slice($items, $offSet, $perPage, true);
//
//        return new LengthAwarePaginator($itemsForCurrentPage, count($items), $perPage,Paginator::resolveCurrentPage(), array('path' => Paginator::resolveCurrentPath()));
//    }


    protected function fileToModel($file) {
        $dir = explode('/', $file);

        if(isset($dir[1])) {
            $entity = explode('-', $dir[1]);

            return in_array($entity[0], $this->allowedEntities) ? $entity[0] : false;
        }

        return false;
    }

}
