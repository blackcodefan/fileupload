<?php

namespace Satfish\Http\Controllers\Api;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Satfish\Http\Requests\HotBitesRequest;
use Satfish\Http\Resources\HotBites as HotBitesResource;
use Satfish\Http\Controllers\Controller;
use Satfish\HotBites;
use Satfish\Helpers\General;

class HotBitesController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return HotBitesResource::collection(HotBites::with(['categories'])->vueTable());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(HotBitesRequest $request)
    {
        $data = [
            'category_id' => $request->get('category')['id'],
            'title'  => $request->get('title'),
            'type'  => $request->type ? $request->type : 0,
            'lat'      => $request->get('lat'),
            'lng'      => $request->get('lng'),
            'note'     => $request->get('note'),
            'date_time' => General::timeZoneToUtc($request->date_time),

        ];

	    return new HotBitesResource(HotBites::create($data));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
	    return new HotBitesResource(HotBites::with('categories')->findorfail($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(HotBitesRequest $request, $id)
    {
        $hotbite = HotBites::findOrFail($id);

	    $data = [
		    'category_id' => $request->get('category')['id'],
		    'title'     => $request->get('title'),
		    'type'        => $request->type ? $request->type : 0,
		    'lat'         => $request->get('lat'),
		    'lng'         => $request->get('lng'),
		    'note'        => $request->get('note'),
		    'date_time'   => General::timeZoneToUtc($request->date_time),
	    ];

	    $hotbite->update($data);
	    return new HotBitesResource($hotbite);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        HotBites::destroy($id);
        return response()->json('Hot bite deleted successfully');
    }

    /**
     * Remove the specified resources from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyAll(Request $request)
    {
        HotBites::whereIn('id',$request->ids)->delete();
        return response()->json('Hotbites deleted successfully', 200);
    }


}
