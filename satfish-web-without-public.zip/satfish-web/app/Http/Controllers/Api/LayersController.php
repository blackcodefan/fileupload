<?php

namespace Satfish\Http\Controllers\Api;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Satfish\Helpers\General;
use Satfish\Http\Controllers\Controller;

use Satfish\Http\Requests\LayerRequest;
use Satfish\Http\Resources\LayersResource;
use Satfish\Layers;
use Satfish\Type;
use Satfish\Region;
use File;
use Satfish\Http\Resources\RegionsResource;

class LayersController extends Controller {
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index( Request $request ) {

		return LayersResource::collection( Layers::with( 'region', 'type' )->vueTable() );
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request $request
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function store( LayerRequest $request ) {

		$data = [
			'region_id'  => $request->region['id'],
			'type_id'    => $request->type['id'],
			'status'     => $request->status,
			'temp'     => $request->temp_switch ? $request->temp : null,
			'tiled'      => $request->tiled,
			'created_at' => General::timeZoneToUtc($request->created_at),
		];

		$layer = new Layers( $data );

		if ( $request->media) {
			$image = $request->get( 'media' );
			$layer->addMediaFromBase64( $image )
			      ->usingFileName( General::getB64Filename( $request->get( 'media' ) ) )
			      ->toMediaCollection( 'layers' );
		}

		$layer->save();

		return new LayersResource( $layer );
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int $id
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function show( $id ) {
		return new LayersResource( Layers::with( 'region', 'type', 'media' )->findorfail( $id ) );
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request $request
	 * @param  int $id
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function update( LayerRequest $request, $id ) {
		$layer = Layers::with( 'region', 'type', 'media' )->findorfail( $id );

		$data = [
			'region_id'  => $request->region['id'],
			'type_id'    => $request->type['id'],
			'status'     => $request->status,
			'temp'    => $request->temp_switch ?  $request->temp : null,
			'tiled'      => $request->tiled,
			'created_at' => General::timeZoneToUtc($request->created_at)
		];


		$layer->update( $data );

		//Delete Existing Media if we got new media or layer source is changed to directory
		if ( $layer->media->count() && ( ( $request->media
		                                   && ! is_array( $request->media ) ) || $request->source == 'directory' )
		) {
			$layer->clearMediaCollection( 'layers' );
		}

		if ( $request->has( 'media' ) && $request->media && ! is_array( $request->media ) ) {

			//if we got media
			$image = $request->get( 'media' );

			//Get filename
			$layer->addMediaFromBase64( $image )
			      ->sanitizingFileName( function ( $fileName ) {
				      return strtolower( str_replace( [ '#', '/', '\\', ' ' ], '-', $fileName ) );
			      } )
			      ->toMediaCollection( 'layers' );
		}

		return new LayersResource( $layer );
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int $id
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function destroy( $id ) {
		Layers::destroy( $id );

		return response()->json( 'Layer deleted successfully' );
	}

    /**
     * Remove the specified resources from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyAll(Request $request)
    {
        Layers::whereIn('id',$request->ids)->delete();
        return response()->json('Layers deleted successfully', 200);
    }


	public function history( $region, $layer ) {
//		$layers = Layers::whereRegionId($region)->whereTypeId($layer)->get();
		$timeNow = Carbon::now(config('satfish.timezone'));
		return LayersResource::collection(
				Layers::with( 'media', 'region', 'type')
                ->whereRegionId( $region )
				->whereStatus(true)
				->whereTiled(true)
				->where('created_at', '>', $timeNow->subDays(7))
//				->limit(30)
				->orderBy('created_at', 'asc')
                ->whereTypeId( $layer )->get() );
	}
}
