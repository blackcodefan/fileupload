<?php

namespace Satfish\Http\Controllers\Api;

use Illuminate\Http\Request;
use Satfish\Http\Requests\MarkersRequest;
use Satfish\Http\Controllers\Controller;
use Satfish\Http\Resources\MarkersResource;
use Satfish\Markers;

class MarkersController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return MarkersResource::collection(Markers::vueTable());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MarkersRequest $request)
    {
        $data = [
            'name'      => $request->get('name'),
            'lat'       => $request->get('lat'),
            'lng'       => $request->get('lng'),
	        'extra'     => [
	        	'style'     =>  $request->get('style'),
	        	'icon'      =>  $request->get('icon'),
	        	'cssClass'  =>  $request->get('cssClass'),
	        	'font_size'  =>  $request->get('fontSize'),
	        	'zoom_ctrl'  =>  $request->get('zoomCtrl'),
	        	'content'  =>  $request->get('content'),
	        ]
        ];

        $marker = Markers::create($data);
        return new MarkersResource($marker);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return new MarkersResource(Markers::findorfail($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(MarkersRequest $request, $id)
    {
        $marker = Markers::findOrFail($id);
	    $data = [
		    'name'      => $request->get('name'),
		    'lat'       => $request->get('lat'),
		    'lng'       => $request->get('lng'),
		    'extra'     => [
			    'style'     =>  $request->get('style'),
			    'icon'      =>  $request->get('icon'),
			    'cssClass'  =>  $request->get('cssClass'),
			    'font_size'  =>  $request->get('fontSize'),
			    'zoom_ctrl'  =>  $request->get('zoomCtrl'),
			    'content'  =>  $request->get('content'),
		    ]
	    ];

	    $marker->update($data);

        return new MarkersResource($marker);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Markers::destroy($id);
        return response()->json('Marker deleted successfully');
    }

    /**
     * Remove the specified resources from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyAll(Request $request)
    {
        Markers::whereIn('id',$request->ids)->delete();
        return response()->json('Markers deleted successfully', 200);
    }


}
