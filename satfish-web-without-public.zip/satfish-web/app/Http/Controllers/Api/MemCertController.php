<?php

namespace Satfish\Http\Controllers\Api;

use Satfish\Http\Requests\MemCertRequest;
use Satfish\Http\Resources\MemCertResource;
use Satfish\MemCert;
use Illuminate\Http\Request;
use Satfish\Http\Controllers\Controller;

class MemCertController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return MemCertResource::collection(MemCert::vueTable());
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return new MemCertResource(MemCert::findorfail($id));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(MemCertRequest $request, $id)
    {
        $memCert = MemCert::findorfail($id);
        $data = $request->all();
        $data['grace_period_unit'] = $data['grace_period_unit']['code'];
        $memCert->update($data);
        return new MemCertResource($memCert);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MemCertRequest $request)
    {
        $data = $request->all();
        $data['grace_period_unit'] = $data['grace_period_unit']['code'];
        return new MemCertResource(MemCert::create($data));
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $memcert = MemCert::findorfail($id);
        $memcert->delete();
        return response()->json('Membership certificate deleted successfully');
    }
}
