<?php

namespace Satfish\Http\Controllers\Api;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Satfish\Http\Controllers\Controller;
use Satfish\Http\Requests\RegionsRequest;
use Satfish\Http\Resources\RegionsResource;
use Satfish\Region;
use Satfish\Type;
use File;
use DB;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class RegionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return RegionsResource::collection(Region::vueTable());
    }

    public function getFrontEnd() {
	    return RegionsResource::collection(Region::activeBrand()->active()->get());
    }


    public function regionList() {
        return RegionsResource::collection(Region::all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RegionsRequest $request)
    {
        DB::beginTransaction();
        try{
	        $data = $request->all();
	        $data['brand'] = $request->brand['slug'];
            $region =  new RegionsResource(Region::create($data));

            $input = [
                'server' => ($data['server'])? 1:0,
                'timezone' => $data['timezone'],
                'station_id' => ($data['server'])? $request->station_id:'',
                'isdst' => $data['isdst'],
                'height_unit' => $data['height_unit'],
                'frequency' => $data['frequency'],
                'location_id' => !($data['server'])? $request->location_id:''
            ];

            $region->options()->create($input);
            DB::commit();
        }catch(\Exception $e){
            DB::rollBack();
        }

        return new RegionsResource($region);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        return new RegionsResource(Region::with('layers.media','options')->findorfail($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RegionsRequest $request, $id)
    {

        $region = Region::findOrFail($id);
        $data = $request->all();
        $data['brand'] = $request->brand['slug'];

        $region->update($data);
        $input = [
            'server' => ($data['server'])? 1:0,
            'timezone' => $data['timezone'],
            'station_id' => ($data['server'])? $request->station_id:'',
            'isdst' => $data['isdst'],
            'height_unit' => $data['height_unit'],
            'frequency' => $data['frequency'],
            'location_id' => !($data['server'])? $request->location_id:''
        ];
        $region->options()->update($input);
        return new RegionsResource($region);
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Region::destroy($id);
        return response()->json('Region deleted successfully',200);
    }


    /**
     * Remove the specified resources from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyAll(Request $request)
    {
        Region::whereIn('id',$request->ids)->delete();
        return response()->json(['message' => 'Regions deleted successfully']);
    }


    public function wind($id) {
	    $region = Region::findorfail($id);
		$lastDay = Carbon::now( config('satfish.timezone') )->minute(00)->second(00)->subDay();
		$nextDay = Carbon::now( config('satfish.timezone') )->minute(00)->second(00)->addDays(7);
//	    return $region->wind()->whereForecast(0)->first()->data;
//	    dd($region->wind()->whereBetween('created_at', [$lastDay, $nextDay])->orderBy('created_at')->get());
	    return $region->wind()->whereBetween('created_at', [$lastDay, $nextDay])->orderBy('created_at')->get();
    }
}
