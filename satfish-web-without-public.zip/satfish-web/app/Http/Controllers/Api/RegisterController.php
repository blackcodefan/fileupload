<?php

namespace Satfish\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Satfish\Helpers\Brand;
use Satfish\Http\Requests\UserRequest;
use Satfish\User;
use Satfish\Http\Controllers\Controller;
use Stripe\Plan;
use Satfish\Role;

class RegisterController extends Controller
{
    public function store(Request $request){

        $name     = $request->get('name');
        $email    = $request->get('email');
        $password = $request->get('password');
        $clientId = $request->client_id;
        $clientSecret = $request->client_secret;

        //default role
        $role = 'register';
        $role = Role::whereName($role)->first();

        if(!$role)
        {
            return response()->json(['errors' => $role. "doesn't exist in the system"]);
        }
//        \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
        \Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));
        $data = [
            'plans' => Plan::all()->data,
        ];

        // save new user
        $user = \Satfish\User::create([
            'name'     => $name,
            'email'    => $email,
            'password' => bcrypt($password),
        ]);




        $user->attachRole($role);

        $request->request->add([
            'grant_type'    => 'password',
            'username'      => $email,
            'password'      => $password,
            // 'scope'         => implode(" ",(array_keys(config('scopes.'.$role->name)))),
            'scope'         => null,
            'client_id'     => $client->id,
            'client_secret' => $client->secret,
        ]);

        // Fire off the internal request. 
        $token = Request::create(
            'oauth/token',
            'POST'
        );

        return \Route::dispatch($token);
    }

}
