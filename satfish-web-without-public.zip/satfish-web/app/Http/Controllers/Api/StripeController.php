<?php

namespace Satfish\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Satfish\Helpers\Brand;
use Satfish\Helpers\Notifier;
use Satfish\Http\Controllers\Controller;
use Satfish\Http\Resources\CardResource;
use Satfish\Http\Resources\InvoicesResource;
use Satfish\Http\Resources\TrialsResource;
use Satfish\Http\Resources\UserResource;
use Satfish\Http\Requests\StripeRequest;

use Satfish\User;
use Carbon\Carbon;
use Stripe\Plan;

class StripeController extends Controller
{
	public function getInvoices(Request $request,$uid = false) {


		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);

		//If User got customer ID associated
		if($currentUser->stripe_id) {
		    $page = $request->has('page')? $request->page: 1;
		    $invoices = [];
//		    dd($currentUser->invoicesIncludingPending());
//			return New Paginator($currentUser->invoicesIncludingPending()->toArray(),10,$page);
			foreach($currentUser->invoicesIncludingPending() as $invoice) {
//				dd($invoice->id);
				$invoices[] = (object) [
					'id'        =>  $invoice->id,
					'number'        =>  $invoice->number,
					'amount_due'        =>  $invoice->amount_due,
					'amount_paid'        =>  $invoice->amount_paid,
					'amount_remaining'        =>  $invoice->amount_remaining,
					'application_fee'        =>  $invoice->application_fee,
					'charge'        =>  $invoice->charge,
					'closed'        =>  $invoice->closed,
					'created'        =>  $invoice->created,
					'created'        =>  $invoice->created,
					'date'        =>  $invoice->date,
					'due_date'        =>  $invoice->due_date,
					'invoice_pdf'        =>  $invoice->invoice_pdf,
					'paid'        =>  $invoice->paid,
					'period_start'        =>  $invoice->period_start,
					'period_end'        =>  $invoice->period_end,
					'receipt_number'        =>  $invoice->receipt_number,
					'status'        =>  $invoice->status,
					'subscription'        =>  $invoice->lines->data[0],
				];

			}

			return New Paginator($invoices,10,$page);
		}

		return response('No Data Available', 204);
	}

	public function getCards($uid = false) {
		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);

		//If User got customer ID associated
		if($currentUser->stripe_id) {
			return new CardResource($currentUser->defaultCard(), ['name' => $currentUser->card_name]);
		}

		return response('No Data Available', 204);
	}





    public function updateCard(Request $request, $uid = false) {

	    $data = $request->all();
		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::findorfail($uid);
		}

	    $currentUser::setStripeKey($currentUser->branded['stripe_secret']);

		if($currentUser->stripe_id) {
			$currentUser->updateCard($request->token);

			$currentUser->update(['card_name' => $data['name']]);

            if($currentUser->stripe_id) {
                return new CardResource($currentUser->defaultCard(), ['name' => $currentUser->card_name]);
            }

			return response('Card Has Been updated Successfully', 200);
		}

		return response('Card Update Failed', 204);
	}

	public function getActiveSubscription(Request $request,$uid = false) {



	    if(!$uid)
        {
            $currentUser = Auth::user();
            $uid = $currentUser->id;
        }


		//If User is super admin and we have a user id
		if($uid || in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);

		if($currentUser->stripe_id) {

		    $with[] = 'activeSubscription';

			//return $currentUser->subscriptions->first()->asStripeSubscription();
		}

        $with[] = 'activeTrial';
		return  new UserResource(User::with($with)->findOrFail($uid));


	}

	public function cancelSubscription($uid = false) {
		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);

		if($currentUser->stripe_id) {
			$currentUser->subscriptions->first()->cancel();
			$subscription =  $currentUser->subscriptions->first()->asStripeSubscription();

			Notifier::notify('membership.cancel',['subscription' => $subscription,'user' => $currentUser]);
			return $subscription;
		}
	}

	public function resumeSubscription($uid = false) {
		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);

		if($currentUser->stripe_id) {
			$currentUser->subscriptions->first()->resume();
			return $currentUser->subscriptions->first()->asStripeSubscription();
		}
	}

	public function renewSubscription(StripeRequest $request, $uid = false) {

		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::with('person')->findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);

//		if($currentUser->stripe_id) {
        $data = $request->all();

		// check if user has a trial

        $anchor = false;
        $trialEndDate = false;

        if($activeTrial = $currentUser->activeTrial)
        {

//            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            \Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));
            $plan = Plan::retrieve($data['plan']);
            // check if trial is greater than current plan

            $planDate = Carbon::now()->modify("$plan->interval_count  $plan->interval");

            // check if planDate is not less than trial period


            if(!$planDate->gt($activeTrial->valid_to))
            {
                return response()->json(["errors" => "Trial period is greater than choosed plan date"],401);
            }

            $addDays = $activeTrial->valid_to->diffInDays(Carbon::now());
            if($addDays > 0)
            {
                $anchor = Carbon::now()->addDay($addDays);
	            $trialEndDate = $activeTrial->valid_to;
            }


        }

        //If user got any active trial
		if($currentUser->trial_ends_at && $currentUser->trial_ends_at > Carbon::now())
		{

			\Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));
			$plan = Plan::retrieve($data['plan']);
			// check if trial is greater than current plan

			$planDate = Carbon::now()->modify("$plan->interval_count  $plan->interval");

			// check if planDate is not less than trial period


			if(!$planDate->gt($currentUser->trial_ends_at))
			{
				return response()->json(["errors" => "Trial period is greater than choosed plan date"],401);
			}

			$addDays = $currentUser->trial_ends_at->diffInDays(Carbon::now());
			if($addDays > 0)
			{
				$anchor = Carbon::now()->addDay($addDays);
				$trialEndDate = $currentUser->trial_ends_at;
			}

		}

        $subscription = $currentUser->newSubscription(config('satfish.stripeDefault.name'),$data['plan']);

        if($anchor && $trialEndDate)
        {
//            $subscription = $subscription->anchorBillingCycleOn($anchor);
            $subscription = $subscription->trialUntil($trialEndDate);
        }

        if(!empty($data['couponCode']))
        {
            $subscription = $subscription->withCoupon($data['couponCode']);
        }

        $currentUser->update(['card_name' => $data['name']]);

        $subscription = $subscription->create($data['token'], [
            'email' => $currentUser->email,
            'name' =>  $currentUser->fullname,
            'phone' => ($currentUser->person)? $currentUser->person->phone:null,
        ]);


        $invoice = $currentUser->invoices()->first();
        Notifier::notify('membership.receipt',['subscription' => $subscription , 'invoice' => $invoice, 'user' => $currentUser ],$currentUser);
        return new UserResource(User::with(['activeTrial','activeSubscription'])->findOrFail($currentUser->id));

//		}
	}

	/**
	 * Show the form for creating a new resource.
	 * @return Response
	 */
	public function getPlans(Request $request, $uid = false) {

		$currentUser = Auth::user();
		//If User is super admin and we have a user id
		if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
			$currentUser = User::with('person')->findorfail($uid);
		}

		$currentUser::setStripeKey($currentUser->branded['stripe_secret']);
		\Stripe\Stripe::setApiKey($currentUser->branded['stripe_secret']);

		return response()->json([
			'plans' => Plan::all()->data,
			'key'   => $currentUser->branded['stripe_key']
		]);
	}

	public function plans(Request $request) {

		$planSet = [];
		foreach(config('satfish.brands') as $brand) {
			\Stripe\Stripe::setApiKey($brand['stripe_secret']);
			foreach (Plan::all()->data as  $plan) {
				$plan['name'] = $brand['name'] . ' - ' . $plan->name;
				$planSet[] = $plan;
			}
		}

		return response()->json($planSet);
	}

}