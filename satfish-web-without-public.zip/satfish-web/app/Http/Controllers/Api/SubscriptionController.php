<?php

namespace Satfish\Http\Controllers\Api;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Satfish\Helpers\Brand;
use Satfish\Helpers\General;
use Satfish\Http\Resources\SubscriptionsResource;
use Satfish\Http\Resources\UserResource;
use Satfish\Http\Requests\StripeRequest;
use Satfish\Refund;
use Satfish\User;
use Satfish\UserTrial;
use Stripe\Plan;
use Satfish\Http\Controllers\Controller;

class SubscriptionController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $user = $request->user ? User::find($request->user) : false;
        return SubscriptionsResource::collection($user->subscriptions()->vueTable());
    }

    public function invoices(Request $request){

        $user = $request->user ? User::find($request->user) : false;
	    $user::setStripeKey($user->branded['stripe_secret']);
        $invoices = $user->invoices();
        foreach($invoices as $invoice){

            $invoiceArr[] = [
                'stripe_plan' => $invoice->lines['data'][0]['plan']->name,
                'invoice_id'  => $invoice->id,
                'number'  => $invoice->number,
                'id'  => $invoice->id,
                'total' => $invoice->total(),
                'status' => $invoice->status,
                'created_at' => $invoice->date()->toFormattedDateString(),
            ];

        }
        return response()->json(['data' => $invoiceArr],200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function plans(Request $request) {
        \Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));

        return response()->json([
        	'plans' => Plan::all()->data,
	        'key'   => Brand::active('stripe_key')
        ]);
    }

    public function show(Request $request){
        $user = $request->user ? User::with('subscriptions')->find($request->user) : false;
	    $user::setStripeKey($user->branded['stripe_secret']);
        return SubscriptionsResource::collection($user->subscriptions);
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(StripeRequest $request)
    {
        $user = User::findorfail($request->user);
	    $user::setStripeKey($user->branded['stripe_secret']);

        if(!empty($request->get('coupon'))){
            if(!$this->isCouponValid($request->coupon) OR $this->checkLocalValidity($request->coupon,$request->plan)){
                return response()->json(['error' => 'Coupon Code not valid'],422);
            }
            $user->newSubscription(config('satfish.stripeDefault.name'), $request->plan)->withCoupon($request->coupon)->create($request->token);
        }else{
            $user->newSubscription(config('satfish.stripeDefault.name'), $request->plan)->create($request->token);
        }

        $user->update(['card_name' => $request->get('name')]);

        return new UserResource($user);
    }


    /**
     * check if coupon is not disabled and is according to the selected plan
     * @param $coupon
     * @return bool
     */
    public function checkLocalValidity($coupon){
        $coupon = Coupon::with('batch')->where('code',$coupon)->first();
        if($coupon){
            if($coupon->batch->is_disabled){
                return false;
            }

            if(!empty($coupon->batch->product_ids) AND !in_array($coupon->batch->product_ids)){
                return false;
            }
            return true;
        }
        return false;
    }

    private function isCouponValid($coupon)
    {
//        \Stripe\Stripe::setApiKey(\Config::get('services.stripe.secret'));
        \Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));

        try {
            $coupon = \Stripe\Coupon::retrieve($coupon);

            return $coupon->valid;
        } catch(\Exception $e) {
            return false;
        }
    }


    /**
     * Cancel User subscription
     */
    public function cancelSubscription(Request $request, $user_id){
        $msg = 'Subscription cancelled successfully';
        $user = User::findOrFail($user_id);

        // only fetching active subscriptions
        if($user->subscriptions()->whereNull('ends_at')->count()){
	        $user::setStripeKey($user->branded['stripe_secret']);
        	if($request->now) {
//		        $user->subscription(config('satfish.stripeDefault.name'), $request->plan)->cancelNow();
                $subscription = $user->subscriptions()->whereId($request->sub_id)->first();
                $subscription->cancel();
                $subscription->cancelNow();

	        } else {
		        $user->subscriptions()->whereId($request->sub_id)->first()->cancel();
	        }
            return SubscriptionsResource::collection($user->subscriptions);
        }

        $msg = "User has not been subscribed to any subscription yet";
        return response()->json(['error' => $msg],404);



    }

    public function subscribed(Request $request){
        $user = User::findOrFail($request->user);
	    $user::setStripeKey($user->branded['stripe_secret']);
        return $user->subscribed(config('satfish.stripeDefault.name')) ? SubscriptionsResource::collection($user->subscriptions): response()->json(['error' => 'No active subscription found'],404);
    }

    public function activateTrial(Request $request) {

    	$data = $request->all();
		//Current User
	    $assigneeId = Auth::user()->id;

	    //If Trial is within Active Range, make it activated right away
	    if(General::timeZoneToUtc($data['startDate']) < Carbon::now()
	    && General::timeZoneToUtc($data['endDate']) > Carbon::now()) {
	    	$user = User::find($data['userId']);
	    	$user->trial_ends_at = General::timeZoneToUtc($data['endDate']);
	    	$user->save();
	    }


	    return UserTrial::create([
	    	'assigned_by' => $assigneeId,
	    	'user_id' => $data['userId'],
		    'status'  => 1,
		    'comments'  => $data['comments'],
		    'valid_from' => General::timeZoneToUtc($data['startDate']),
		    'valid_to' => General::timeZoneToUtc($data['endDate']),
	    ]);
    }

    public function getTrials($userId) {
		return User::findorfail($userId)->trials;
    }

	public function cancelTrials($userId) {
    	$trial = UserTrial::find($userId);

		$trial->status = false;

		$trial->save();

		return $trial;
	}

	public function refundInvoice(Request $request) {
		$data = $request->all();
    	$user = User::findorfail($data['userId']);

		$user::setStripeKey($user->branded['stripe_secret']);
		$user->refundInvoice($data);

		return response()->json(['message' => 'Invoice has been refunded successfully']);
	}

	public function getRefunds($invoice_id) {
		return Refund::whereInvoiceId($invoice_id)->get();
	}
}
