<?php

namespace Satfish\Http\Controllers\Api;

use Satfish\Http\Resources\TrialsResource;
use Satfish\UserTrial;
use Illuminate\Http\Request;
use Satfish\Http\Controllers\Controller;

class TrialsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id = false)
    {
    	if($id) {
			return TrialsResource::collection(UserTrial::with( 'assignee', 'certificate')->whereUserId($id)->vueTable());
	    }

        return TrialsResource::collection(UserTrial::with('user', 'assignee', 'certificate')->vueTable());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \Satfish\UserTrial  $userTrial
     * @return \Illuminate\Http\Response
     */
    public function show(UserTrial $userTrial)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Satfish\UserTrial  $userTrial
     * @return \Illuminate\Http\Response
     */
    public function edit(UserTrial $userTrial)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Satfish\UserTrial  $userTrial
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserTrial $userTrial)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Satfish\UserTrial  $userTrial
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserTrial $userTrial)
    {
        //
    }
}
