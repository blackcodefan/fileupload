<?php

namespace Satfish\Http\Controllers\Api;

use Illuminate\Http\Request;
use Satfish\Http\Controllers\Controller;
use Satfish\Http\Requests\TypesRequest;
use Satfish\Http\Resources\TypesResource;
use Satfish\Type;

class TypesController extends Controller
{
    public function index(Request $request)
    {
        return TypesResource::collection(Type::with('parent')->vueTable());
    }

    public function show(Request $request, $id)
    {
        $types = new Type();
        if ($request->has('with')) {
            $with = explode(",", $request->get('with'));
            $types = $types->with($with);
        }
        return new TypesResource($types->with('parent')->findOrFail($id));
    }

    public function getchildren(Request $request,$slug = false){

        if($slug){
            $parent = Type::whereSlug($slug)->first();
            if($parent){
                return TypesResource::collection($parent->children()->get());
            }
        }else{
            return TypesResource::collection(Type::whereNull('parent_id')->get());
        }

        
        //@TODO send json response not found any children
        return '';
         

    }

    public function store(TypesRequest $request)
    {
        $data = [
            'name' => $request->get('name'),
            'slug' => $request->get('slug'),
            'status' => ($request->has('status')) ? $request->get('status') : 1,
        ];

        if ($request->has('parent') && $request->parent) {
            $parent_id = is_numeric($request->parent) ? $request->parent : $request->parent['id'];
            $parent = Type::findOrFail($parent_id);
            $data['parent_id'] = $parent->id;
            //@TODO:: baum is not working right now due to some issue.. so directly inserted parent id value


            $type = Type::create($data);

            //Appending Parent back to response
            $type->parent = $request->parent;

        } else {

            unset($data['parent']);
            $type = Type::create($data);
        }
        return new TypesResource($type);
    }

    public function update(TypesRequest $request, Type $type)
    {
        $data = $request->all();
        if ($request->has('parent') && $request->parent) {
            $parent_id = is_numeric($request->parent) ? $request->parent : $request->parent['id'];
            $data['parent_id'] = $parent_id;
        }

        $type->update($data);
        $type = Type::with('parent')->findOrFail($type->id);
        return new TypesResource($type);
    }



    public function destroy(Type $type)
    {
        $type->delete();
        return response()->json('Type deleted successfully', 200);
    }

    /**
     * Remove the specified resources from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyAll(Request $request)
    {
        $ids = $request->ids;
        Type::whereIn('id',$ids)->delete();
        return response()->json('Types deleted successfully', 200);
    }

}
