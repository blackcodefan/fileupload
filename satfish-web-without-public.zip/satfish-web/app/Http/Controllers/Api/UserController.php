<?php

namespace Satfish\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Satfish\Helpers\General;
use Satfish\Http\Controllers\Controller;
use Satfish\Http\Requests\UserRequest;
use Satfish\Http\Requests\UserSettings;
use Satfish\Http\Resources\BanResource;
use Satfish\Http\Resources\UserActivityResource;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Satfish\Http\Resources\UserResource;

use Illuminate\Support\Facades\Password;

//use PragmaRX\Tracker\Tracker;
use PragmaRX\Tracker\Vendor\Laravel\Facade as tracker;
use Satfish\User;
use Satfish\Role;
use Carbon\Carbon;
use DB;

class UserController extends Controller {

    use AuthenticatesUsers;
	public function index( Request $request ) {
		return UserResource::collection( User::with( 'person' )->vueTable());
	}

	public function show( Request $request, $id ) {
        $user = User::with('person.referral')->find( $id );
        if(!$user->person){
            $user->person()->create();
        }
		return new UserResource($user);
	}

	public function get(Request $request,User $user)
    {
        return new UserResource($user);
    }

	public function logoutUser( Request $request ) {
	    $this->logout($request);

	    $accessToken = Auth::user()->token();
        DB::table('oauth_refresh_tokens')
            ->where('access_token_id', $accessToken->id)
            ->update([
                'revoked' => true
            ]);

        $accessToken->revoke();
        return response()->json(null, 204);


		return response()->json( [
			'message' => 'User logged out successfully',
		], 200);
	}

	public function store( UserRequest $request ) {

		$name     = $request->get( 'name' );
		$email    = $request->get( 'email' );
		$password = $request->get( 'password' );
		$brand =  $request->brand['slug'];
		$data     = $request->all();

		$data['person']['referral'] = $request->referral ? $request->referral['id'] : null;


		if ( ! $request->has( 'role' ) )
		{
			$role = 'register';
		}
		else
        {
			$role = $request->get( 'role' );
		}

		$role = Role::whereName( $role )->firstOrFail();
		// save new user
        $userOptions = !empty(config('satfish.default_user_fields'))? config('satfish.default_user_fields'):[];
		$user = \Satfish\User::create( [
			'name'     => $name,
			'email'    => $email,
			'password' => bcrypt( $password ),
			'brand' => $brand,
            'options'  => $userOptions
		]);

        $data['person']['country_title'] = $data['person']['country']['name'];
		$data['person']['country'] = $data['person']['country']['code'];




		$user->person()->create( $data['person'] );
		$user->attachRole( $role );


		return new UserResource( $user );
	}

	/**
	 * Get the guard to be used during authentication.
	 *
	 * @return \Illuminate\Contracts\Auth\StatefulGuard
	 */
	protected function guard() {
		return Auth::guard( 'api' );
	}


    /**
     * User update process
     * @param UserRequest $request
     * @param $id
     * @return UserResource
     */
	public function update( UserRequest $request, $id ) {

		$user = User::findOrFail( $id );
		$data = $request->all();
		if ( $request->has( 'password' ) && $request->password ) {
			$data['password'] = bcrypt( $request->get( 'password' ) );
		} else {
			unset( $data['password'] );
		}

		$data['brand'] = $data['brand']['slug'];

		$user->update( $data );
		$personInput  = [
		    'referral_id' => !empty($request->person['referral']) ? $request->person['referral']['id'] : null,
            'city' => $data['person']['city'],
            'street' => $data['person']['street'],
			'state' => $data['person']['state'],
            'country_title' => $data['person']['country']['name'],
            'country' => $data['person']['country']['code'],
            'boat_name' => $data['person']['boat_name'],
            'phone' => $data['person']['phone'],
            'zip_code' => $data['person']['zip_code'],
            'first_name' => $data['person']['first_name'],
            'last_name' => $data['person']['last_name'],
            'comments' => $data['person']['comments']
        ];

		$user->person()->update( $personInput);

		return new UserResource( $user );
	}


	public function destroyAll(Request $request)
    {
        User::whereIn('id',$request->ids)->delete();
        return response()->json(['message' => 'Users deleted successfully']);
    }

    public function destroy( Request $request, $id ) {
		$user = User::findOrFail( $id );
		$user->delete();

		return response()->json( [
			'message' => 'User deleted successfully',
		], 200 );
	}


	public function banUser( Request $request, $user ) {

		$user = User::findOrFail( $user );

		$forHow = $request->get('forhow');
		$time = $request->get('time');
		switch ($forHow){
            case 'min':
                $time = $time * 1;
                break;
            case 'hour':
                $time = $time * 60;
            case 'day':
                $time = $time * 1440; // 1 day = 1440 min
            case 'week':
                $time = $time * 10080; // 1 week = 10080 min
            case 'month':
                $time = $time * 43800;  // 1 month = 43800 min
                break;
            case 'year':
                $time  =  $time * 525600; // 1 year = 525600 min
                break;
            case 'forever':
                $time = $time * 525600 * 50; // for twenty years
            default;
                $time = $time * 1;
                break;


        }

		$user->ban( [
			'comment'    => $request->get( 'comment' ),
			'expired_at' => Carbon::now()->addMinutes( $time ),
		] );

		return response()->json( [
			'message' => 'User banned successfully',
		], 200 );
	}

	public function getBanUser( Request $request, $user ) {

		$user = User::findOrfail( $user );
		return  BanResource::collection($user->bans()->withTrashed()->paginate( 15 ));
	}

	public function bannedUsers( Request $request ) {
		return UserResource::collection( User::onlyBanned()->vueTable() );
	}

	public function isBanned( Request $request, $user ) {
		$user = User::findOrFail( $user );

		//@TODO fix response
		return $user->isBanned() ? 1 : 0;
	}

	public function unBan( Request $request, $user ) {
		$user = User::findOrFail( $user );
		$user->unban();

		return ! $user->isBanned() ? response()->json( [ 'User ban has been removed' ], 200 ) : response()->json( [ 'Got some error while unbanning user' ] );
	}

	public function userResponse( Request $request ) {
		$user = User::findOrfail( $request->user );
		var_dump( $user->sessions() );
		exit;
	}

	public function activity( Request $request ) {
		$user = User::findOrFail( $request->user );

		return UserActivityResource::collection( Tracker::sessions( 60 * 24, false )->whereUserId( $user->id )->paginate( 50 ) );
	}

	public function allActivity( Request $request ) {

//		return UserActivityResource::collection( Tracker::sessions( 60 * 24, false )->paginate( 50 ) );
	}


    /**
     * Updating user options
     * @param Request $request
     * @param $user
     * @return \Illuminate\Http\JsonResponse
     */
	public function userOptions( Request $request, $user )
    {

        $user = User::findOrFail( $user );
        $finalOptions = [];

        $data = $request->all();

		if(!empty($data['options'])){
		    foreach($data['options'] as $key=>$option){
		        $finalOptions[$key] = $option['id'];
            }
        }

        $user->options = $finalOptions;

        $user->save();
        $user->person()->update(['comments' => $data['person']['comments']]);
        return response()->json( [
            'message' => 'User options saved successfully',
        ], 200 );
    }

    public function profileSettings($uid = false) {
	    $currentUser = Auth::user();
	    //If User is super admin and we have a user id
	    if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
		    $currentUser = User::findorfail($uid);
	    }


	    if($currentUser) {
		    return new UserResource($currentUser);
	    }
    }

    public function storeProfileSettings(UserSettings $request, $uid = false) {
	    $currentUser = Auth::user();

        $newEmail = $request->email;
        $oldEmail = $currentUser->getOriginal('email');


	    //If User is super admin and we have a user id
	    if($uid && in_array($currentUser->id, config('satfish.superAdmin'))) {
		    $currentUser = User::findorfail($uid);
	    }

	    $data = $request->all();

	    if ( $request->has( 'password' ) && $request->password ) {
		    $data['password'] = bcrypt( $request->get( 'password' ) );
	    } else {
		    unset( $data['password'] );
	    }

	    $options = [];
	    foreach($data['options'] as $key => &$option) {
		    $option = $option['id'];
	    }

	    $data = General::cleanArray($data);
	    $currentUser->fill($data);

	    unset($data['person']['full_name']);
	    unset($data['person']['country']);
	    unset($data['person']['created_at']);

	    $currentUser->person()->update($data['person']);

	    $emailVerify = false;
	    if($newEmail != $oldEmail)
        {
            $currentUser->email_verified_at = NULL;
            $emailVerify = true;
        }

	    $currentUser->save();

	    if($emailVerify)
        {
            $this->sendVerifyEmail($currentUser);
        }

//	    return response($currentUser);
	    return new UserResource($currentUser);
    }

    public function sendVerifyEmail($user)
    {
        $user->setProfileUpdate(true);
        return $user->sendEmailVerificationNotification();
    }




    public function logoutApi(){
        if (Auth::check()) {
            return Auth::user()->AauthAcessToken()->delete();
        }
    }

    public function resentVerification() {
	    Auth::user()->sendEmailVerificationNotification();

	    return response()->json( [
		    'message' => 'Verification Email resent',
	    ], 200 );
    }


}
