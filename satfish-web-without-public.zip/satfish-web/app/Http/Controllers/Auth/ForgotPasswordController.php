<?php

namespace Satfish\Http\Controllers\Auth;
use Illuminate\Support\Facades\Password;
use Satfish\Helpers\Brand;
use Satfish\User;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Satfish\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails {
	    sendResetLinkEmail as parentSendResetLinkEmail;
    }

    protected $field = 'email';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

	/**
	 * Send a reset link to the given user.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\JsonResponse
	 */
	public function sendResetLinkEmail(Request $request)
	{
		$user = User::where('email', $request->input('email'))->whereBrand(Brand::active('slug'))->first();
		if (!$user) {
			return $this->sendResetLinkFailedResponse($request, 'Sorry, we don\'t have any accounts matching that email address');
		}

		return $this->parentSendResetLinkEmail($request);
	}

    /**
     * Send a reset link to the given user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\JsonResponse
     */
    public function sendResetLinkEmailAmember(Request $request)
    {
        $this->field = filter_var($request->get($this->field), FILTER_VALIDATE_EMAIL)
            ? $this->field
            : 'name';

        //check user exist in laravel
        $user = User::where($this->field,$request->email)->count();

        if($user){
           return $this->sendResetLinkEmail($request);
        }else{
            // check user from amember with this name
            return $this->checkAmemberUser($request);
        }
    }


    public function checkAmemberUser(Request $request){

        $userInput = [
            'login' => $request->email,
            '_key' => env('AMEMBER_API_KEY'),
        ];

        $client = new Client(); //GuzzleHttp\Client
        $result = $client->get(env('AMEMBER_URL')."/api/check-access/by-login?".http_build_query($userInput));
        $response = json_decode($result->getBody()->getContents());
        if($response->ok && $result->getStatusCode() == 200){
            //if user exist then amember will handle that
            return redirect(env('AMEMBER_URL').'/login?sendpass');
        }

        return back()->withErrors(
            ['email' => 'No user exist with this email']
        );
    }


    /**
     * Send a reset link to the given user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getResetToken(Request $request)
    {
        $this->validate($request, ['email' => 'required|email']);
        $user = User::where('email', $request->input('email'))->first();
        if (!$user) {
            return response()->json(['error' => 'User not found with that email address'],404);
        }
        $this->sendResetLinkEmail($request);
        $token = $this->broker()->createToken($user);
        return response()->json(['token' => $token]);
    }
}
