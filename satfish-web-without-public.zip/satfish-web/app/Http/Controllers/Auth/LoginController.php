<?php

namespace Satfish\Http\Controllers\Auth;

use http\Env\Response;
use Log;
use Auth;
use Satfish\Helpers\Brand;
use Satfish\User;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Satfish\Helpers\General;
use Illuminate\Http\Request;
use Satfish\Http\Controllers\Controller;
use Illuminate\Validation\ValidationException;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller {
	/*
	|--------------------------------------------------------------------------
	| Login Controller
	|--------------------------------------------------------------------------
	|
	| This controller handles authenticating users for the application and
	| redirecting them to your home screen. The controller uses a trait
	| to conveniently provide its functionality to your applications.
	|
	*/

	use AuthenticatesUsers {
		logout as protected parentLogout;
		login as protected parentLogin;
	}

	/**
	 * Where to redirect users after login.
	 *
	 * @var string
	 */
	protected $redirectTo = '/bkend';
	protected $field = 'email';

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware( 'guest' )->except( 'logout' );
	}

	/**
	 * Get the needed authorization credentials from the request.
	 *
	 * @param \Illuminate\Http\Request $request
	 *
	 * @return array
	 */
	protected function credentials( Request $request ) {

		$this->field = filter_var( $request->get( $this->username() ), FILTER_VALIDATE_EMAIL )
			? $this->username()
			: 'name';

		return [
			$this->field => $request->get( $this->username() ),
			'password'   => $request->password,
			'brand'      => Brand::active( 'slug' )
		];
	}


	/**
	 * Login user using Wordpress SSO
	 *
	 * @param Request $request
	 *
	 * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
	 */
	public function loginSSO( Request $request ) {

		if ( config( 'sso.wp_redirect' ) and ! empty( config( 'sso.wp_redirect' ) ) ) {
			$baseUrl = url( '/' );

			// default exception handling by guzzle
			$client = new \GuzzleHttp\Client( [ 'http_errors' => false ] );
			if ( ! empty( $request->token ) ) {
				$response = $client->get( $baseUrl . '/api/auth/user', [
					'headers' => [
						'Accept'        => 'application/json',
						'Authorization' => 'Bearer ' . $request->token,
						'Content-Type'  => 'application/x-www-form-urlencoded',
					],
				] );

				$data = json_decode( (string) $response->getBody() );
				if ( isset( $data->email ) && $data->email ) {
					$user = User::where( 'email', $data->email )->first();
					\Auth::login( $user );
				} else {
					Log::info( "User not available against the provided token" );
				}
			} else {
				Log::info( "No token provided" );
			}

			return redirect( config( 'sso.wp_redirect' ) );
		}

		return redirect()->back();

	}

	public function login( Request $request ) {
		if(Brand::active('slug') == 'fishdope') {
		    return $this->checkAmemberUser( $request );
		}

		return $this->parentLogin( $request );
	}

	public function checkAmemberUser( Request $request ) {
		$data      = $request->all();
		$userInput = [
			'login' => $data[ $this->field ],
			'pass'  => $data['password'],
			'_key'  => env( 'AMEMBER_API_KEY' ),
		];

		$client = new Client(); //GuzzleHttp\Client

        if ( env( 'AMEMBER_URL' ) && env( 'AMEMBER_API_KEY' ) ) {
            $result = $client->get(env('AMEMBER_URL') . "/api/check-access/by-login-pass?" . http_build_query($userInput));
            $response = json_decode($result->getBody()->getContents());
            $subscriptions = isset($response->subscriptions) ? $response->subscriptions : null;

            if ($result->getStatusCode() == 200 && $response->ok) {
                if (empty($subscriptions)) {
                    return response()->json(['errors' => ['email' => ['You must have an active subscription to log in. Please contact support@fishdope.com for further assistance.']]], 401);
                } else {
                    if ($this->addUser($request, $response, true) && $this->checkSubscription($subscriptions)) {
                        // All good
                        return $this->parentLogin($request);
                    }
                }
            }
            else {
                return response()->json([
                    'errors' => ['email' => [$response->msg]]
                ], 401);
            }
        }
	}

	/**
	 * Checking if subscription has not been expired
	 * @param $subscription
	 * @return bool
	 */

	public function checkSubscription($subscription){

		if(!empty($subscription)){
			foreach($subscription as $productId => $expiry){
				if(Carbon::parse($expiry)->gte(Carbon::now())){
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Add user and check for login attempt
	 *
	 * @param $userData
	 */
	public function addUser( Request $request, $response, $amemberUser = 0 ) {
		$user = User::whereEmail( $response->email )->orWhere( 'name', $response->login )->first();
		$data = [
			'email'        => $response->email,
			'name'         => $response->login,
			'password'     => bcrypt( $request->password ),
			'brand'     => Brand::active('slug'),
			'amember_user' => ( $amemberUser ) ? 1 : 0,
		];


		try {
			if ( $user ) {
				$user->update( $data );
			} else {
				User::create( $data );
			}

			return true;

		} catch ( Exception $e ) {
			return false;
		}

		return false;
	}

	public function logout( Request $request ) {
		//If SSO Enabled
		if ( Brand::active( 'sso' ) && config( 'sso.wp_redirect' ) ) {
			return redirect( config( 'sso.wp_redirect' ) . '/wp-json/v1/logoutsso?redirect=' . Brand::active( 'app_url' ) );
		}

		return $this->parentLogout( $request );
	}


	/**
	 * Checking if subscription has not been expired
	 *
	 * @param $subscription
	 *
	 * @return bool
	 */

//    public function checkSubscription($subscription){
//
//        if(!empty($subscription)){
//            foreach($subscription as $productId => $expiry){
//                if(Carbon::parse($expiry)->gte(Carbon::now())){
//                    return true;
//                }
//            }
//        }
//
//        return false;
//    }


	protected function authenticated( Request $request, $user ) {

		if ( $user->isBanned() ) {
			Auth::logout();

			throw ValidationException::withMessages( [
				$this->username() => [ 'You have been banned. Please contact support' ],
			] );

			return response()->json( 'You have been bannded', 401 );
		}

		$credentials = $this->credentials( $request );
		if ( config( 'sso.wp_redirect' ) ) {
			$baseUrl = url( '/' );
			$client  = new \GuzzleHttp\Client( [ 'http_errors' => false ] );
			if ( isset( $credentials['name'] ) ) {
				$credentials['email'] = $credentials['name'];
				unset( $credentials['name'] );
			}
			$response = $client->post( $baseUrl . '/api/auth/login', [
				'form_params' => $credentials,
				'headers'     => [
					'Accept'       => 'application/json',
					'Content-Type' => 'application/x-www-form-urlencoded',
				],
			] );

			$data = json_decode( (string) $response->getBody() );
			if ( isset( $data->access_token ) && $data->access_token ) {
				return response()->json( [ 'redirectTo' => config( 'sso.wp_redirect' ) . "/wp-json/v1/loginsso?token=" . $data->access_token . "&redirect=" . env( 'APP_URL' ) ] );
			} else {
				$encodedCredentials = json_encode( $credentials );
				Log::info( "User not available against the provided credentials $encodedCredentials " );
			}
		}

		if ( $request->wantsJson() ) {
			return response( [ 'redirectTo' => route( 'admin' ), 'status' => $user->getCanAccessAttribute() ] );
		} else {
			if ( Auth::user()->isAdmin ) {
				return redirect()->route( 'admin' );
			}

			return redirect()->route( 'home.dashboard' );
		}

	}

}
