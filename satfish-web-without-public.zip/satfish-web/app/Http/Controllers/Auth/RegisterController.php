<?php

namespace Satfish\Http\Controllers\Auth;

use DB;
use http\Env\Response;
use Satfish\CouponBatch;
use Satfish\Helpers\Brand;
use Satfish\Helpers\General;
use Satfish\Helpers\Notifier;
use Satfish\MemCert;
use Satfish\Type;
use Satfish\User;
use Stripe\Plan;
use Satfish\Role;
use Illuminate\Http\Request;
use Satfish\Http\Requests\UserRequest;
use Illuminate\Auth\Events\Registered;
use Satfish\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;


class RegisterController extends Controller {
	/*
	|--------------------------------------------------------------------------
	| Register Controller
	|--------------------------------------------------------------------------
	|
	| This controller handles the registration of new users as well as their
	| validation and creation. By default this controller uses a trait to
	| provide this functionality without requiring any additional code.
	|
	*/

	use RegistersUsers;

	/**
	 * Where to redirect users after registration.
	 *
	 * @var string
	 */
	protected $redirectTo = '/';

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware( 'guest' );
	}


	public function validateCoupon( Request $request ) {
		if ( $request->get( 'redeem_certificate' ) ) {
			$memCart = MemCert::where( 'code', $request->get( 'couponCode' ) )->where( 'status', 1 )->first();
			if ( ! empty( $memCart ) ) {
				return response()->json( [ 'Certificate available' ], 200 );
			}

			return response()->json( [ 'errors' => [ 'No coupon available with this code' ] ], 404 );


		} else {
			\Stripe\Stripe::setApiKey( Brand::active( 'stripe_secret' ) );
			if ( ! empty( $request->has( 'couponCode' ) ) ) {
				$coupon = \Stripe\Coupon::retrieve( $request->get( 'couponCode' ) );
				$couponBatch = CouponBatch::whereCode($request->get( 'couponCode' ))->whereIsDisabled(0)->first();
				if ( $request->ajax() ) {
					if ( $coupon && $couponBatch ) {
						return response()->json( [ 'coupon' => $coupon ], 200 );
					}

					return response()->json( [ 'Coupon Code not valid' ], 422 );
				}

				return $coupon;
			}
		}


	}

	/**
	 * Handle a registration request for the application.
	 *
	 * @param \Illuminate\Http\Request $request
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function register( UserRequest $request ) {
//    	var_dump('here');exit;

//        try
//        {
		// DB::beginTransaction();
		$data = $request->all();
//            $this->validator($request->all())->validate();
		//Set Brand User
		$data['brand'] = Brand::active( 'slug' );
		if ( $request->has( 'redeem-coupon' ) && $request->get( 'redeem-coupon' ) ) {
			$memCert = MemCert::where( 'code', $request->get( 'cert-coupon' ) )->where( 'status', 1 )->whereRaw( 'use_count > used_count' )->first();
			if ( empty( $memCert ) ) {
				if ( $request->ajax() ) {
					return response()->json( [ 'errors' => [ 'Coupon Code not valid' ] ], 422 );
				}

				return back()->with( 'errors', [ 'Coupon Code not valid' ] );

			}
		}

		if ( $request->has( 'redeem-coupon' ) && ! $request->get( 'redeem-coupon' ) ) {
			try {
				$this->validateCoupon( $request );
			} catch ( \Exception $e ) {
				return redirect()->back()->withErrors( [ 'Coupon Code not valid' ] );
			}
		}

		event( new Registered( $user = $this->create( $data ) ) );

		//Setting Stripe Key on the fly
		$user::setStripeKey( Brand::active( 'stripe_secret' ) );

		if ( $request->has( 'redeem-coupon' ) && $request->get( 'redeem-coupon' ) ) {

			switch ( $memCert->grace_period_unit ) {
				case 'day':
					$days = 1;
					break;
				case 'week':
					$days = 7;
					break;
				case 'month':
					$days = 30;
					break;
				case 'year':
					$days = 30 * 12;
					break;
			}

			$days = $memCert->grace_period_no * $days;
			$user->trial_ends_at = now()->addDays( $days );
			$user->update();

			$memCert->increment( 'used_count' );

			//adding coupon usage
			$memCert->couponUsage()->attach( $user->id );
		} else {

			$subscription = $user->newSubscription( config( 'satfish.stripeDefault.name' ), $data['plan'] );
			if ( ! empty( $data['couponCode'] ) ) {
				$subscription = $subscription->withCoupon( $data['couponCode'] );
			}

			$subscription->create( $data['stripeToken'], [
				'email' => $data['email'],
				'name'  => $data['person']['first_name'] . ' ' . $data['person']['last_name'],
				'phone' => $data['person']['phone']
			] );
		}
		if ( $user->subscribedToPlan( $data['plan'], config( 'satfish.stripeDefault.name' ) ) OR $user->onTrial() ) {
			$role                            = $request->has( 'role' ) ? $request->get( 'role' ) : 'register';
			$role                            = Role::whereName( $role )->firstOrFail();
			$data['person']['country_title'] = config( 'countries' )[ $data['person']['country'] ];
			$data['person']['country']       = $data['person']['country'];
			$user->person()->create( $data['person'] );
			$user->attachRole( $role );

		}

		//DB::commit();

		//Send Email Notifications
		Notifier::notify( 'user.signup', [ 'user' => $user, 'password' => $data['password'] ], $user );
		$user->sendEmailVerificationNotification();
//        }
//        catch(\Exception $e)
//        {
//            DB::rollback();
//        }

		$this->guard()->login( $user );

		if ( $request->ajax() ) {
			return response()->json( [ 'redirectTo' => route( 'home' ), 'status' => $user->getCanAccessAttribute()] );
		}

		return $this->registered( $request, $user )
			?: redirect( $this->redirectPath() );

	}


	/**
	 * Get a validator for an incoming registration request.
	 *
	 * @param array $data
	 *
	 * @return \Illuminate\Contracts\Validation\Validator
	 */
	protected function validator( array $data ) {
		return Validator::make( $data, [
			'name'     => 'required|string|max:255',
			'email'    => 'required|string|email|max:255|unique:users',
			'password' => 'required|string|min:6|confirmed',
		] );
	}

	/**
	 * Create a new user instance after a valid registration.
	 *
	 * @param array $data
	 *
	 * @return \Satfish\User
	 */
	protected function create( array $data ) {
		return User::create( [
			'name'      => $data['name'],
			'email'     => $data['email'],
			'brand'     => $data['brand'],
			'password'  => bcrypt( $data['password'] ),
			'card_name' => ! empty( $data['card_name'] ) ? $data['card_name'] : null,
		] );
	}

	/**
	 * Show the application registration form.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function showRegistrationForm() {

//        \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
		\Stripe\Stripe::setApiKey( Brand::active( 'stripe_secret' ) );
		$types = Type::with( 'children' )->whereIn( 'slug', [
			'gps_format_options',
			'temprature',
			'distance',
			'height',
			'speed',
			'referrals'
		] )->get()->keyBy( 'slug' );

		$client  = new \GuzzleHttp\Client();
		$terms   = $client->request( 'GET', 'https://www.'.Brand::active('slug').'.com/wp-json/wp/v2/pages/'.(Brand::active('slug') == "fishdope" ? '18' : '64'));
		$privacy = $client->request( 'GET', 'https://www.'.Brand::active('slug').'.com/wp-json/wp/v2/pages/'.(Brand::active('slug') == "fishdope" ? '20' : '66'));

		$terms   = json_decode( $terms->getBody() );
		$privacy = json_decode( $privacy->getBody() );

		$termsTxt = $terms->content->rendered . $privacy->content->rendered;

//	    dd($termsTxt);
		$typesArr = [];
		foreach ( $types as $key => $type ) {
			foreach ( $type->children as $child ) {
				$typesArr[ $key ][ $child->id ] = $child->name;
			}
		}

		$data = [
			'plans'    => Plan::all()->data,
			'types'    => $typesArr,
			'termsTxt' => $termsTxt
		];

		return view( 'auth.register', $data );
	}


}
