<?php

namespace Satfish\Http\Controllers\Auth;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Mockery\Generator\StringManipulation\Pass\Pass;
use Satfish\Http\Controllers\Controller;
use Illuminate\Support\Facades\Password;
use Illuminate\Foundation\Auth\ResetsPasswords;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    protected $updateAmember = false;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }


//    public function reset(Request $request)
//    {
//        $this->validate($request, $this->rules(), $this->validationErrorMessages());
//        // Here we will attempt to reset the user's password. If it is successful we
//        // will update the password on an actual user model and persist it to the
//        // database. Otherwise we will parse the error and return the response.
//        $response = $this->broker()->reset(
//                $this->credentials($request), function ($user, $password) {
//                $this->resetPassword($user, $password);
//            }
//        );
//
//        dd($response);
//
//        // if request is from api
////        if(!$request->wantsJson()){
////            $this->updateAmemberPassword($request);
////        }
//
//        // If the password was successfully reset, we will redirect the user back to
//        // the application's home authenticated view. If there is an error we can
//        // redirect them back to where they came from with their error message.
//
//        if($request->wantsJson()){
//            if($response == Password::PASSWORD_RESET){
//                return response()->json(['success' => trans($response)]);
//            }
//            return response()->json(['error' => trans($response)]);
//        }
//
//        return $response == Password::PASSWORD_RESET
//            ? $this->sendResetResponse($response)
//            : $this->sendResetFailedResponse($request, $response);
//    }


    /**
     * Updating amember password in case of reset
     * @param Request $request
     * @return bool|void
     */
    public function updateAmemberPassword(Request $request){


        $userInput = [
            'email' => $request->email,
            '_key' => env('AMEMBER_API_KEY'),
        ];

        //get user and if get user then update its password in next request
        $client = new Client(); //GuzzleHttp\Client
        $result = $client->get(env('AMEMBER_URL')."/api/check-access/by-email?".http_build_query($userInput));
        $response = json_decode($result->getBody()->getContents());
        if($response->ok && $result->getStatusCode() == 200){

            //if user exist then update amember user
            $userInput = [
                '_key' => env('AMEMBER_API_KEY'),
                '_method' => 'PUT',
                'pass' => $request->password,
            ];

            $client = new Client(); //GuzzleHttp\Client
            $result = $client->put(env('AMEMBER_URL')."/api/users/".$response->user_id,['form_params'=>$userInput]);
            $response = json_decode($result->getBody()->getContents());
            if(isset($response[0]) && $response[0]->need_session_refresh){
                return;
            }
        }

        return false;
    }
}
