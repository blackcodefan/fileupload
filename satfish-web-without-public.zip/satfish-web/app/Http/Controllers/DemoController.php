<?php

namespace Satfish\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Satfish\Buoy;
use Satfish\Helpers\Brand;
use Satfish\Helpers\General;
use Satfish\HotBites;
use Satfish\Layers;
use Satfish\Markers;
use Satfish\TidesData;
use Satfish\Region;

use Satfish\RegionOptions;
use Satfish\Solunar;;
use URL;

class DemoController extends Controller
{

    /**
     * membership view
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function memberShip(Request $request){
        return view('demo.membership');
    }

	/**
	 * Render list of Regions
	 *
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
    public function getRegions($ajax = false) {

	    if(!$ajax && !Auth::check()) {
		    abort(403, 'You are not logged in, or do not have access to this page.');
	    }

    	$data = [
			'regions' => Region::activeBrand()
								->whereStatus(true)
								->get()
        ];

	    //Return data if its an aJax call
	    if($ajax) {
		    return response()
			    ->json($data);
	    }

	    return view('demo/regions', $data);
    }


	/**
	 *  Render an individual Region
	 *
	 * @param Request $request
	 * @param $id
	 *
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
	 */
    public function getRegion(Request $request, $id, $ajax = false) {

	    if(!$ajax && !Auth::check()) {
		    abort(403, 'You are not logged in, or do not have access to this page.');
	    }

        $region = Region::
	                activeBrand()
                    ->whereStatus(true)
                        ->with('wind')
                        ->findorfail($id);
        $layers = Layers::whereRegionId($id)
                        ->whereTiled(true)
                        ->whereStatus(true)
	                    ->activeType()
                            ->with('type');

        if($ajax) {
	        $layers = $layers->with('type', 'media');
        }
	    $layers = $layers->get();

        $markers = Markers::WithinRegion($region)->get();

        if(Brand::active('hotbites')) {
	        $hotbites = HotBites::WithinRegion($region)
	                            ->where('date_time', '>' , Carbon::now(config('satfish.timezone'))->subDays(5))
	                            ->orderBy('date_time')
	                            ->get();
        } else {
        	$hotbites = null;
        }


        $buoys = Buoy::WithinRegion($region)->whereStatus(true)->get();

        $data = [
            'region' => $region,
	        'layers' => General::orderLayers($region, $layers, $markers, $hotbites, $buoys),
	        'map_zoom' => General::getZoom($region)
        ];

        //Return data if its an aJax call
        if($ajax) {
        	$data['menuLayers'] = config('satfish.layers');
        	return response()
		        ->json($data);
        }

        return view('demo/region', $data);
    }

	public function solunar(Request $request,$id){

		$data = ['region_id' => $id];
		return view('demo/solunar',$data);

	}

	/**
	 * Getting data for graph
	 * @param Request $request
	 * @return \Illuminate\Http\JsonResponse
	 */
	public function getTideGraph(Request $request){

        global $moonPoints;
        $region = Region::findOrFail($request->region_id);
		if(empty($request->lat) && empty($request->lng)){


			if($region->upper_lat < $region->bottom_lat){
				$lat = ($region->bottom_lat - $region->upper_lat)/2;
				$lat += $region->upper_lat;
			}else{
				$lat = ($region->upper_lat - $region->bottom_lat)/2;
				$lat += $region->bottom_lat;
			}


			if($region->left_lng < $region->right_lng){
				$underlong = ($region->right_lng - $region->left_lng)/2;
				$underlong += $region->left_lng;
			}else{
				$underlong = ($region->left_lng - $region->right_lng)/2;
				$underlong += $region->right_lng;
			}
		}else{
			$lat = $request->lat;
			$underlong = $request->lng;
		}


		$currentDate = explode("-",$request->date);
		if($currentDate[0] < 10){
			$currentDate[0] = "0".$currentDate[0];
		}
		$currentDate = implode("-",$currentDate);
//        $data = Solunar::where('solunar_date',$currentDate)->first();


		if(!empty($request->date)){
//            date_default_timezone_set("Asia/Karachi");
			$today =  Carbon::parse($request->date);
			$year = $today->year;
			$month = $today->month;
			$day = $today->day;
		}else{
			$today = getDate();
			$year = $today['year'];
			$month = $today['mon'];
			$day = $today['mday'];
		}
//        $today = empty($request->date)? getdate():$request->date;  //defualt to todays date

		$tz = ch150918__utc_offset_dst();
		$UT = 0.0;

		if ($lat < 0){
			$lat1 = 0 - $lat;
		}

		if ($underlong < 0){
			$long1 = 0 - $underlong;
		}

		//get dates
		$JD = get_Julian_Date($year, $month, $day, $UT);

//        $today = $today->setTimezone('UTC');
//        $jd = unixtojd( $today->getTimestamp());

		$date = ($JD - 2400000.5 - ($tz/24.0));
		//get rise, set and transit times for moon and sun
        set_moonpoints(1, $date, 0.0 - $underlong , $lat, $sunrise, $sunset, $suntransit);
        set_moonpoints(0, $date, 0.0 - $underlong, $lat, $moonrise, $moonset, $moontransit);
		get_rst(1, $date, 0.0 - $underlong , $lat, $sunrise, $sunset, $suntransit);
		get_rst(0, $date, 0.0 - $underlong, $lat, $moonrise, $moonset, $moontransit);
		$moonunder = get_transit_under(0, $date - 1.5 - ($tz/24.0), 0, $underlong);

		//get solunar minor periods
		sol_get_minor1($minorstart1, $minorstop1, $moonrise);
		sol_get_minor2($minorstart2, $minorstop2, $moonset);

		//get solunar major periods
		sol_get_major1 ($majorstart1, $majorstop1, $moontransit);
		sol_get_major2 ($majorstart2, $majorstop2, $moonunder);

		//get moon phase
		$moonage = get_moon_phase ($JD, $PhaseName, $illumin);

		//get day scale
		$phasedayscale = phase_day_scale ($moonage);
		$soldayscale = sol_get_dayscale ($moonrise, $moonset, $moontransit,$moonunder, $sunrise, $sunset);
		$dayscale = 0;
		$dayscale = ($soldayscale + $phasedayscale);
		$data = [
		    'moonpoints' => $moonPoints,
			'sunrise' => convert_time_to_string($sunrise),
			'sunset' => convert_time_to_string($sunset),
			'moonrise' => convert_time_to_string($moonrise),
			'moonset' => convert_time_to_string($moonset),
			'moonunderfoot' => convert_time_to_string($moonunder),
			'moonoverhead' => convert_time_to_string($moontransit),
			'majorfishingtime1' => convert_time_to_string($majorstart1),
			'majorfishingtime2' => convert_time_to_string($majorstop1),
			'majorfishingtime3' => convert_time_to_string($majorstart2),
			'majorfishingtime4' => convert_time_to_string($majorstop2),
			'minorfishingtime1' => convert_time_to_string($minorstart1),
			'minorfishingtime2' => convert_time_to_string($minorstop1),
			'minorfishingtime3' => convert_time_to_string($minorstart2),
			'minorfishingtime4' => convert_time_to_string($minorstop2),
			'percentgoodday' => $dayscale,
			'percentfull' => $illumin * 100,
			'debug' => [
				'date' => $today,
				'lat' => $lat,
				'lng' => $underlong,
			],
		];

		$tidesData = $this->fetchMoonData($request->date,$request->region_id);
		$data['tidesData'] =  isset($tidesData['data'])? $tidesData['data']:[];
		$data['regionOptions'] = isset($tidesData['regionOptions'])? $tidesData['regionOptions']:[];
		if(empty($data)){
			return response()->json($data,'404');
		}
		return response()->json($data,200);
	}




	/**
	 * Data calculation
	 * @param $date
	 * @param int $regionId
	 * @return array
	 * @throws \GuzzleHttp\Exception\GuzzleException
	 */

	public function fetchMoonData($date,$regionId = 1){

		$date = Carbon::parse($date,config('app.timezone'));

		$dbDateFormat = $date->format("Y-m-d");

		$region = Region::with('options')->findOrFail($regionId);
		if(empty($region->options)){
			return [];
		}
		$tidesData = TidesData::where('data_date',$dbDateFormat)->where('server',$region->options->server)->first();

		if($region->options->server == 1 && !empty($region->options->station_id) && empty($tidesData->data)){
			//use API
			$date = $date->format("Ymd");
			$stationId = $region->options->station_id;
			$endpoint = "https://tidesandcurrents.noaa.gov/api/datagetter?product=predictions&begin_date=$date&end_date=$date&datum=MLLW&station=$stationId&time_zone=GMT&units=english&interval=&format=json&application=NOS.COOPS.TAC.WL";
			$client = new \GuzzleHttp\Client();
			$response =  $client->request('GET', $endpoint);
			$statusCode = $response->getStatusCode();
			$content = $response->getBody()->getContents();
			$content = json_decode($content);
			if(isset($content->predictions)){
				return ['data' => $content->predictions,'regionOptions' => $region->options];
			}
		}

		if(empty($tidesData->data)){
			return [];
		}

		if($tidesData){
			//fetch from DB
			return ['data' => $tidesData->data,'regionOptions' => $region->options];
		}else{
			//if server is mexico we cant get it using api
			return [];
		}



	}


}
