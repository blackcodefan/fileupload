<?php

namespace Satfish\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Satfish\Helpers\Notifier;
use Satfish\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }



//    public function testAction() {
//    	dd(Notifier::notify('user.email_verify',['user' => Auth::user(), 'verificationUrl' => 'anything'],User::find(19)));
////	    dd(\Notification::send( Auth::user(), ( new static( [ 'template' => 'mail.self.user.email_verify', 'data' => ['user' => Auth::user(), 'verificationUrl' => 'anything'] ] ) ) ));
//    }
}
