<?php

namespace Satfish\Http\Controllers;
use Satfish\Helpers\General;
use Satfish\Type;
use Satfish\Http\Requests\HotBitesRequest;
use Satfish\Http\Resources\HotBites as HotBitesResource;
use Satfish\HotBites;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HotBitesController extends Controller
{
    protected $view = 'demo.hotbites.';



    public function index(){
        return view($this->view.'index',['hotbites'=> HotBites::with(['categories'])->get()]);
    }

    public function create(){

        $parent = Type::with('children')->whereSlug('hot_bites_categories')->first();
        return view($this->view.'create',['hotbites' => $parent->children->pluck('name','id')]);
    }

    public function store(HotBitesRequest $request){

        $data = [
            'category_id' => $request->category,
            'title'    => $request->get('title'),
            'type'     => $request->type ? $request->type : 0,
            'lat'      => General::DMStoDD($request->lat),
            'lng'      => General::DMStoDD($request->lng) * -1,
            'note'     => $request->get('note'),
            'date_time' => General::timeZoneToUtc($request->date_time),
        ];

        HotBites::create($data);

        return redirect(route('hotbites.index'));
    }


    public function edit(Request $request,$id){
        $hotbite = HotBites::findOrFail($id);
        $parent = Type::with('children')->whereSlug('hot_bites_categories')->first();
        return view($this->view.'create',['hotbite' => $hotbite,'hotbites' => $parent->children->pluck('name','id') ]);
    }

    public function update(HotBitesRequest $request,$id){

        $hotbite = HotBites::findOrFail($id);
        $data = [
            'category_id' => $request->category,
            'title'    => $request->get('title'),
            'type'     => $request->type ? $request->type : 0,
            'lat'      => General::DMStoDD($request->lat),
            'lng'      => General::DMStoDD($request->lng) * -1,
            'note'     => $request->get('note'),
            'date_time' => General::timeZoneToUtc($request->date_time),
        ];
        $hotbite->update($data);
        return redirect(route('hotbites.index'));
    }
}