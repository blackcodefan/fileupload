<?php
/**
 * Created by PhpStorm.
 * User: team
 * Date: 7/16/19
 * Time: 12:54 PM
 */



namespace Satfish\Http\Controllers\Webhooks;
use Laravel\Cashier\Http\Controllers\WebhookController;
use Illuminate\Support\Facades\Log;
use Satfish\Helpers\Notifier;
use Illuminate\Support\Facades\Artisan;
use Satfish\User;

class StripeController extends WebhookController
{
    public function handlePaymentIntentPaymentFailed(array $payload)
    {
        $customer = $payload['data']['object']['customer'];
        if(!empty($customer))
        {
           $user =  User::where('stripe_id',$customer['id'])->first();
           $error = $payload['data']['last_payment_error'];

           switch ($error['code'])
           {
               case 'expired_card':
                   $message = 'The card has expired. Check the expiration date or use a different card';
                   break;
               case 'email_invalid':
                   $message = "Your email is invalid";
                   break;
               case 'invalid_card_type':
                   $message = "The card provided as an external account is not a debit card. Provide a debit card instead";
                   break;
               case 'invalid_number':
                   $message = 'The card number is invalid. Check the card details or use a different card';
                   break;
               case 'default':
                   $message = 'Your payment has not been captured due to some issue. Please contact support';
                   break;
           }

           Notifier::notify('membership.payment_failed',['user' => $user,'message' => $message]);
           Log::info('Payment failed - StripeWebhook - handlepaymentintent()', ['details' => json_encode($payload)]);

        }
        return  response()->json('Webhook Handled', 200);
    }



    public function handleCouponUpdated(array $payload)
    {
        Artisan::call('satfish:sync-coupons',[]);

        return  response()->json('Webhook Handled', 200);

    }

    public function handleCouponDeleted(array $payload)
    {
        Artisan::call('satfish:sync-coupons',[]);

        return  response()->json('Webhook Handled', 200);

    }


}