<?php

namespace Satfish\Http\Middleware;

use Auth;
use Closure;
use Illuminate\Support\Facades\App;
use Satfish\Helpers\General;

class AmemberAuth {
	/**
	 * Handle an incoming request.
	 *
	 * @param \Illuminate\Http\Request $request
	 * @param \Closure $next
	 *
	 * @return mixed
	 */
	public function handle( $request, Closure $next ) {

		if ( \Route::currentRouteName() == 'admin' && Auth::check() && ! in_array( Auth::user()->id, config( 'satfish.superAdmin' ) ) ) {
			return General::redirectTo( route( 'home' ), 'Permission Denied' );
		}

		if(Auth::check() AND \Route::currentRouteName() == 'login' )
        {
            return General::redirectTo( route( 'home' ) );
        }


        if(\Route::currentRouteName() == 'demo-regions-ajax' OR \Route::currentRouteName() == 'demo-region')
        {
            if(!$this->checkRestrication())
            {
                return General::redirectTo("/");
            }
        }

		return $next( $request );
	}


    protected function checkRestrication()
    {

        if(Auth::check() AND (Auth::user()->subscribed(config('satfish.stripeDefault.name')) OR Auth::user()->activeTrial))
        {
            return true;
        }
        return false;
    }
}
