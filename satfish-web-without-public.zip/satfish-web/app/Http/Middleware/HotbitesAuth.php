<?php

namespace Satfish\Http\Middleware;

use Auth;
use Closure;

class HotbitesAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
	    if(!Auth::check() || (Auth::user() && !in_array(Auth::user()->name, ['lunchbox', 'jason', 'Danny', 'garrett619', 'demo']))) {
	    	abort(403, "Sorry! You don't have access ot this page");
	    }

        return $next($request);
    }
}
