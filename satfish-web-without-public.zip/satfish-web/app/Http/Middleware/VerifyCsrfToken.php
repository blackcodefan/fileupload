<?php

namespace Satfish\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        '/getGraphData',
        'http://192.168.31.201:3000/*',
        '/api/auth/*',
        '/webhooks/*',
        '/login',
        '/register',
        '/password/mobile'
    ];
}
