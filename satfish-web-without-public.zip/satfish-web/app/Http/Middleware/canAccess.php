<?php

namespace Satfish\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Satfish\Helpers\General;

class canAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
    	if(Auth::user() && !Auth::user()->can_access) {
		    return General::redirectTo( route( 'home.dashboard' ) );
	    }

        return $next($request);
    }
}
