<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CouponRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $validation =  [
            'code' => "required|regex:/(^[A-Za-z0-9]+$)+/",
            'duration' => 'required',
            'discount' => 'required|regex:/(^[1-9]\d*$)+/',
            'usage' => 'required|regex:/(^[1-9]\d*$)+/',
            'type' => 'required',
            'brand' => 'required',
            'plans' => 'required',

        ];

        if($this->duration == 'repeating'){
            $validation['duration_in_months'] = 'required';
        }

        return $validation;
    }

    public function messages(){
        return [
            'code.required' => 'Please enter coupon',
            'code.regex' => 'Code can only contain number and alphabets without spaces',
            'duration' => 'Please select any duration ',
            'discount.regex' => 'Discount can only contain positive number',
            'usage.regex' => 'Coupon Usage can only contain postive number'
        ];
    }

}
