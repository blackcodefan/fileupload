<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class HotBitesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'  => 'required|regex:/(^(?!-)(?!.*--)[A-Za-z0-9- ]+(?<!-)*$)/',
            'category'  => 'required',
            'lat' => 'required',
            'lng' => 'required',
            'date_time' => 'required',
        ];
    }
        // regex:/(^[a-zA-Z0-9_ -]*[a-zA-Z0-9_]+[a-zA-Z0-9_ -]*$)+/
        //regex:/(^[a-zA-Z0-9_]*[a-zA-Z_]+[a-zA-Z0-9_]*$)+/

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'title.regex' => "The Title may only contain letters and numbers with dash and spaces",
            //'lat.numeric' => "Latitude fields should be a number",
            //'lng.numeric' => "Longitude fields should be a number",
            'lat.required' => "Latitude fields is required for hotbite",
            'lng.required' => "Longitude fields is required for hotbite",
            'date_time.required' => "Please select date and time of the hotbite",
            'category.required' => "Please select category",
        ];
    }

}
