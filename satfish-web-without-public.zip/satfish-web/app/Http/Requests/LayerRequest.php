<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LayerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $validation =  [
            'region' => 'required',
            'type' => 'required',
            'created_at' => 'required'
            //,
            //'media' =>'required' 
//           |regex:/^(\d)+.(?:jpe?g|png|gif)/'
//	        'media' =>  ($this->source == 'image' && $this->method() == 'POST') ? 'required|base64:png,jpeg,jpg' : ''
//	        'media' =>   'required'
        ];

        if($this->method() == 'POST'){

            $validation['media'] = "required|base64:png,jpeg,jpg";
            if(isset($this->type['slug'])
                && config('satfish.layers.' . $this->type['slug'] . '.kml')) {
	            $validation['media'] .= ',kml,xml';
            }
        }


        if($this->method() == 'PATCH')
        {

            $validation['media'] = "required|base64:png,jpeg,jpg";
        }

        return $validation;
    }


	/**
	 * Get the error messages for the defined validation rules.
	 *
	 * @return array
	 */
	public function messages()
	{
		return [
			'tiled.max' => "You can't mark tiles as generated",
            'created_at.required' => 'Please select date and time of the layer',
            'media.required' => 'Please upload an image',
            'postsize.max' => "Max post size should be less than :max MB",
		];
	}
}
