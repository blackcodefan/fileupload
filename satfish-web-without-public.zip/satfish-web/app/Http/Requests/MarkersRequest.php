<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MarkersRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
    	$rules = [
		    'name' => 'required|regex:/(^[A-Za-z0-9. -]+$)+/',
		    'lat' => 'required|lat',
			'lng' => 'required|lng',
			'zoomCtrl' =>['regex:/(?:[0-9]-[1-9][0-9]+|-[1-9]|-[2-9]|2-[3-9]|3-[4-9]|4-[5-9]|5-[6-9]|6-[7-9]|7-[8-9]|8-9)|[0-9]|[0-9][0-9]/']			
		//	'zoomCtrl' =>['regex:/b\(?:0-[1-9]|1-[2-9]|2-[3-9]|3-[4-9]|4-[5-9]|5-[6-9]|6-[7-9]|7-[8-9]|8-9|9-1[0-3]|0-1[0-3]|1-1[0-3]|2-1[0-3]|3-1[0-3]|4-1[0-3]|5-1[0-3]|6-1[0-3]|7-1[0-3]|8-1[0-3]|9-1[0-3]|10-1[1-3]|11-1[2-3]|12-13|^[0-9]*$)\b/']
		];

    	if($this->zoomCtrl) {
    		$zoom = explode('-', $this->zoomCtrl);

    		if(isset($zoom[0]) && !is_numeric($zoom[0])) {
				$rules['zoomCtrl'] = 'digits_between:1,13';
		    }

		    if(isset($zoom[1]) && !is_numeric($zoom[1])) {
			    $rules['zoomCtrl'] = 'digits_between:1,13';
		    }

		    if(isset($zoom[0]) && is_numeric($zoom[0]) && isset($zoom[1]) && is_numeric($zoom[1]) && $zoom[0] > $zoom[1])
            {
                $rules['zoomCtrl'] = 'max:'. (int)($zoom[1]);
            }
	    }

        return $rules;
    }


	/**
	 * Get the validation error message.
	 *
	 * @return string
	 */
	public function messages()
	{
		return [
			'zoomCtrl.digits_between' => 'Please provide a valid range or a number between 0-13',
			'zoomCtrl.max' => 'Zoom must not be greater than :max',
			//'zoomCtrl.regex'=>'The First Number Should be Smaller then the Second number',
			'name.regex' => 'Name can only contain letters,numbers,dash and spaces',
		];
	}
}


// 'zoomCtrl' =>['regex:/\b(?:
// 			0-[1-9]|1-[2-9]|2-[3-9]|3-[4-9]|4-[5-9]|5-[6-9]|6-[7-9]|7-[8-9]|8-9|9-1[0-3]
// 			|0-1[0-3]|1-1[0-3]|2-1[0-3]|3-1[0-3]|4-1[0-3]|5-1[0-3]|6-1[0-3]|7-1[0-3]|8-1[0-3]|9-1[0-3]
// 			|10-1[1-3]|11-1[2-3]|12-13)\b/']