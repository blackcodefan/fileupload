<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MemCertRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'code' => 'required|regex:/(^[A-Za-z0-9.]+$)+/|unique:membership_certificate',
            'use_count'    => 'required|regex:/(^[1-9]\d*$)+/',
            'grace_period_no'      => 'required|regex:/(^[1-9]\d*$)+/',
            'grace_period_unit'     => 'required',
        ];
    }

/**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'code.regex' => 'The Name may only contain letters and numbers',
            'use_count.regex' =>'Use Count can only contain numbers (positive)',
            'grace_period_no.required' => "Grace Period # is required",
            'grace_period_no.regex' => "Grace Period # can only contain numbers (positive)"
           ];
    }









}
