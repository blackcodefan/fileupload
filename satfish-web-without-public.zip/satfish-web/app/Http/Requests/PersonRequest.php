<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PersonRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     *
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {     return [
            //'person.boat_name' => 'required',
            'name' => 'required|alpha_dash|unique:person',
            'email' => 'required|string|email|max:255|unique:users',
            //'password' => 'required|string|min:6|confirmed',
            'person.first_name' => 'required',
            'person.last_name' => 'required',
            'person.phone' => 'required|numeric',
            'person.street'    => 'required|regex:/(^[A-Za-z0-9. -]+$)+/',
            'person.city'      =>   'required|regex:/^[a-zA-Z ]*$/',
            'person.state'      =>   'required|regex:/^[a-zA-Z ]*$/',
            'person.zip_code' => 'required|numeric',
            'person.country'      =>   'required',
        ];
    }

    public function messages()
    {
        return [
            //'person.boat_name.required' => 'Please enter boat name',
            
            'person.zip_code.required' =>   " Zip Code is required",
            'person.zip_code.numeric' =>    "Zip Code may only contain numbers",
            'person.street.required'    =>  'Street is required',
            'person.street.regex'      => 'Street may only contain alphabets , numbers and dash', 
            'person.city.required'      =>   'City is required',
            'person.city.alpha'      =>     'City may only contain alphabets',
            'person.state.required'     =>   'State is required',
            'person.state.alpha'      =>     'State may only contain alphabets',
            
            // 'person.zip_code.required'      =>   'Please enter zip code',
            // 'person.country.required'      =>   'Please enter country',
        ];
    }
}
