<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegionsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $maxZoom = $this->extra['max_zoom'];
        $minZoom = $this->extra['min_zoom'];

        $validation =  [

            //'name' => 'required|regex:/(^[A-Za-z0-9. -]+$)+/',
            'name' => 'required|regex:/(^[a-zA-Z0-9_\/ -]*[a-zA-Z_\/ -]+[a-zA-Z0-9_\/ -]*$)+/',
            'upper_lat' => 'required|numeric',
            'left_lng' => 'required|numeric',
            'bottom_lat' => 'required|numeric',
            'right_lng' => 'required|numeric',
            'brand'  => 'required',
            //  'server' => 'required',
            'extra.max_zoom' => "integer|min:5",
            'extra.min_zoom' => "integer|min:$minZoom|max:14",
            'extra.default_zoom' => "integer|min:$minZoom|max:$maxZoom",
        ];

        switch ($this->method())
        {
            case 'GET':
            case 'DELETE':
                {
                    return [];
                }
            case 'POST':
                {
                    $validation['slug'] = 'required|alpha_dash|unique:regions';
                    return $validation;
                }
            case 'PUT':
            case 'PATCH':
                {
                    //@TODO : discuss with faisal
//                    $id = $this->route('regions.update');
//                    $validation['slug'] = "required|alpha_dash|unique:regions,slug,$id,id";
                //$validation['brand'] = "required";
                return $validation;
                }
            default:break;
        }
    }

    public function messages(){
        return [
            'name.required' => 'Name is required',
            'name.regex' => 'Name must contain letters and may contain numbers, dashes, forward slash and spaces',
            'upper_lat.required' => 'Upper latitude must not be empty',
            'upper_lat.numeric' =>'Upper latitude must be a number',
            'bottom_lat.numeric' => 'Bottom latitude must be a number',
            'left_lng.numeric' => 'Left langitude must be a number',
            'right_lng.numeric' => 'Right longitude must be a number',
            //'bottom_lat' => 'required|numeric',
            //'right_lng' => 'required|numeric',

//            'upper_lat.lat' => 'Upper latitude format is not correct',
//            'upper_lngt.lng' => 'Upper longitude format is not correct',
//            'bottom_lat.lat' => 'Bottom latitude format is not correct',
//            'bottom_lng.lng' => 'Bottom longitude  format is not correct',
            'extra.max_zoom.integer' => 'Zoom must be a positive integer',
            'extra.max_zoom.min' => 'Zoom must be a positive integer',
            'extra.min_zoom.integer' => 'Zoom must be a positive integer',
            'extra.min_zoom.min' => 'Zoom must be a positive integer',
            'extra.default_zoom.integer' => 'Zoom must be a positive integer',
            'extra.default_zoom.min' => 'Default zoom must not be less than :min',
            'extra.default_zoom.max' => 'Default zoom must not be greater than :max',
        ];
    }
}
