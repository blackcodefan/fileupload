<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StripeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'plan' => 'required',
            'name'=> 'required|regex:/^[a-zA-Z ]*$/',
            'token' => 'required',
        ];
    }

    /**
     * Return error messages
     */

    public function messages(){
        return [
            'plan.required' => 'Please select a plan first',
            'token.required' => 'Stripe token cannot be empty',
            'name.required' => 'Name cannot be empty',
            'name.regex' => 'Name can only allow alphabets with spaces'
        ];
    }
}
