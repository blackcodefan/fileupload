<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TypesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $validation = [];

        switch ($this->method())
        {
            case 'GET':
            case 'DELETE':
                {
                    return [];
                }
            case 'POST':
                {
                   
                    $validation['name']='required|regex:/(^[A-Za-z0-9 -]+$)+/';
                    // $validation['name'] = 'required';
                    $validation['slug'] = 'required|alpha_dash|unique:types';
                    //$validation['parent'] = 'required';
                    return $validation;
                }
            case 'PUT':
            case 'PATCH':
                {
                    $id = $this->route('type')->id;
                    $validation['name']='required|regex:/(^[A-Za-z0-9 -]+$)+/';
                    // $validation['name'] = 'required' ;
                    $validation['slug'] = "required|alpha_dash|unique:types,slug,$id,id";
                    //$validation['parent'] = 'required';
                    
                    return $validation;
                }
            default:break;
        }

        return $validation;
    }
    public function messages(){
        return [
            'name.regex' => 'Name may only contain letters, numbers, dashes and spaces'
        ];
    }
}
