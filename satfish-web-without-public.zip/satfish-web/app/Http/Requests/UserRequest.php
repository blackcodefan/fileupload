<?php

namespace Satfish\Http\Requests;
use phpDocumentor\Reflection\Types\Parent_;
use Satfish\Http\Requests\PersonRequest;
use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends PersonRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $validation = Parent::rules();

        $validation +=  [
            'name' => 'required|string|max:255',
        ];

        switch ($this->method())
        {
            case 'GET':
            case 'DELETE':
                {
                    return [];
                }
            case 'POST':
                {

                    $validation['name'] = 'required|regex:/(^[A-Za-z0-9_ -]+$)+/|unique:users';
                    $validation['person.first_name'] = 'required|regex:/^[a-zA-Z ]*$/';
                    $validation['person.last_name'] = 'required|regex:/^[a-zA-Z ]*$/';
                    $validation['person.phone'] = 'required|numeric';
                    $validation['email'] = 'required|string|email|max:255|unique:users';
                    $validation['password'] = 'required|string|min:6|confirmed';
                    $validation['person.zip_code'] = 'required|numeric';
                    $validation['person.phone'] = 'required|numeric';
                //    'person.first_name'    => 'required',
                //    'person.last_name'    => 'required',
                 
                    return $validation;
                }
            case 'PUT':
            case 'PATCH':
                {
                    // $id = $this->route('user')->id;
                    $id = $this->route('user');
                    $validation['name'] = "required||regex:/(^[A-Za-z0-9_ -]+$)+/|unique:users,name," . $id;
                    $validation['person.first_name'] = 'required|regex:/^[a-zA-Z ]*$/';
                    $validation['person.last_name'] = 'required|regex:/^[a-zA-Z ]*$/';
                    $validation['person.phone'] = 'required|numeric';
                    $validation['email'] = "required|string|email|unique:users,email,$id,id";
                    $validation['person.zip_code'] = 'required|numeric';    
                    return $validation;
                }
            default:break;
        }

        return $validation;
    }

    public function messages(){
       // $messages = Parent::messages();
       // return $messages;
       return [
        'name.required'=>'Username is required',
        'name.regex' => 'UserName may only contain letters,numbers,dash,underscores and spaces',
        'email.required'=>'Email is required',
        'password.required'=>'Password is required',
        'person.first_name.required'=> 'First Name is required',
        'person.last_name.required' => 'Last Name is required', 
        'person.first_name.regex'=> 'First Name may only contain alphabets',
        'person.last_name.regex' => 'Last Name  may only contain alphabets',  
        'person.phone.numeric' => "Phone may only contain numbers",
        'person.phone.required' => " Phone  is required",
        //'person.boat_name.required' => 'Please enter boat name',fa
        'person.street.required'    => 'Street is required',
        'person.street.numeric'      => 'Street may only contain numbers', 
        'person.street.regex'      => 'Street may only contain alphabets,numbers and dash', 
        'person.city.required'      =>   'City is required',
        'person.city.alpha'      =>     'City may only contain alphabets',
        'person.state.required'     =>   'State is required',
        'person.state.alpha'      =>     'State may only contain alphabets',
        'person.zip_code.required' => " Zip Code is required",
        'person.zip_code.numeric' => "Zip Code fields may only contain numbers",
        'person.country.required' => " Country is required",
            // 'person.zip_code.required'  =>   'Please enter zip code',
            // 'person.country.required'   =>   'Please select country',

    ];
    }
}

