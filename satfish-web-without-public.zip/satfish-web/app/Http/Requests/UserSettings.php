<?php

namespace Satfish\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Satfish\User;

class UserSettings extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
    	$validation = [];

	    switch ($this->method())
	    {
		    case 'GET':
		    case 'DELETE':
			    {
				    return [];
			    }
		    case 'POST':
			    {
			    	$user_id = $this->route('uid') ? $this->route('uid') : Auth::user()->id;
				    $validation['email'] = "required|string|email|unique:users,email,$user_id,id";
					$validation['password'] = 'nullable|string|min:6|confirmed';
					$validation['person.first_name'] = 'required|regex:/^[a-zA-Z ]*$/';
                    $validation['person.last_name'] = 'required|regex:/^[a-zA-Z ]*$/';
					$validation['person.phone'] = "required|numeric";
				    return $validation;
			    }
		    case 'PUT':
		    case 'PATCH':
			    {
				    // $id = $this->route('user')->id;
				    $id = $this->route('user');
				    $validation['name'] = "required|alpha_dash|unique:users,name," . $id;
					$validation['email'] = "required|string|email|unique:users,email,$id,id";
					$validation['person.first_name'] = 'required|regex:/^[a-zA-Z ]*$/';
                    $validation['person.last_name'] = 'required|regex:/^[a-zA-Z ]*$/';
					$validation['person.phone'] = "required|numeric";
					
					//person.phone
				    return $validation;
			    }
		    default:break;
	    }

	    return $validation;
	}
	public function messages(){
		// $messages = Parent::messages();
		// return $messages;
		return [
		 'name.required'=>'Username is Required',
		 'email.required'=>'Email is Required',
		 'person.first_name.required'=> 'First Name is required',
		 'person.last_name.required' => 'Last Name is required', 
		  'person.first_name.regex'=> 'First Name may only contain alphabets',
		  'person.last_name.regex' => 'Last Name  may only contain alphabets', 
		 'person.phone.numeric' => "Phone may only contain numbers",
		 'person.phone.required' => " Phone  is required",
	 ];
	 }
}
