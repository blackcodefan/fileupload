<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CouponBatchResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'code' => $this->coupon->code,
            'discount' => $this->getDiscount($this->coupon->discount_type,$this->discount),
            'is_disabled' => ($this->is_disabled)? 'Disabled':'Active',
            'product_ids' => implode(",",$this->product_ids),
            'brand' => $this->brand,
            'duration' => !empty($this->duration)? ucfirst($this->duration):'',
        ];
    }

    public function getDiscount($type,$discount){
        if($type == 'percent' OR $type == 'percentage'){
            return $discount."%";
        }else{
            return "$".$discount;
        }
    }


}
