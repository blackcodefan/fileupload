<?php

namespace Satfish\Http\Resources;

use Satfish\Helpers\Brand;
use Satfish\Http\Resources\CouponBatchResource;
use Stripe\Plan;
use Illuminate\Http\Resources\Json\JsonResource;

class CouponResource extends JsonResource
{

    private $plans;



    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {


        return [
            'id' => $this->id,
            'code' => ($this->coupon->count() > 0)? $this->coupon->first()->code: null,
            'discount' => $this->getDiscount($this->discount_type,$this->discount),
            'is_disabled' => $this->is_disabled,
            'duration' => $this->duration,
            'use_count' => $this->use_count,
            'brand' => Brand::getDetails($this->brand, 'name'),
            'user_use_count' => $this->user_use_count,
        ];
    }

    public function getProductIds($productIds){

        $this->setPlans();
        if(is_array($productIds)){
           //$products =  implode(",",$this->batch->product_ids);
           $str = "<ul>";
           foreach($productIds as $product){
               $plan = $this->plans[$product];
               $str .="<li>$plan</li>";
           }
           $str .="</ul>";
           return $str;
        }

        return '';

    }

    public function setPlans(){

        if(empty($this->plans)){
//            \Stripe\Stripe::setApiKey(config('services.stripe.secret'));
            \Stripe\Stripe::setApiKey(Brand::active('stripe_secret'));
            $this->plans = collect(Plan::all()->data);
            $this->plans = $this->plans->pluck('name','id')->toArray();
        }

        return $this->plans;



    }


    public function getDiscount($type,$discount){
        if($type == 'percent' OR $type == 'percentage'){
            return $discount."%";
        }else{
            return "$".$discount;
        }
    }
}
