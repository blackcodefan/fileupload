<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class HotBites extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'category' => $this->whenLoaded('categories'),
            'title' => $this->title,
            'note' => $this->note,
            'lng' => $this->lng,
            'lat' => $this->lat,
            'type' => $this->type,
            'created_at' => $this->created_at,
//            'date_time_unix' => $this->date_time->timestamp * 1000,
            'date_time' => $this->date_time->toIso8601ZuluString(),
        ];
    }
}
