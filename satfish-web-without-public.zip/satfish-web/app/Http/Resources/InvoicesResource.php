<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InvoicesResource extends JsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
    	return [
    		'id'        =>  $this->id,
    		'number'        =>  $this->number,
    		'amount_due'        =>  $this->amount_due,
    		'amount_paid'        =>  $this->amount_paid,
    		'amount_remaining'        =>  $this->amount_remaining,
    		'application_fee'        =>  $this->application_fee,
    		'charge'        =>  $this->charge,
    		'closed'        =>  $this->closed,
    		'created'        =>  $this->created,
    		'created'        =>  $this->created,
    		'date'        =>  $this->date,
    		'due_date'        =>  $this->due_date,
    		'invoice_pdf'        =>  $this->invoice_pdf,
    		'paid'        =>  $this->paid,
    		'period_start'        =>  $this->period_start,
    		'period_end'        =>  $this->period_end,
    		'receipt_number'        =>  $this->receipt_number,
    		'status'        =>  $this->status,
    		'subscription'        =>  $this->lines->data[0],
	    ];
    }
}
