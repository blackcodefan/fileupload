<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Satfish\Helpers\General;

class LayersResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'region' => $this->whenLoaded('region'),
            'type' => $this->whenLoaded('type'),
//	        'source' => $this->media->first() ? 'image' : 'directory',
            'status' => $this->status,
            'tiled' => $this->tiled,
            'temp' => $this->temp ? $this->temp : ['start' => 0, 'end' => 100],
            'temp_switch' => $this->temp ? true : false,
            'preview' => General::layerThumbs($this),
            'image_url' => $this->full_image,
            'tiles_url' => $this->tiles_url,
            'exclusive' => $this->exclusive,
            'history' => $this->history,
            'sort_order' => $this->sort_order,
            'color_scale' => $this->color_scale,
            'created_at' => $this->created_at->toIso8601ZuluString()
        ];
    }
}
