<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MemCertResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $respone = parent::toArray($request);

        $respone['grace_period_unit'] = [
        	                        'code' => $respone['grace_period_unit'],
	                                'name' => ucfirst($respone['grace_period_unit'])
        ];
        return $respone;
    }
}
