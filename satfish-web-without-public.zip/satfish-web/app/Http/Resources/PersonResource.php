<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PersonResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {

        return [
            'full_name' => ucfirst($this->first_name). " ".ucfirst($this->last_name),
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'city' => $this->city,
            'street' => $this->street,
            'state' => $this->state,
            'country' => collect(['name' =>  $this->country_title, 'code' => $this->country]),
            'country_title' => $this->country_title,
            'boat_name' => $this->boat_name,
            'comments' => $this->comments,
            'phone' => $this->phone,
            'zip_code' => $this->zip_code,
            'created_at' => $this->created_at,
            'referral' =>  new TypesResource($this->whenLoaded( 'referral')),
        ];
    }
}
