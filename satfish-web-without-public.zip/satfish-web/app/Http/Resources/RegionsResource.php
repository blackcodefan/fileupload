<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class RegionsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {

        // return $this->resource->map(function ($user) {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'status' => $this->status,
            'upper_lat'=> $this->upper_lat,
            'left_lng' => $this->left_lng,
            'bottom_lat' => $this->bottom_lat,
            'right_lng' => $this->right_lng,
            'extra' => $this->extra,
            'brand'     => ['slug' => $this->brand, 'name' => config("satfish.brands.$this->brand.name")],
            'server' =>  isset($this->options)? $this->options->server:0,
            'station_id' =>isset($this->options)? $this->options->station_id:'',
            'location_id' => isset($this->options)? $this->options->location_id:'',
            'timezone' => isset($this->options)? $this->options->timezone:'',
            'height_unit' => isset($this->options)? $this->options->height_unit:'',
            'isdst' => isset($this->options)? $this->options->isdst:0,
            'frequency' => isset($this->options)? $this->options->frequency:'',
            'created_at' => $this->created_at,
        ];
        // });

    }
}
