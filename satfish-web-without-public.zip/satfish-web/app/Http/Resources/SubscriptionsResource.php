<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'stripe_plan' => $this->stripe_plan,
            'trial_ends_at' => $this->trial_ends_at,
            'ends_at' => $this->ends_at,
            'status' => $this->calculateStatus(),
	        'on_grace'  => $this->onGracePeriod(),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'created_at_humanize' => $this->created_at->diffForHumans(\Carbon\Carbon::now()),


            $this->mergeWhen(empty($this->ends_at),[
                'can_cancel_subscription' => true,
            ]),
        ];
    }

    protected function calculateStatus(){
        if(empty($this->ends_at) or strtotime($this->ends_at) <= 0){
            return 'active';
        }elseif(empty($this->ends_at) or strtotime($this->ends_at) >= 0){
            return 'expired';
        }else{
            return 'trial';
        }
    }
}
