<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Satfish\Helpers\General;

class TrialsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
	    return [
		    'id' => $this->id,
		    'user' => new UserResource($this->whenLoaded('user')),
		    'assignee' => new UserResource($this->whenLoaded('assignee')),
		    'status' => $this->status,
		    'valid_from' => $this->valid_from,
		    'valid_to' => $this->valid_to,
		    'comments' => $this->comments,
		    'created_at' => $this->created_at->toIso8601ZuluString()
	    ];
    }
}
