<?php

namespace Satfish\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserActivityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'client_ip' => $this->client_ip ."&nbsp;&nbsp;&nbsp;". $this->getCountryIcon($this->geo_ip),
            'browser_device' => $this->getBrowserIcon($this->agent,$this->device),
            //'referer' => $this->checkReferrer($this->referer),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'last_activity' => $this->updated_at->diffForHumans(\Carbon\Carbon::now(config('app.timezone'))),
            'username' => $this->user->name,
            'email' => $this->user->email,
        ];

    }

    protected function getBrowserIcon($agent,$device){

        $browsers = [
            'Opera' => 'opera',
            'Edge' => 'edge',
            'Chrome' => 'chrome',
            'Firefox' => 'firefox',
            'Safari' => 'safari',
            'IE' => 'internet-explorer',
        ];


        $browserIcon = 'compass';
        //$browserIcon = array_key_exists($agent->browser,$browsers)? $browsers[$agent->browser]: 'compass';

        foreach($browsers as $browser=>$icon){
            if(strpos(strtolower($agent->browser),strtolower($browser)) !== false){
               $browserIcon  = $icon;
            }
        }

        switch(strtolower($device->kind)){
            case 'Computer':
                $deviceKind =  "desktop";
                break;
            case 'Tablet':
                $deviceKind =  "tablet";
                break;
            case 'phone':
                $deviceKind =  "mobile";
                break;
            default:
                $deviceKind =  "laptop";
                break;
        }

        switch($device->platform){
            case 'Windows XP':
            case 'Windows 7':
            case 'Windows Vista':
            case 'Windows 8':
            case 'Windows 8.1':
            case 'Windows 10':
            case 'Windows NT':
            case 'Other':
                $devicePlatform =  "windows";
                break;
            case 'Debian':
            case 'Ubuntu':
            case 'Linux':
                $devicePlatform =  "linux";
                break;
            case 'PPC':
            case 'Macintosh':
            case 'Mac OS X':
            case 'PPC':
            case 'iOS':
                $devicePlatform =  "apple";
                break;
            case 'ChromeOS':
            case 'CrOS':
                $devicePlatform =  "chrome";
                break;
            case 'android':
            case 'Android':
                $devicePlatform =  "android";
                break;
            default:
                $devicePlatform =  "windows";
                break;
        }

        $icons = "<i class=\"fa fa-$deviceKind\" title=\"$device->kind\" style='font-size: 24px;'></i>&nbsp;&nbsp;&nbsp;<i class=\"fa fa-$devicePlatform \" title=\"$device->platform - $device->platform_version\" style='font-size: 24px;'></i>&nbsp;&nbsp;&nbsp;";


        return $icons. "<i class=\"fa fa-$browserIcon\" title=\"$agent->browser - $agent->browser_version\" style='font-size: 24px;'></i>";



    }

    protected function checkReferrer($referer){
        if(!empty($referer)){
            $url = $this->referer->url;
            $host = parse_url($url, PHP_URL_HOST);
            if($host !== env('APP_URL')){
                return $host;
            }
        }

        return '';
    }


    protected function getCountryIcon($country){
            if($country){
                $countryCode = strtolower($country->country_code);
                return "<i  title=\"$country->city - $country->country_name\" class=\"h4 mb-0 flag-icon flag-icon-$countryCode\"></i>";
            }


    }
}
