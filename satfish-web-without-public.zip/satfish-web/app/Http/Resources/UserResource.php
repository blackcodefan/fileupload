<?php

namespace Satfish\Http\Resources;

use Satfish\Type;
use Satfish\Http\Resources\PersonResource;
use Illuminate\Http\Resources\Json\Resource;
use Satfish\Http\Resources\TrialsResource;
use Satfish\Http\Resources\SubscriptionsResource;

class UserResource extends Resource {
	/**
	 * Transform the resource into an array.
	 *
	 * @param \Illuminate\Http\Request $request
	 *
	 * @return array
	 */
	public function toArray( $request ) {
		return [
			'id'         => $this->id,
			'name'       => $this->name,
			'email'      => $this->email,
			'person'     => new PersonResource( $this->person ),
			'brand'     => ['slug' => $this->brand, 'name' => config("satfish.brands.$this->brand.name")],
			'options'    => $this->convertingOptions(),
			'created_at' => $this->created_at,
            'email_verified' => $this->email_verified_at,
            'trial' => $this->trial,
            'can_access' => $this->can_access,
            'amember' => $this->amember_user,

//            'trial'     => new TrialsResource($this->whenLoaded('activeTrial')),
            'subscription' => $this->whenLoaded('activeSubscription', function(){
               return ($this->activeSubscription)? $this->activeSubscription->asStripeSubscription(): false;
            }),
		];
	}


	public function convertingOptions() {
		$finalOptions = [];
		if ( empty( $this->options ) ) {
			$this->options = ! empty( config( 'satfish.default_user_fields' ) ) ? config( 'satfish.default_user_fields' ) : [];;
		}

		foreach ( $this->options as $key => $option ) {
			if ( ! empty( $option ) ) {
				$finalOptions[ $key ] = Type::findOrFail( $option );
			}
		}

		return collect( $finalOptions );
	}
}

