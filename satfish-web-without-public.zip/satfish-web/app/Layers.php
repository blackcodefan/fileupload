<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Satfish\Helpers\General;
use Satfish\Traits\VueTableSearch;
use Spatie\MediaLibrary\Exceptions\FileCannotBeAdded\InvalidBase64Data;
use Spatie\MediaLibrary\FileAdder\FileAdder;
use Spatie\MediaLibrary\FileAdder\FileAdderFactory;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\Helpers\TemporaryDirectory;
use Spatie\MediaLibrary\Models\Media;

class Layers extends Model implements HasMedia {
	use VueTableSearch, HasMediaTrait;

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'region_id',
		'type_id',
		'tiled',
		'status',
        'imported',
		'temp',
		'created_at'
	];

	protected $appends = ['tiles_url', 'full_image' , 'exclusive', 'history', 'color_scale', 'sort_order', 'active'];

	protected $casts = [
		'temp'  =>  'array'
	];

	protected $filterJoins = ['region' => ['name'],'type' => ['name']];

	/**
	 * The table associated with the model.
	 *
	 * @var string
	 */
	protected $table = 'regions_layers';

	public function region() {
		return $this->belongsTo( 'Satfish\Region' );
	}

	public function type() {
		return $this->belongsTo( 'Satfish\Type' );
	}

	public function getRegionLayerAttribute() {
		return $this->region->name . ' - ' . $this->type->name;
	}

	/**
	 * History Attribute loaded from Config based on slug
	 *
	 * @param bool $slug
	 *
	 * @return bool|int
	 */
	public function getHistoryAttribute( $slug = false ) {
		$slug = $slug ? $slug : $this->type->slug;

		return General::getConfigAttribute( 'history', $slug );
	}

	/**
	 * @param Media|null $media
	 *
	 * @throws \Spatie\Image\Exceptions\InvalidManipulation
	 */
	public function registerMediaConversions( Media $media = null ) {
		$this->addMediaConversion( 'thumb' )
		     ->width( 100 )
		     ->height( 70 )
		     ->sharpen( 10 )
		     ->nonQueued();
	}


	/**
	 * Exclusive Attribute loaded from Config based on slug
	 *
	 * @param bool $slug
	 *
	 * @return bool
	 */
	public function getExclusiveAttribute( $slug = false ) {
		$slug = $slug ? $slug : $this->type->slug;

		return General::getConfigAttribute( 'exclusive', $slug );
	}

	/**
	 * Check if this layer got color scale based functionality
	 * @param bool $slug
	 *
	 * @return bool
	 */
	public function getColorScaleAttribute( $slug = false ) {
		$slug = $slug ? $slug : $this->type->slug;

		return General::getConfigAttribute( 'clrscale', $slug );
	}

	public function getSortOrderAttribute( $slug = false ) {
		$slug = $slug ? $slug : $this->type->slug;

		return General::getConfigAttribute( 'order', $slug );
	}

	public function getActiveAttribute( $slug = false ) {
		$slug = $slug ? $slug : $this->type->slug;

		return General::getConfigAttribute( 'active', $slug );
	}

	/**
	 *
	 * Filter Results based on joined table data
	 *
	 * @param $query
	 * @param $table
	 * @param $column
	 * @param $dir
	 *
	 * @return mixed
	 */
	public function scopeSortJoin( $query, $table, $column = 'id', $dir = 'asc' ) {


		switch ( $table ) {
			case 'regions' :
				$query
					->join( 'regions', 'regions.id', '=', $this->getTable() . '.region_id' );
				break;

			case 'types' :
				$query
					->join( 'types', 'types.id', '=', $this->getTable() . '.type_id' );
				break;
		}


		return $query
			->select( $this->getTable() . '.*', $column )
			->orderBy( DB::raw( $column ), $dir );
	}


    /**
     * Handling extraparam coming from vue table
     * @param $query
     * @param $request
     * @return mixed
     */
	public function checkExtraParams($query,$request){
        if($request->exists('extraParam') && !empty($request->extraParam)){
            $extraParam = json_decode($request->extraParam,true);
            $layer = $extraParam['layers'];
            $region = $extraParam['regions'];

            if(!empty($region)){
                $query->whereHas('region',function($q)use($region){
                    $q->where('regions.name',"$region");
                });
            }

            if(!empty($layer)){
                $query->whereHas('type',function($q)use($layer){
                    $q->where('types.name',"$layer");
                });
            }
        }
        return $query;
    }

	public function getTilesUrlAttribute() {

		if(config('satfish.layers.' . $this->type['slug'] . '.kml')) {
			return General::kmlUrl($this, $this->region->id);
		}

		return General::tilesUrl($this, $this->region->id);
	}

	public function getFullImageAttribute() {
		return url($this->getFirstMediaUrl('layers'));
//		return General::fullImgUrl($this, $this->region->id);
	}

	public function scopeActiveType($query) {
		return $query->whereHas('type', function ($q)  {
			$q->where('status', true);
		});
	}

}
