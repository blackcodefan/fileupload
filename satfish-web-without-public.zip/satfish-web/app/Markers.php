<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;
use Satfish\Traits\BoundsFilter;
use Satfish\Traits\VueTableSearch;

class Markers extends Model
{
    use VueTableSearch, BoundsFilter;

    protected $table = 'markers';
    protected $fillable = ['name', 'lat', 'lng', 'extra'];

	protected $casts = [
		'extra' => 'array',
	];

	protected $appends = ['icon', 'style', 'content', 'css_class', 'font_size', 'zoom_ctrl', 'allClasses'];


	public function getIconAttribute() {
		return isset($this->extra['icon']) ? $this->extra['icon'] : '0';
	}

	public function getStyleAttribute() {
		return isset($this->extra['style']) ? $this->extra['style'] : 'plain';
	}

	public function getContentAttribute() {
		return isset($this->extra['content']) ? $this->extra['content'] : '';
	}

	public function getCssClassAttribute() {
		return isset($this->extra['cssClass']) ? $this->extra['cssClass'] : '';
	}

	public function getAllClassesAttribute() {
		$rtrStr = '';

		//Font Styling
		if($this->style == 'plain' && $this->fontSize) {
			$rtrStr .= ' plain-' . $this->fontSize;
		}

		//Zoom Control
		if($this->zoomCtrl) {
			$zoomRange = explode('-', $this->zoomCtrl);

			$rtrStr .= ' label-z';

			if(isset($zoomRange[1]) && is_numeric($zoomRange[1])) {
				for($i = $zoomRange[0]; $i <= $zoomRange[1]; $i++) {
					$rtrStr .= ' label-z' . $i;
				}
			} else {
				$rtrStr .= ' label-z' . $zoomRange[0];
			}
		}

		//Any Manual Class
		if($this->cssClass) {
			$rtrStr .= ' ' . $this->cssClass;
		}

		return $rtrStr;
	}

	public function getFontSizeAttribute() {
		return isset($this->extra['font_size']) ? $this->extra['font_size'] : '';
	}

	public function getZoomCtrlAttribute() {
		return isset($this->extra['zoom_ctrl']) ? $this->extra['zoom_ctrl'] : '';
	}

}
