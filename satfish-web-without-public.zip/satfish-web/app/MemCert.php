<?php

namespace Satfish;

use Carbon\Carbon;
use Satfish\Traits\VueTableSearch;
use Illuminate\Database\Eloquent\Model;

class MemCert extends Model
{
    use VueTableSearch;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'code',
        'use_count',
        'grace_period_no',
        'grace_period_unit',
        'used_count',
        'valid_from',
        'valid_to',
        'status',
    ];


    protected $casts = [
        'data'  =>  'array'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'valid_from',
        'valid_to',
    ];

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'membership_certificate';

    public function couponUsage()
    {
        return $this->belongsToMany('Satfish\User', 'membership_certificate_usage', 'membership_certificate_id', 'user_id')->withTimestamps();
    }
}
