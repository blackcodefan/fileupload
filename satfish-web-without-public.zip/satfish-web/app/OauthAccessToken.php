<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class OauthAccessToken extends Model
{
    protected $table = "oauth_access_tokens";

}
