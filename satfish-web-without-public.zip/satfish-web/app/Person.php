<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class Person extends Model
{
    protected $table = 'persons';
    protected $fillable = ['first_name','last_name','city','state','state_title','zip_code','country_title','phone','street','country','referral_id','comments','boat_name'];
   protected $appends = array('fullname');

    public function user()
    {
        return $this->belongsTo('Satfish\User');
    }


    public function referral()
    {
        return $this->belongsTo('Satfish\Type','referral_id');
    }

    /**
     * Get boat of the user's person.
     */
    public function boat(){
        return $this->boat_name;
    }

    public function getFullNameAttribute() {
        return ucfirst($this->first_name) . ' ' . ucfirst($this->last_name);
    }


}
