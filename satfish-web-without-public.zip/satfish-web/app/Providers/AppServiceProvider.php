<?php

namespace Satfish\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Http\Resources\Json\Resource;
use Illuminate\Support\Facades\Validator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
	    if(!$this->app->environment('local')) {
		    \URL::forceScheme('https');
	    }

    	/** Validate Base64 file */
	    Validator::extend('base64', function ($attribute, $value, $parameters, $validator) {
	    	$explode = explode(',', $value);

		    $allow = $parameters ? $parameters : ['png', 'jpg', 'svg', 'jpeg', 'tif'];

		    $format = str_replace(
			    [
				    'data:image/',
				    'data:application/',
				    ';',
				    'base64',
			    ],
			    [
				    '', '', '', '',
			    ],
			    $explode[0]
		    );

		    // check file format
		    if (!in_array($format, $allow) && (in_array('kml', $allow) && $format != 'octet-stream' && $format != 'vnd.google-earth.kml+xml')) {
			    return false;
		    }
		    // check base64 format
		    if (!preg_match('%^[a-zA-Z0-9/+]*={0,2}$%', $explode[1])) {
			    return false;
		    }
		    return true;
	    });

	    Validator::replacer('base64', function ($message, $attribute, $rule, $parameters) {
		    $allow = $parameters ? $parameters : ['png', 'jpg', 'svg', 'jpeg', 'tif', 'txt'];
	    	return 'File not recongized. System only accepts ' . implode(', ', $allow);
	    });

	    /** Validate Latitude */
	    Validator::extend('lat', function ($attribute, $value, $parameters, $validator) {
		    if (!preg_match('/^(\+|-)?(?:90(?:(?:\.0{1,6})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,6})?))$/', $value)) {
			    return false;
		    }
		    return true;
	    });

	    Validator::replacer('lat', function ($message, $attribute, $rule, $parameters) {
		    return 'Latitude is not valid';
	    });

	    /** Validate Longitude */
	    Validator::extend('lng', function ($attribute, $value, $parameters, $validator) {
		    if (!preg_match('/^(\+|-)?(?:180(?:(?:\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,6})?))$/', $value)) {
			    return false;
		    }
		    return true;
	    });

	    Validator::replacer('lng', function ($message, $attribute, $rule, $parameters) {
		    return 'Longitude is not valid';
	    });

        Resource::withoutWrapping();
    }


    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
