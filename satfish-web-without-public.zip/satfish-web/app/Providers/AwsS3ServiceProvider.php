<?php

namespace Satfish\Providers;

use Illuminate\Support\Arr;
use Illuminate\Support\ServiceProvider;
use Satfish\Helpers\AwsS3Adapter as S3Adapter;
use Aws\S3\S3Client;
use League\Flysystem\Filesystem;
use Illuminate\Support\Facades\Storage;

class AwsS3ServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
	    Storage::extend('s3sf', function ($app, $config) {
		    $s3Config = $this->formatS3Config($config);

		    $root = $s3Config['root'] ?? null;

		    $options = $config['options'] ?? [];

		    return new Filesystem(new S3Adapter(new S3Client($s3Config), $s3Config['bucket'], $root, $options), $config );
	    });
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

	/**
	 * Format the given S3 configuration with the default options.
	 *
	 * @param  array  $config
	 * @return array
	 */
	protected function formatS3Config(array $config)
	{
		$config += ['version' => 'latest'];

		if ($config['key'] && $config['secret']) {
			$config['credentials'] = Arr::only($config, ['key', 'secret']);
		}

		return $config;
	}
}
