<?php


namespace Satfish;


class Referer extends \PragmaRX\Tracker\Vendor\Laravel\Models\Referer {

	public function setUrlAttribute($value)
	{
		$this->attributes['url'] = substr($value, 0, 254);
	}
}