<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class Refund extends Model
{
	protected $fillable = [
		'user_id', 'processed_by', 'amount', 'invoice_id','charge_id', 'refund_id', 'status', 'comments'
	];

	protected $casts = [
		'status' => 'boolean',
	];

	public function processor()
	{
		return $this->belongsTo('Satfish\User', 'processed_by');
	}
}
