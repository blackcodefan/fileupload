<?php

namespace Satfish;
use Satfish\Helpers\Brand;
use Satfish\Type;
use Illuminate\Database\Eloquent\Model;
use Satfish\Traits\VueTableSearch;

class Region extends Model
{
    use VueTableSearch;

    protected $casts = ['extra' => 'array'];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'slug', 'status', 'upper_lat', 'left_lng', 'bottom_lat', 'right_lng','extra','brand'
    ];

    protected $filterJoins = [];

    public function layers()
    {
        return $this->belongsToMany('Satfish\Type', 'regions_layers', 'region_id', 'type_id');
    }

	public function wind()
	{
		return $this->hasMany('Satfish\Wind');
	}

    public function options()
    {
        return $this->hasOne('Satfish\RegionOptions');
    }

	public function scopeActiveBrand($query)
	{
		return $query->whereBrand(Brand::active('slug'));
	}

	public function scopeActive($query)
	{
		return $query->whereStatus(true);
	}
}