<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class RegionOptions extends Model
{
    protected $table = 'region_options';
    protected $fillable = ['server','station_id','location_id','timezone','isdst','height_unit','frequency','date_from','date_to'];
//    protected $casts = ['noaa_data' => 'array'];
    protected $dates = ['data_from','data_to','created_at','updated_at','data_updated'];

    public function region(){
        return $this->belongsTo('Satfish\Region');
    }

    public function tidesData(){
        return $this->hasMany("Satfish\TidesData")->where('tides_data.server','server');
    }
}
