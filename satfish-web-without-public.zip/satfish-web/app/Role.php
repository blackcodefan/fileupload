<?php

namespace Satfish;
use Zizaco\Entrust\EntrustRole;

use Illuminate\Database\Eloquent\Model;

class Role extends EntrustRole
{
    protected $fillable = [
        'name',
        'display_name',
        'description'
    ];
    
    public $incrementing = false;

    protected $primaryKey = 'id';

    public function permission()
    {
        return $this->belongsToMany('Modules\Base\Models\Permission');
    }
}

