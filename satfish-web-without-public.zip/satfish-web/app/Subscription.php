<?php

namespace Satfish;

use Satfish\Traits\VueTableSearch;

class Subscription extends \Laravel\Cashier\Subscription
{
    use VueTableSearch;
}
