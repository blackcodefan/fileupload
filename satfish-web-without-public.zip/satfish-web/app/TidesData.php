<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class TidesData extends Model
{
    protected $table = 'tides_data';
    protected $fillable = ['region_options_id','server','data_date','data'];
    protected $casts = ['data' => 'array'];

    public function regionOptions(){
        return $this->belongsTo("Satfish\RegionOptions");
    }
}
