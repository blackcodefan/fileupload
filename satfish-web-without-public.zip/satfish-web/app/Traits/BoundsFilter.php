<?php
namespace Satfish\Traits;

use Satfish\Region;

trait BoundsFilter {

	/**
	 * A model method for getting enteries between bounds
	 * @param $query
	 * @param Region $region
	 *
	 * @return mixed
	 */
	public function scopeWithinRegion($query, Region $region) {
		return $query->whereBetween('lat', [$region->bottom_lat, $region->upper_lat])
		             ->whereBetween('lng', [$region->right_lng, $region->left_lng]);
	}
}