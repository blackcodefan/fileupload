<?php

namespace Satfish\Traits;

trait VueTableSearch {

    /**
     * filter and sorting process
     * @param $query
     * @return mixed
     */
    public function scopeVueTable($query) {
        $request = request();
        if ($request->has('sort') && $request->sort) {
            list($sortCol, $sortDir) = explode('|', request()->sort);
	        if( strpos( $sortCol, '.' ) !== false ) {
		        $sortDetails = explode('.', $sortCol);
		        $query = $query->sortJoin($sortDetails[0], $sortCol, $sortDir);
	        } else {
		        $query = $query->orderBy($sortCol, $sortDir);
	        }
        } else {
            $query = $query->orderBy('id', 'asc');
        }


        if ($request->exists('filter') && !empty($request->filter)) {

            $value = "%{$request->filter}%";
            //own table filter
            $query->Where(function($q) use($request) {
                $value = "%{$request->filter}%";
                $searchableCols = isset($this->searchAble) ? $this->searchAble : $this->fillable;

                foreach($searchableCols as $column) {
                    $q->orWhere($this->getTable().".".$column, 'like', $value);
                }
            });


            //joins filter
            if(property_exists($this,'filterJoins') && !empty($this->filterJoins)){
                foreach($this->filterJoins as  $join => $cols){
                    $query = $query->orWhereHas($join,function($q) use($value,$cols){
                        if(is_array($cols)){
                            foreach ($cols as $key => $col){
                                ($key == 0)? $q->where($col, 'like', $value): $q->orWhere($col, 'like', $value);
                            }
                        }else{
                            $q->where($cols,'like',$value);
                        }
                    });
                }
            }
        }

        if(method_exists($this,'checkExtraParams')){
            $this->checkExtraParams($query,$request);
        }


        $perPage = request()->has('per_page') ? (int) request()->per_page : null;
        return $query->paginate($perPage);
    }

}