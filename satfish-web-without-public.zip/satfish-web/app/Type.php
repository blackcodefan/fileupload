<?php

namespace Satfish;

use Baum\Node;
use Illuminate\Support\Facades\DB;
use Satfish\Region;
use Satfish\Traits\VueTableSearch;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

/**
 * Type
 */
class Type extends Node implements HasMedia
{

    use HasMediaTrait, VueTableSearch;
    /**
     * Table name.
     *
     * @var string
     */
    protected $table = 'types';

    protected $searchAble = [
        'name', 'slug',
    ];

    protected $fillable = ['name','slug','status','lat','lng','parent_id', 'order_id'];

    protected $filterJoins = ['parent' => ['name']];

     protected $parentColumn = 'parent_id';
     protected $leftColumn = 'lft';
     protected $rightColumn = 'rgt';
     protected $depthColumn = 'depth';
     protected $orderColumn = 'rgt';
     protected $guarded = array('id', 'parent_id', 'lft', 'rgt', 'depth');

    //
    // This is to support "scoping" which may allow to have multiple nested
    // set trees in the same database table.
    //
    // You should provide here the column names which should restrict Nested
    // Set queries. f.ex: company_id, etc.
    //

    // /**
    //  * Columns which restrict what we consider our Nested Set list
    //  *
    //  * @var array
    //  */
    // protected $scoped = array();

    //////////////////////////////////////////////////////////////////////////////

    //
    // Baum makes available two model events to application developers:
    //
    // 1. `moving`: fired *before* the a node movement operation is performed.
    //
    // 2. `moved`: fired *after* a node movement operation has been performed.
    //
    // In the same way as Eloquent's model events, returning false from the
    // `moving` event handler will halt the operation.
    //
    // Please refer the Laravel documentation for further instructions on how
    // to hook your own callbacks/observers into this events:
    // http://laravel.com/docs/5.0/eloquent#model-events

    public function region()
    {
        return $this->belongsToMany('Satfish\Region', 'regions_layers', 'type_id', 'region_id'); //->withPivot('user_id') if you need saving
    }

	/**
	 *
	 * Filter Results based on joined table data
	 *
	 * @param $query
	 * @param $table
	 * @param $column
	 * @param $dir
	 *
	 * @return mixed
	 */
	public function scopeSortJoin( $query, $table, $column, $dir ) {
		switch($table) {
			case 'parent' :
				return $query
					->leftJoin( 'types as parent', 'parent.id', '=', $this->getTable() . '.parent_id' )
					->select($this->getTable() .  '.*', $column . ' as parent_name')
					->orderBy('parent_name', $dir);
				break;
		}

		return $query
			->select($this->getTable() .  '.*', $column)
			->orderBy(DB::raw($column), $dir);
	}

	/**
	 * Get the "default" left column name.
	 *
	 * @return string
	 */
	public function getDefaultLeftColumnName()
	{
		return 'lft';
	}


	/**
	 * Get the "default" right column name.
	 *
	 * @return string
	 */
	public function getDefaultRightColumnName()
	{
		return 'rgt';
	}

    // public function region(){
    //   return $this->allRegions()->latest()->first();
    // }

}
