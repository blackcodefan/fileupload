<?php

namespace Satfish;

use Illuminate\Auth\Notifications\ResetPassword as ResetPasswordNotification;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\URL;
use Laravel\Cashier\Billable;
use Satfish\Helpers\Brand;
use Satfish\Helpers\Notifier;
use Satfish\Role;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Satfish\Traits\VueTableSearch;
use Stripe\Charge;
use Stripe\Refund as StripeRefund;
use Zizaco\Entrust\Traits\EntrustUserTrait;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Cog\Contracts\Ban\Bannable as BannableContract;
use Cog\Laravel\Ban\Traits\Bannable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Auth\MustVerifyEmail as TraitMustVerifyEmail;

class User extends Authenticatable implements BannableContract, MustVerifyEmail
{
    use HasApiTokens,Notifiable,EntrustUserTrait,VueTableSearch,Bannable,Billable, TraitMustVerifyEmail;

    public $timestamps = true;

    protected $profileUpdate = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','options','brand','amember_user', 'email_verified_at','card_name'
    ];

    protected $casts = [
        'options' => 'array',
	    'amember_user'  => 'boolean'
    ];

    protected $searchAble = [
        'name', 'email'
    ];

    protected $appends = [
    	'branded', 'can_access'
    ];

	/**
	 * The attributes that should be mutated to dates.
	 *
	 * @var array
	 */
	protected $dates = [
		'created_at',
		'updated_at',
		'trial_ends_at'
	];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function AauthAcessToken(){
        return $this->hasMany('Satfish\OauthAccessToken');
    }

    public function person(){
        return $this->hasOne('Satfish\Person');
    }

    public function trials() {
    	return $this->hasMany('Satfish\UserTrial');
    }

    public function getFullNameAttribute() {
    	if($this->person) {
    		return $this->person->fullname;
	    }

    	return $this->name;
    }

    public function getIsAdminAttribute() {
	    return in_array($this->id, config('satfish.superAdmin'));
    }

    public function getBrandedAttribute() {
    	return Brand::getDetails($this->brand);
    }

	/**
	 * Send the email verification notification.
	 *
	 * @return void
	 */
	public function sendEmailVerificationNotification() {

	    $hook = 'email_verify';
		if($this->profileUpdate)
        {
            $hook = 'email_update';
        }
        Notifier::notify('user.'.$hook,['user' => $this, 'verificationUrl' => $this->verificationUrl()],$this);
	}

	public function sendPasswordResetNotification($token)
	{
		Notifier::notify('user.password_reset',['user' => $this, 'url' => route('password.reset', $token)],$this);
	}

	public function setProfileUpdate($flag)
    {
        $this->profileUpdate = $flag;
    }

	protected function verificationUrl()
	{
		return URL::temporarySignedRoute(
			'verification.verify',
			Carbon::now()->addMinutes(Config::get('auth.verification.expire', 60)),
			['id' => $this->getKey()]
		);
	}

	public function refundInvoice($data) {
		$invoice = $this->findInvoiceOrFail($data['invoiceId']);
		$chargeId = $invoice->asStripeInvoice()->charge;
		$stripeAmnt = round($data['amount'] * 100);

		$refund = StripeRefund::create(['amount' => $stripeAmnt, 'charge' => $chargeId], ['api_key' => $this->getStripeKey()]);

		if($refund->status == 'succeeded') {
			Refund::create([
				'user_id'   =>  $data['userId'],
				'processed_by'  => Auth::user()->id,
				'amount'    =>  $data['amount'],
				'invoice_id'    =>  $data['invoiceId'],
				'charge_id' =>  $chargeId,
				'refund_id' => $refund->id,
				'comments' =>   $data['comments'],
				'status'    => true
			]);
		}

		return $refund;
	}

	/**
	 * Get all of the subscriptions for the Stripe model.
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\HasMany
	 */
	public function subscriptions()
	{
		return $this->hasMany(Subscription::class, $this->getForeignKey())->orderBy('created_at', 'desc');
	}


    public function pendingInvoices()
    {
        $invoices = [];

        $stripeInvoices = $this->asStripeCustomer()->invoices(['limit' => 24]);


        // Here we will loop through the Stripe invoices and create our own custom Invoice
        // instances that have more helper methods and are generally more convenient to
        // work with than the plain Stripe objects are. Then, we'll return the array.
        if (! is_null($stripeInvoices)) {
            foreach ($stripeInvoices->data as $invoice) {
                if ($invoice->paid) {
                    $invoices[] = new Invoice($this, $invoice);
                }
            }
        }

        return new Collection($invoices);
    }




	public function activeTrial()
    {
        $dt = Carbon::now();

//        return $this->hasOne('Satfish\UserTrial')->whereStatus(1)->whereRaw(" valid_from >= "."'$dt '". "AND valid_to <= "."'$dt' ");

        return $this->hasOne('Satfish\UserTrial')->whereStatus(1)->whereRaw('"'.$dt.'" between `valid_from` and `valid_to`');
    }

    public function getTrialAttribute() {
		return $this->onTrial() ? $this->trial_ends_at : false;
    }


    public function activeSubscription()
    {
        return $this->hasOne(Subscription::class, $this->getForeignKey())->orderBy('created_at', 'desc');
    }

    public function getCanAccessAttribute() {

		$sub = config('satfish.stripeDefault.name');
//		dd($this->subscription(config('satfish.stripeDefault.name'))->onGracePeriod());
		//Check if Email is active
	    if( isset($this->name) &&
//	    	$this->email_verified_at &&
		    (
	        $this->onTrial() || $this->amember_user
	        || ($this->subscription($sub) && $this->subscription($sub)->onGracePeriod())
	        || ($this->subscription($sub) && !$this->subscription($sub)->cancelled())
	       )
	    ) {
			return true;
	    }

		return false;
    }

}
