<?php

namespace Satfish;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Satfish\Traits\VueTableSearch;

class UserTrial extends Model
{
	use VueTableSearch;
	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'user_id', 'assigned_by', 'status', 'valid_from','valid_to','comments', 'membership_certificate_id'
	];

	protected $casts = [
		'status' => 'boolean',
//		'valid_from' => 'datetime',
//		'valid_to' => 'datetime'
	];

	protected $appends = [
		'type'
	];

	protected $dates = [
		'valid_from',
		'valid_to'
	];

	public function user()
	{
		return $this->belongsTo('Satfish\User');
	}

	public function assignee()
	{
		return $this->belongsTo('Satfish\User', 'assigned_by');
	}

	public function certificate()
	{
		return $this->belongsTo('Satfish\MemCert', 'membership_certificate_id');
	}

	public function getTypeAttribute() {
		if(in_array($this->assigned_by, config('satfish.superAdmin'))) {
			return 'Admin';
		} else {
			return 'Free Certificate';
		}
	}

	/**
	 * Get Users those have valid request and their Trial needs to be refreshed 
	 *
	 * @param $query
	 *
	 * @return mixed
	 */
	public function scopeEffective($query)
	{
		return $query
			->where('valid_to', '>', Carbon::now())
			->where('valid_from', '<', Carbon::now())
			->whereHas('user', function($q)
			{
				$q->where('trial_ends_at', '<', Carbon::now());
				$q->orWhereNull('trial_ends_at');
			});
	}
}
