<?php

namespace Satfish;

use Illuminate\Database\Eloquent\Model;

class Wind extends Model {
	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'region_id',
		'forecast',
		'data',
		'captured_at',
		'created_at'
	];

	protected $casts = [
		'data'  =>  'array'
	];

	protected $dates = [
		'created_at',
		'updated_at',
		'captured_at'
	];

	/**
	 * The table associated with the model.
	 *
	 * @var string
	 */
	protected $table = 'regions_wind';

	public function region() {
		return $this->belongsTo( 'Satfish\Region', 'region_id' );
	}
}
