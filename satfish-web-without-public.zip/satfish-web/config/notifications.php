<?php


return [
	'user.email_verify' => [
		'rel'   =>
			[
			   'self' =>
				   [
					   'subject' => '{{$user->name}} - Account Verification',
				   ],
			],

	],
    'membership.payment_failed' => [

        'rel' =>
            [
                'self' =>
                [
                    'subject' => 'Payment capture failed',
                ],
                'admin' =>
                [
                    'subject' => '{{$user->name}} - Payment capture failed',
                ]

            ]
    ],

    'membership.pending_invoices' => [
        'rel' => [
            'admin' => [
                'subject' => 'Pending Invoices',
            ]
        ]
    ],

    'user.email_update' => [
        'rel'   =>
            [
                'self' =>
                    [
                        'subject' => '{{$user->name}} - Account Verification',
                    ],
                'admin' =>
                    [
                        'subject' => '{{$user->name}} - Email Changed',
                    ]
            ],

    ],
    'user.email_verified' => [
        'rel'   =>
            [
                'self' =>
                    [
                        'subject' => '{{$user->name}} - Thank you for email verification',
                    ],
            ],

    ],

    'user.registered' => [
      'rel'   =>
          [
             'self' =>
             [
                 'subject' => '{{$user->name}} Registered',
            ],
          ],

    ],
	'user.signup' => [
		'rel'   =>
			[
				'admin' =>
					[
						'subject' => 'User Registration: {{$user->name}}',
					],
				'self' =>
					[
						'subject' => '{{$user->name}} - Membership Information',
					],
			],

	],
	'user.password_reset' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => '{{$user->name}} - Your Lost Password',
					],
			],

	],
	'user.password_changed' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => '{{$user->name}} - Password Changed',
					],
			],

	],

	'user.profile_changed' => [
		'rel'   =>
			[
				'admin' =>
					[
						'subject' => '{{$user->name}} - User profile has been changed',
					],
			],

	],


	'membership.invoice_pending' => [
		'rel'   =>
			[
				'admin' =>
					[
						'subject' => 'User Registration: {{$user->name}}',
					],
				'self' =>
					[
						'subject' => '{{$user->name}} - Account Verification',
					],
			],

	],
	'membership.receipt' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => '{{$user->name}} - Payment Receipt',
					],
			],

	],
	'membership.cancel' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => 'Automatic renewal cancelled',
					],
			],

	],

	'membership.rebill_stats' => [
		'rel'   =>
			[
				'admin' =>
					[
						'subject' => 'Rebill Statistics ',
					],
			],

	],

	'membership.cc_success' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => 'Subscription Renewed',
					],
			],

	],

	'membership.cc_expiry' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => 'Credit Card Expiration',
					],
			],

	],

	'membership.cc_failed' => [
		'rel'   =>
			[
				'self' =>
					[
						'subject' => 'Subscription Renewal Failed',
					],
			],

	],
];