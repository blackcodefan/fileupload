<?php

return [
    'default_user_fields' => [
        'gps_format' => 33,
        'temprature' => 37,
        'distance' => 40,
        'height' => 44 ,
        'speed' => 46,
    ],

    'superAdmin' => [
	    env('ADMIN_ID', 1), env('DEMO_ID', 0), env('JEFF_ID', 0)
    ],

	'stripeDefault' => [
		'name'  =>  env('STRIPE_SUB_NAME', 'Satfish')
	],

	'python' => env("PYTHON", 'python3'),

	'brands'    =>  [
		'satfish'   =>  [
			'slug'      =>  'satfish',
			'name'      =>  'Satfish',
			'assets'      =>  env('ST_APP_URL', 'https://satfish.test') . '/img/satfish',
			'email_from'=>  'support@satfish.com',
			'email_name'=>  'Satfish Support',
			'phone'=>  '‪(619) 356-3497',
			'home_url'  =>   'https://www.satfish.com',
			'app_host'   =>  env('ST_APP_HOST', 'app.satfish.com'),
			'app_url'   =>  env('ST_APP_URL', 'https://satfish.test'),

			'stripe_key' => env('ST_STRIPE_KEY', 'pk_test_1DhS6kzQRxYKpcv7XJ8Ky5I5'),
			'stripe_secret' => env('ST_STRIPE_SECRET', 'sk_test_OngMjEMyIfN5lYRW88TRzDA5'),

			//Features
		],
		'fishdope'  =>  [
			'slug'  =>  'fishdope',
			'name'  =>  'Fishdope',
			'assets'      =>  env('FD_APP_URL', 'https://fdapp.test') . '/img/fishdope',
			'email_from'=>  'support@fishdope.com',
			'email_name'=>  'Fishdope Support',
			'phone'=>  '(619) 992-6099',
			'home_url'  =>   'https://www.fishdope.com',
			'app_host'   =>  env('FD_APP_HOST', 'app.fishdope.com'),
			'app_url'   =>  env('FD_APP_URL', 'https://fdapp.test'),

			'stripe_key' => env('FD_STRIPE_KEY', 'pk_test_EPHbQOQIqNf44nHwwOBsCGHd'),
			'stripe_secret' => env('FD_STRIPE_SECRET', 'sk_test_zkxc0fwcPpPxNLgtu5Tgl5xR'),

			//Features
			'hotbites'  =>  true,
			'sso'       =>  false
		]
	],

	'zoom'   => [
		'default' => 10,
		'min'     => 10,
		'max'     => 12
	],
	'old_slugs' =>  [
		'baslay'   => 'bas_lay',
		'batlay'   => 'bat_lay',
		'mpalay'   => 'mpa_lay',
		'bdsc'  =>  'sst_msk',
		'fsst'  =>  'sst_opt',
		'st8'   =>  'sst_raw',
		'chl'   =>  'chl_msk',
//		'bz'    =>  'sst_bzo',
		'sst3dc'   => 'sst_3dc',
		'sstlay' => 'sst_lay',
		'sst1dc' => 'sst_1dc',
        'chl1dc' => 'chl_1dc',
		'chl3dc' => 'chl_3dc',
//      'imglay' => 'imglay',
		'truclr' => 'tru_clr',
        'dnb' => 'dnb',
//		'sshlay' => 'ssh_lay',
		'ssh' => 'ssh_hgt',
        'ssha' => 'ssh_sha',
        'cur' => 'ssh_gvl',
		'swh' => 'wav_swh',
		'wwh' => 'wav_wwh',
		'maplay' => 'map_lay',
		'lablay' => 'lab_lay',
		'geolay' => 'geo_lay'
 	],
	'buoys' => [
		'WDIR'  =>  [
			'title' =>  'Wind Direction',
			'unit'  =>  '°'
		],
		'WSPD'  =>  [
			'title' =>  'Wind Speed',
			'unit'  =>  'm/s',
			'type'  =>  'speed'
		],
		'GST'  =>  [
			'title' =>  'Wind Gust',
			'unit'  =>  'm/s',
			'type'  =>  'speed'
		],
		'WVHT'  =>  [
			'title' =>  'Wave Height',
			'unit'  =>  ' m',
			'type'  =>  'height'
		],
		'DPD'  =>  [
			'title' =>  'Dominant wave',
			'unit'  =>  'sec'
		],
		'APD'  =>  [
			'title' =>  'Average wave',
			'unit'  =>  ' sec'
		],
		'MWD'  =>  [
			'title' =>  'Wave Direction',
			'unit'  =>  '°'
		],
		'PRES'  =>  [
			'title' =>  'Sea level pressure',
			'unit'  =>  'hPa'
		],
		'PTDY'  =>  [
			'title' =>  'Pressure Tendency',
			'unit'  =>  'hPa'
		],
		'ATMP'  =>  [
			'title' =>  'Air temp.',
			'unit'  =>  ' °C',
			'type'  =>  'temp'
		],
		'WTMP'  =>  [
			'title' =>  'Water temp.',
			'unit'  =>  '°C',
			'type'  =>  'temp'
		],
		'DEWP'  =>  [
			'title' =>  'Dewpoint temp.',
			'unit'  =>  '°C',
			'type'  =>  'temp'
		],
		'VIS'  =>  [
			'title' =>  'Station visibility',
			'unit'  =>  'nmi'
		],
		'TIDE'  =>  [
			'title' =>  'Water Level',
			'unit'  =>  ' ft',
			'type'  =>  'height'
		],


	],
	'layers' => [
		'sst_lay' => [
			'name'  => 'Water Temperature',
			'class' => 'st-sst'
		],
		'sst_msk' => [
			'name'      => 'SST',
			'parent'    => 'sst_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 100,
			'db'        => true,
			'active'    => true,
			'clrscale'  =>  'sst',
			'class'     => 'st-processed-sst'
		],
		'sst_raw' => [
			'name'      => 'Raw SST',
			'parent'    => 'sst_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 110,
			'db'        => true,
			'clrscale'  =>  'sst',
			'class'     => 'st-raw-sst'
		],
		'sst_1dc' => [
			'name'      => '1-day Composite SST',
			'parent'    => 'sst_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 120,
			'db'        => true,
			'clrscale'  =>  'sst',
			'class'     => 'st-sst-day1'
		],
		'sst_3dc' => [
			'name'      => '3-day Composite SST',
			'parent'    => 'sst_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 130,
			'db'        => true,
			'clrscale'  =>  'sst',
			'class'     => 'st-sst-day3'
		],
		'sst_opt' => [
			'name'      => 'Cloud-Free SST',
			'parent'    => 'sst_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 140,
			'db'        => true,
			'clrscale'  =>  'sst',
			'class'     => 'st-cloud-free-sst'
		],
//		'sst_bzo' => [
//			'name'      => 'Bite Zone',
//			'parent'    => 'sst_lay',
//			'exclusive' => true,
//			'history'   => 7,
//			'order'     => 150,
//			'db'        => true,
//			'clrscale'  =>  'bz',
//			'class'     => 'st-bitzone'
//		],
		'chl_lay' => [
			'name'  => 'Water Color',
			'class' => 'st-water-color'
		],
		'chl_msk' => [
			'name'      => 'Chl',
			'parent'    => 'chl_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 160,
			'db'        => true,
			'clrscale'  =>  'chl',
			'class'     => 'st-chl'
		],
//		'chl_raw' => [
//			'name'      => 'Raw Chl',
//			'parent'    => 'chl_lay',
//			'exclusive' => true,
//			'history'   => 7,
//			'order'     => 170,
//			'db'        => true,
//			'clrscale'  =>  'chl',
//			'class'     => 'st-raw-chl'
//		],
        'chl_1dc' => [
             'name'      => '1-day Composite Chl',
             'parent'    => 'chl_lay',
             'exclusive' => true,
             'history'   => 7,
             'order'     => 170,
             'db'        => true,
             'clrscale'  =>  'chl',
             'class'     => 'st-composite-chl-day1'
         ],
		'chl_3dc' => [
			'name'      => '3-day Composite Chl',
			'parent'    => 'chl_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 180,
			'db'        => true,
			'clrscale'  =>  'chl',
			'class'     => 'st-composite-chl'
		],
        'imglay' => [
            'name'  => 'Imagery',
            'class' => 'st-imagery',
        ],
        'tru_clr' => [
			'name'      => 'True Color',
			'parent'    => 'imglay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 190,
			'db'        => true,
//			'clrscale'  =>  'chl',
			'class'     => 'st-true-color'
		],
        'dnb' => [
            'name'      => 'Night Vision',
            'parent'    => 'imglay',
            'exclusive' => true,
            'history'   => 7,
            'order'     => 200,
            'db'        => true,
//            'clrscale'  =>  'chl',
            'class'     => 'st-night-vision'
        ],
		'ssh_lay' => [
			'name'  => 'Altimetry / Currents',
			'class' => 'st-altimetry',
		],
		'ssh_hgt' => [
			'name'      => 'Sea Surface Height',
			'parent'    => 'ssh_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 210,
			'db'        => true,
			'class'     => 'st-ssh',
		],
		'ssh_sha' => [
            'name'      => 'Sea Surface Height Anomaly',
            'parent'    => 'ssh_lay',
            'exclusive' => true,
            'history'   => 7,
            'order'     => 210,
            'db'        => true,
            'class'     => 'st-ssh',
        ],'ssh_gvl' => [
			'name'      => 'Currents',
			'parent'    => 'ssh_lay',
			'exclusive' => true,
			'history'   => 7,
			'order'     => 220,
			'db'        => true,
            'clrscale'  =>  'sst',
			'class'     => 'st-currents'
		],
        'wnd_lay' => [
            'name'      => 'Wind',
//          'parent'    => 'ssh_lay',
            'exclusive' => true,
//          'history'   => 7,
            'order'     => 230,
            'class'     => 'st-wind'
        ],
		'wav_lay' => [
			'name'      => 'Waves',
            'class'    => 'st-waves',
//			'parent'    => 'ssh_lay',
//			'exclusive' => true,
//			'history'   => 7,
//			'order'     => 220,
		],
		'wav_swh' => [
			'name'      => 'Significant Wave Height',
			'parent'    => 'ssh_lay',
			'exclusive' => true,
//			'history'   => 7,
			'order'     => 240,
//			'db'        => true,
			'class'     => 'st-significant-wave'
		],
		'wav_wwh' => [
			'name'      => 'Wind Wave Height',
			'parent'    => 'ssh_lay',
			'exclusive' => true,
//			'history'   => 7,
			'order'     => 250,
//			'db'        => true,
			'class'     => 'st-wind-wave'
		],
		'mpa_lay' => [
			'name'  => 'Closures',
			'order' => 300,
			'db'    => true,
			'kml'    => true,
			'class' => 'st-closures'
		],

		'map_lay' => [
			'name'  => 'Map Layers',
			'class' => 'st-map-layer',
		],
		'bas_lay' => [
			'name'   => 'Base Layer',
			'parent'    => 'map_lay',
			'order'  => 10,
			'db'     => true,
			'class'  => 'st-base-layer',
			'active' => true,
		],
		'bat_lay' => [
			'name'   => 'Bathymetry',
			'parent'    => 'map_lay',
			'order'  => 400,
			'db'     => true,
			'kml'    => true,
			'class'  => 'st-bathymetry',
			'active' => true,
			'class'  => 'st-buoty'
		],
		'geo_lay' => [
			'name'   => 'Lat/Lon Grid',
			'parent'    => 'map_lay',
			'order'  => 400,
			'class'  => 'st-lat-lon',
			'active' => true,
		],
		'lab_lay'   => [
			'name'   => 'Labels',
			'parent'    => 'map_lay',
			'order'  => 500,
			'active' => true,
			'class'  => 'st-labels'
		],
		'buoys'   => [
			'name'   => 'Buoys',
			'parent'    => 'map_lay',
			'order'  => 510,
			'active' => false,
			'class'  => 'st-buoys'
		],
		'hob_lay'   => [
			'name'  => 'Hot Bites',
			'order' => 600,
			'class' => 'st-hot-bites'
		],
		'hob_lay_1' => [
			'name'   => '1 Day',
			'parent' => 'hob_lay',
			'order'  => 605,
			'active' => true,
			'class'  => 'st-1-day'
		],
		'hob_lay_2' => [
			'name'   => '2 Days',
			'parent' => 'hob_lay',
			'order'  => 610,
			'active' => true,
			'class'  => 'st-2-days'
		],
		'hob_lay_3' => [
			'name'   => '3 Days',
			'parent' => 'hob_lay',
			'order'  => 620,
			'active' => true,
			'class'  => 'st-3-days'
		],
		'hob_lay_4' => [
			'name'   => '4 Days',
			'parent' => 'hob_lay',
			'order'  => 630,
			'active' => true,
			'class'  => 'st-4-days'
		],
		'hob_lay_5' => [
			'name'   => '5 Days',
			'parent' => 'hob_lay',
			'order'  => 640,
			'active' => true,
			'class'  => 'st-5-days'
		],
		'hob_list' => [
			'name'   => 'List',
			'parent' => 'hob_lay',
			'order'  => 650,
			'active' => false,
			'class'  => 'st-hob_list'
		]
	],
    'timezone' => 'America/Los_Angeles',
];
