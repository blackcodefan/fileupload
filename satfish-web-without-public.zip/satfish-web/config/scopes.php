<?php

return [
    'admin'=>[
        'manage-roles' => 'Manage User roles',
        'manage-types' => 'Manage Types and layers',
        'manage-regions' => 'Manage regions',
        'manage-users' => 'Manage Users',
    ],
    'register' => [
        'can-view-layers' => 'View Layers',
        'can-view-regions' => 'Can view regions',
    ],

];