<?php

return [
    'wp_redirect' => env('WP_REDIRECT', false),
];