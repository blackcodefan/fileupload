<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBuoysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('buoys', function (Blueprint $table) {
            $table->increments('id');
	        $table->string('sid');
	        $table->string('name')->nullable();
	        $table->string('lat');
	        $table->string('lng');
	        $table->string('owner')->nullable();
	        $table->string('program')->nullable();
	        $table->string('type')->nullable();
	        $table->json('data')->nullable();
	        $table->tinyInteger('status')->default(1);
	        $table->timestamp('data_time')->useCurrent();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('buoys');
    }
}
