<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegionsWind extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('regions_wind', function (Blueprint $table) {
	        $table->increments('id');
	        $table->integer('region_id')->unsigned();
	        $table->integer('forecast')->unsigned();
	        $table->json('data');
	        $table->timestamp('captured_at');

	        $table->foreign('region_id')->references('id')->on('regions')
	              ->onDelete('cascade');

	        $table->timestamp('created_at')->useCurrent();
	        $table->timestamp('updated_at')->default(\DB::raw('CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP'));
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        Schema::table('regions_wind', function (Blueprint $table) {
	        Schema::dropIfExists('regions_wind');
        });
    }
}
