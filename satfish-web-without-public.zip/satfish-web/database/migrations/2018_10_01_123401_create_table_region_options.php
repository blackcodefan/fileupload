<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableRegionOptions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('region_options', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('region_id')->unsigned();
            $table->string('server');
            $table->string('station_id')->nullable();
            $table->string('location_id')->nullable();
            $table->string('timezone');
            $table->boolean('isdst');
            $table->integer('height_unit');
            $table->integer('frequency');
            $table->foreign('region_id')->references('id')->on('regions')
                ->onDelete('cascade');
            $table->timestamp('data_updated')->useCurrent();
            $table->timestamp('data_from')->nullable();
            $table->timestamp('data_to')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(\DB::raw('CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP'));
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS = 0');
        Schema::dropIfExists('region_options');
        DB::statement('SET FOREIGN_KEY_CHECKS = 1');

    }
}
