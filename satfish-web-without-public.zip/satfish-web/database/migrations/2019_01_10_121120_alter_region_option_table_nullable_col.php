<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterRegionOptionTableNullableCol extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('region_options', function($table)
        {
            $table->string('server')->nullable()->change();
            $table->string('timezone')->nullable()->change();
            $table->boolean('isdst')->nullable()->change();
            $table->integer('height_unit')->nullable()->change();
            $table->integer('frequency')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('region_options', function (Blueprint $table) {
            $table->string('server')->change();
            $table->string('timezone')->change();
            $table->boolean('isdst')->change();
            $table->integer('height_unit')->change();
            $table->integer('frequency')->change();
        });
    }
}
