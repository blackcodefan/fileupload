<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRefunds extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('refunds', function (Blueprint $table) {
	        $table->bigIncrements('id');
	        $table->integer('user_id')->unsigned();
	        $table->integer('processed_by')->unsigned();

	        $table->string('amount');
	        $table->string('invoice_id');
	        $table->string('charge_id');
	        $table->string('refund_id');

	        $table->boolean('status')->default(0);

	        $table->text('comments')->nullable();

	        $table->foreign('user_id')->references('id')->on('users')
	              ->onDelete('cascade');
	        $table->foreign('processed_by')->references('id')->on('users')
	              ->onDelete('cascade');

	        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('refunds');
    }
}
