<?php

use Illuminate\Database\Seeder;

class AmemberImporter extends Seeder
{

    protected $connection;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->connection = DB::connection('amember');
        $this->importStripeData();
        //
    }

    protected function importStripeData(){
        $amData = $this->connection->select('*')->from('am_data');
        dd($amData);
        foreach($amData as $data){
            $invoice = $this->connection->select('*')->from('am_invoice')->where('status',2)->whereNotNull('tm_cancelled');
            $userData[] = [
               'user_id' => $data['user_id'],
               '_cc_expires' => $data['stripe_cc_expires'],
                '_cc_masked' => $data['stripe_cc_masked'],
                'token' => $data['stripe_token'],



            ];
        }
    }
}
