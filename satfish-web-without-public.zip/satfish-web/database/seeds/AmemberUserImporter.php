<?php

use Illuminate\Database\Seeder;
use Satfish\User;

class AmemberUserImporter extends Seeder
{
    protected $connection;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->importUser();
    }

    public function importUser(){
        ini_set('max_execution_time', 3000);
        $this->connection = DB::connection('amember');

        $select = [
            'user_id','login','email','name_f','name_l','street','city','state','zip','country','phone','added'
        ];
        $pass = bcrypt('test123');
        $users = $this->connection->table('am_user')->select($select)->where('user_id','!=',8598)->get();
        $userInput = [];
        foreach ($users as $user) {
            $user = (array) $user;

            $userInput[] = [
                'user' => [
                    'id' => $user['user_id'],
                    'name' => $user['login'],
                    'email' => $user['email'],
                    'password' => $pass,
                    'created_at' => $this->validateDate($user['added'])? $user['added']:NULL,
                    'amember_user' => 1,
                ],
                'person' => [
                    'first_name' => $user['name_f'],
                    'last_name'  => $user['name_l'],
                    'street'     => $user['street'],
                    'city'       => $user['city'],
                    'state_title' => $user['state'],
                    'zip_code'   => $user['zip'],
                    'country'    => $user['country'],
                    'country_title' => $user['country'],
                    'phone' => $user['phone'],
                    'state' => $user['state'],
                    'referral_id' => 22,

                ],
            ];
        }

        foreach(array_chunk($userInput,500) as $users){
            foreach($users as $user){
                    $userExist = User::where('id',$user['user']['id'])->orWhere('email',$user['user']['email'])->first();
                    if(!$userExist)
                    {
                        $userCreated = User::create($user['user']);
                        $userCreated->person()->create($user['person']);
                    }
            }
        }
    }


    /**
     * Date validation process
     * @param $date
     * @param string $format
     * @return bool
     */
    public function validateDate($date, $format = 'Y-m-d h:i:s')
    {
        $d = DateTime::createFromFormat($format, $date);
        // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
        return $d && $d->format($format) === $date;
    }
}
