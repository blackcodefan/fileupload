<?php

use Illuminate\Database\Seeder;

class MembershipCertificateCoupon extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $coupons = '6S3JW,S3SD7,L7DAB,MR46M,DUFJ4,XLBNE,5S6EV,VAGLV,WEE3R,3WAFN,U7CF4,N8X5X,5PMZJ,5BQ55,GBXXN,X5TXD,XY7VM,TMGD7,T4LU6,GRAVH,G4TU9,W3P6Y,SM7KZ,W5PQC,XX9C9,HRZDM,UX5D4,6PARD,JMC6F,5KWFL,G9LHB,TN349,EB4F6,5K9ZP,84QDJ,XHG8U,GYSGW,7MYY6,C6V85,RX5JK,NZCLX,BNDE3,S36CL,L7XSV,AAPUN,N5BNF,TXBFF,R65ET,WZSUV,5L7PU,MHA8S,XTE9R,GPWKA,MYZVL,VJFX7,LQQYH,W45NY,MSAQW,ZPP8G,AQYUB,TUZ7U,HCUML,LTQJG,G34EU,EN5VR,WRHG3,9U3VU,BPRM9,6E3FS,44ZFE,SAJ8V,YZV39,8VPRA,GS8L7,RUGJR,K8YGF,TJNDW,6CK9S,E9FYD,3ZX3G,A7H4V,LE4EU,TD7V3,TGL8K,9H7DP,AXEYW,3RJ5Q,M5NC3,UYC4Z,UJDKG,V4LVS,UG4ZA,B838K,4EUA8,SLSRA,8ELY7,H8DJ4,UUZUK,AVFDH,EAQC4,4FB8J,UNUL8,KEXBL,GUJA3,YCMFW,LBCL4,YKTMM,G3DVY,WEEQH,GCBJ8,MWZPY,UHASL,66JSR,DG7FQ,ZQJ9E,56FUM,S9KE4,WGXZQ,Q9MPP,JPCFZ,XY67H,A9V9J,FAPMC,VDVLT,HE765,G6R6Z,RKRYW,UT8FC,N6RL9,PHKPV,QHB9K,CGTED,GPJT6,SKF9W,SDB7T,7LWWS,ZQXDZ,A6NLQ,WWEK9,6XLXF,HGUHB,BRUUB,7QUCG,5SM6R,PU4ZT,Y4VLJ,YLRDE,UJEB9,64DUP,F4WNU';
        $coupons = explode(",",$coupons);
        foreach ($coupons as $coupon)
        {
            $input[] = [
                'code' => $coupon,
                'use_count' => 1,
                'grace_period_no' => 1,
                'grace_period_unit' => 'year',
                'status' => 1,
            ];

        }

        \Satfish\MemCert::insert($input);
    }
}
