<?php

use Illuminate\Database\Seeder;
use Satfish\Role;
class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin= new Role();
        $admin->name         = 'admin';
        $admin->display_name = 'Administrator'; // optional
        $admin->description  = 'User is the owner of a given project'; // optional
        $admin->save();

        $userRole = new Role();
        $userRole ->name         = 'register';
        $userRole ->display_name = 'Registered'; // optional
        $userRole ->description  = 'Normal register user'; // optional
        $userRole ->save();
    }
}
