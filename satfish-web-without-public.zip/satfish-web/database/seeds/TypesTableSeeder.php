<?php

use Illuminate\Database\Seeder;

use Satfish\Type;
class TypesTableSeeder extends Seeder
{

    protected $types = [
	    [
		    'name' => 'Hotbites Categories',
		    'slug' => 'hot_bites_categories',
		    'parent_id' => null
	    ],
	    [
		    'name' => 'Species Categories',
		    'slug' => 'species',
		    'parent_id' => null
	    ],
	    [
		    'name' => 'Referrals',
		    'slug' => 'referrals',
		    'parent_id' => null
	    ],
	    [
		    'name' => 'Layers',
		    'slug' => 'layers',
		    'parent_id' => null
	    ],
	    [
		    'name' => 'Bloodydecks',
		    'slug' => 'ref-bloodydecks',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Fishing Club / Boat Club',
		    'slug' => 'ref-club',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Fred Hall Show / Day at the Docks',
		    'slug' => 'ref-show',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Friend',
		    'slug' => 'ref-friend',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Radio Show',
		    'slug' => 'ref-radio',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Tackle Store',
		    'slug' => 'ref-store',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Web Search',
		    'slug' => 'ref-search',
		    'parent_id' => 3
	    ],
	    [
		    'name' => 'Other',
		    'slug' => 'ref-other',
		    'parent_id' => 3
	    ],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
	    foreach ($this->types as $type) {
		    Type::create($type);
	    }
	    $layers = config( 'satfish.layers' );
	    //Insert Layers first
	    foreach($layers as $slug => $layer) {
	    	if(isset($layer['db']) && $layer['db']) {
			    Type::create([
				    'name' => $layer['name'],
				    'slug' => $slug,
				    'parent_id' => 4
			    ]);
		    }
	    }
    }
}
