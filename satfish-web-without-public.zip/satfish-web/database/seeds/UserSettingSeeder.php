<?php

use Illuminate\Database\Seeder;
use Satfish\Type;

class UserSettingSeeder extends Seeder
{
    protected $userOptionTypes = [
        [
            'name' => 'GPS Format Options',
            'slug' => 'gps_format_options',
            'parent_id' => null,
            'children' => [
                [
                    'name' => 'DD MM.mmm\' (Fishdope default)',
                    'slug' =>  'gps_format_fishdope_default',
                ],
                [
                    'name' => 'DD MM\' SS"',
                    'slug' =>  'gps_format_second_option',
                ],
                [
                    'name' => 'DD.ddddd (system input)',
                    'slug' =>  'gps_format_system_input',
                ]
            ],
        ],
        [
            'name' => 'Temprature',
            'slug' => 'temprature',
            'children' => [
                [
                    'name' => 'F (Fishdope default)',
                    'slug' => 'temprature_f',
                ],
                [
                    'name' => 'c',
                    'slug' => 'temprature_c',
                ],
            ],
        ],
        [
            'name' => 'Distance',
            'slug' => 'distance',
            'children' => [
                [
                    'name' => 'NM (Fishdope default)',
                    'slug' => 'distance_nm',
                ],
                [
                    'name' => 'Mi',
                    'slug' => 'distance_mi',
                ],
                [
                    'name' => 'Km',
                    'slug' => 'distance_km',
                ],
            ],
        ],
        [
            'name' => 'Height',
            'slug' => 'height',
            'children' => [
                [
                    'name' => 'cm',
                    'slug' => 'height_cm',
                ],
            ],
        ],
        [
            'name' => 'Speed',
            'slug' => 'speed',
            'children' => [
                [
                    'name' => 'Kts (Fishdope default)',
                    'slug' => 'speed_kts',
                ],
                [
                    'name' => 'Mph',
                    'slug' => 'speed_mph',
                ],
                [
                    'name' => 'Km/hr',
                    'slug' => 'speed_km_hr',
                ],
            ],
        ],

    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach ($this->userOptionTypes as $type) {

            $children = $type['children'];
            unset($type['children']);
            $type = Type::create($type);
            if(!empty($children)){
                foreach($children as $child){
                    $child = Type::create($child);
                    $child->makeChildOf($type);
                }
            }
        }
    }


}
