<?php

use Satfish\User;

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    protected $connection;
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Admin User
        DB::table('users')->insert([
            'name' => 'admin',
            'email' => 'test@test.com',
            'password' => bcrypt('testing123'),
	        'brand' => 'satfish'
        ]);

//	    DB::table('persons')->insert([
//		    'first_name' => 'Site',
//		    'last_name' => 'Admin',
//		    'phone' => '2342342343',
//		    'street' => 'Testing Street',
//		    'city' => 'City thing',
//		    'state' => 'PU',
//		    'state_title' => 'Punjab',
//		    'zip_code' => '51310',
//		    'country' => 'PK',
//	    ]);

    }



}
