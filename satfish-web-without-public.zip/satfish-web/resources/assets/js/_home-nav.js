export default {
    items: [
        {
            name: 'Regions',
            url: '/regions',
            icon: 'icon-globe'
        },
        {
            name: 'Billing',
            url: '/billing',
            icon: 'icon-calculator'
        },
        {
            name: 'Settings',
            url: '/settings',
            icon: 'icon-wrench'
        },
    ]
}