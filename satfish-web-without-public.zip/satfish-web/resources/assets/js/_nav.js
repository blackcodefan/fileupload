export default {
    items: [
        {
            name: 'Dashboard',
            url: '/dashboard',
            icon: 'icon-speedometer'
        },
        {
            name: 'Hot Bites',
            icon: 'fa fa-map-pin',
            url: '/hot-bites'
        },
        {
            name: 'Labels',
            icon: 'fa fa-map-marker',
            url: '/labels'
        },
        {
            name: 'Users',
            icon: 'icon-people',
            url: '/users',
            children: [
                {
                    name: 'All Users',
                    url: '/users#',
                    icon: 'fa fa-angle-right',
                },
                {
                    name: 'Users Activity',
                    url: '/users/activity',
                    icon: 'fa fa-angle-right',
                },
                {
                    name: 'Banned Users',
                    url: '/users/banned',
                    icon: 'fa fa-angle-right',
                },
                {
                    name: 'Coupons',
                    url: '/users/coupons',
                    icon: 'fa fa-angle-right',
                },
                {
                    name: 'Certificates',
                    url: '/users/certificates',
                    icon: 'fa fa-angle-right',
                },
            ]
        },
        {
            name: 'Regions',
            url: '/regions',
            icon: 'fa fa-globe'
        },
        {
            name: 'Layers',
            icon: 'fa fa-map',
            url: '/layers'
        },
        {
            name: 'Buoys Stations',
            url: '/buoys',
            icon: 'fa fa-cogs',
        },
        {
            name: 'CSV',
            icon: 'fa fa-sitemap',
            url: '/csv-import',
            children: [
                {
                    name: 'Import CSV',
                    url: '/csv-import',
                    icon: 'fa fa-angle-right',
                },
                {
                    name: 'Imported Files',
                    url: '/imported-files',
                    icon: 'fa fa-database',
                },
            ]
        },
        {
            name: 'Types',
            icon: 'fa fa-database',
            url: '/types'
        },
    ]
}