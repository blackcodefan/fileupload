<template>
  <footer class="app-footer">
    <span>Copyright   &copy; 2019 <a :href="brandHomeUrl">{{ brandName }}</a></span>
<!--    <span class="ml-auto">Developed by <a href="https://www.forumcube.com/">ForumCube</a></span>-->
  </footer>
</template>
<script>
export default {
  name: 'c-footer',
  data() {
    return {
      brandName: activeBrand.name,
      brandHomeUrl: activeBrand.home_url
    }
  }
}
</script>
