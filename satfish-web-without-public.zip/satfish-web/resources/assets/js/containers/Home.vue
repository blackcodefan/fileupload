<template>
    <div class="app">
        <AppHeader :navItems="nav" :user="user"/>
        <div class="app-body">
            <Sidebar :navItems="nav"/>
            <main class="main">
                <breadcrumb :list="list"/>
                <b-alert
                        v-show="freeUser"
                        v-bind:style="{margin:'25px'}"
                        show variant="danger"
                        v-if="$route.name != 'Regions'"
                >
                    Need to purchase new subscription? Please <a href="#" @click="stripeForm" class="alert-link"> click here </a>.

                </b-alert>

                <b-alert
                        v-show="showAccessError"
                        v-bind:style="{margin:'25px'}"
                        show variant="danger"
                        v-if="$route.name == 'Regions'"
                >
                    Seems like you dont have any subscription yet. Please <a href="#" @click="redirectBilling" class="alert-link"> visit billing page </a> to purchase
                    a new subscription.
                </b-alert>


                <b-alert
                        v-if="!emailVerified"
                        v-bind:style="{margin:'25px'}"
                        show variant="warning">
                    Your email has not been verified yet. Please verify your account.

                </b-alert>

                <b-alert
                        v-if="!emailVerified && !resentEmail"
                        v-bind:style="{margin:'25px'}"
                        show variant="warning">
                    If you haven't got the verification email yet, please <a href="#" @click="emailReVerify"
                                                                             class="alert-link">click here</a> to send
                    another

                </b-alert>

                <b-alert
                        v-if="!emailVerified && resentEmail"
                        v-bind:style="{margin:'25px'}"
                        show variant="success">
                    A new email is sent to your email. Please check your inbox and click on verification link

                </b-alert>


                <b-alert
                        v-if="showTrialNotice && emailVerified && $route.name != 'Regions'"
                        v-bind:style="{margin:'25px'}"
                        show variant="warning"
                >
                    Your trial period will expire on {{this.formatDate(trial)}}. Click
                    <a href="#" @click="stripeForm" class="alert-link"> here </a>
                    to purchase a membership

                </b-alert>


                <div class="container-fluid">
                    <div class="animated fadeIn">
<!--                        <h3 v-if="subscription || trial || amember">{{ $route.name }}</h3>-->
                        <h3 v-if="canAccess">{{ $route.name }}</h3>
                        <hr/>
                        <b-row v-if="$route.name != 'Regions'">
                            <b-col sm="12" md="8" lg="9">
                                <router-view v-if="renderContent"></router-view>
                            </b-col>
                            <AppAside ref="aside" :if="((subscription || trial) && emailVerified)"
                                      :subscription="subscription" :trial="trial"></AppAside>
                        </b-row>
                        <b-row v-else>
                            <b-col sm="12" v-if="canAccess">
                                <router-view v-if="renderContent"></router-view>
                            </b-col>
                        </b-row>
                    </div>
                </div>
            </main>
        </div>

        <AppFooter/>
    </div>
</template>

<script>
    import nav from '../_home-nav'
    import {Header as AppHeader, Aside as AppAside, Footer as AppFooter, Breadcrumb, Sidebar} from '../home-components/';
    import VueBus from 'vue-bus';


    export default {
        name: 'admin',
        components: {
            AppHeader,
            AppAside,
            AppFooter,
            Breadcrumb,
            Sidebar
        },
        data() {
            return {
                nav: nav.items,
                subscription: false,
                showAccessError: false,
                canAccess: false,
                amember: false,
                loading: false,
                freeUser: false,
                trial: false,
                showTrialNotice: false,
                user: false,
                emailVerified: true,
                resentEmail: false,
            }
        },
        computed: {
            name() {
                return this.$route.name
            },
            list() {
                return this.$route.matched
            },
            renderContent() {

                if (this.$route.name == 'Regions') {
                    return this.subscription || this.trial || this.amember;
                }

                return true;
            }
        },

        mounted() {
            let targetUrl = 'api/billing/subscription';
            var self = this;
            window.axios.get(targetUrl)
                .then(response => {

                    self.loading = false;
                    this.user = response.data;

                    if (response.data.hasOwnProperty('trial') && response.data.trial) {
                        this.trial = response.data.trial;
                    }

                    if (response.data.hasOwnProperty('subscription')) {
                        this.subscription = response.data.subscription;
                    }

                    if (response.data.hasOwnProperty('amember')) {
                        this.amember = response.data.amember;
                    }

                    if (response.data.hasOwnProperty('can_access')) {
                        this.canAccess = response.data.can_access;
                        this.showAccessError = !this.canAccess;
                    }

                    this.renderNotice();
                })
                .catch(error => {
                })

        },

        created() {

            this.$bus.on('updateSideBar', this.updateSideBar);
            this.$bus.on('emailVerify', this.emailVerify);
        },

        methods: {
            renderNotice() {
                this.emailVerified = (this.user.email_verified != null || this.amember) ? true : false;

                if (!this.subscription && this.trial) {
                    this.showTrialNotice = true;
                    return;
                }

                if (!this.subscription && !this.trial && !this.amember) {
                    this.freeUser = true;
                    return;
                }

                this.showTrialNotice = false;
                this.freeUser = false;
                return;
            },

            updateSideBar(data) {
                this.subscription = data.subscription;
                this.trial = (data.trial) ? data.trial : false;
                this.renderNotice();
            },

            emailVerify(data) {
                this.emailVerified = (data.email_verified != null) ? true : false;
            },

            stripeForm() {
                this.$refs.aside.openStripeForm();
            },

            redirectBilling() {
                this.$router.push('Billing');
            },

            emailReVerify() {
                let targetUrl = 'api/billing/re-verify';
                var self = this;
                window.axios.get(targetUrl)
                    .then(response => {
                        self.resentEmail = true;
                    })
                    .catch(error => {
                    })
            },
            formatDate(value, fmt = 'MMM DD, YYYY') {
                value = typeof value === 'object' ? value.date : value;
                return (value == null)
                    ? ''
                    : moment(value).format(fmt)
            }
        },


    }
</script>
