<template>
    <div class="animated fadeIn">
        <b-card>
            <div slot="header">
                <strong>{{ getFormTitle() }}</strong>
                <strong v-if="model.name">- {{ model.name }}</strong>
                <small v-if="editCase">#{{ editCase }}</small>
            </div>
            <b-alert variant="success"
                     dismissible
                     :show="showSuccessAlert"
                     @dismissed="showSuccessAlert=false">
                <span v-html="successMsg"></span>
            </b-alert>

            <b-alert variant="danger"
                     dismissible
                     :show="showErrors"
                     @dismissed="showErrors=false">
                <span v-html="errorMsg"></span>
            </b-alert>

            <b-form @reset="onReset" @submit.prevent="onSubmit">
                <vue-form-generator ref="vfg" :schema="schema" :model="model" :options="formOptions" @model-updated="onModelUpdated"></vue-form-generator>
                <div slot="footer">
                    <b-button v-show="RemoveBuoysButton"  type="submit" :disabled="disableSubmit"  size="sm" variant="primary"><i class="fa fa-dot-circle-o"></i> Submit
                    </b-button>
                    <b-button v-show="RemoveBuoysButton" v-if="editCase" type="reset" size="sm" variant="danger"><i class="fa fa-ban"></i> Reset</b-button>
                <!-- v-show="RemoveBuoysButton"  -->
                </div>
            </b-form>
        </b-card>
    </div>
</template>

<script>

    //Loading Pikaday Script
    window.moment = require('moment-timezone');
    // import 'moment-timezone';

    window.moment.tz.setDefault('America/Los_Angeles');


    window.Pikaday = require('pikaday');

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";
    import Multiselect from 'vue-multiselect';
    import FormMixin from "../Mixins/FormMixin";

    // Register my advance-select field
    import AdvanceSelect from "./AdvanceSelect";
    import DateTime from "./DateTime";

    Vue.component("advance-select", AdvanceSelect);
    Vue.component('multiselect', Multiselect);
    Vue.component('fieldFcdatetime', DateTime);


    Vue.use(VueFormGenerator);

    export default {
        name: "create-edit-form",
        mixins: [FormMixin],

        props: {
            formAction: {
                type: String,
                required: true
            },
            formMethod: {
                type: String,
                required: false,
            },
        
            model: {
                type: Object,
                required: true
            },
            schema: {
                type: Object,
                required: true
            },
            redirect: {
                type: String,
                required: false
            }
        },
        methods: {
            onModelUpdated(newVal, schema) {
                // console.log(this.model.name);
                this.$emit('model-updated', newVal, schema);
            },
        }
    }
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style src="vue-form-generator/dist/vfg.css"></style>

