<template>
    <datetime
            type="datetime"
            v-model="value"
            input-class="form-control"
            :phrases="params.phrases"
            value-zone="America/Los_Angeles"
             zone="America/Los_Angeles" 
            :format="params.format"
            :hour-step="params.hourStep"
            :minute-step="params.minuteStep"
            :min-datetime="params.minDate"
            :max-datetime="params.maxDate"
            :week-start="params.weekStart"
            :use12-hour="params.use12"
            auto
    ></datetime>
 <!-- 
     value-zone="Asia/Karachi"
            zone="Asia/Karachi"
     value-zone="America/Los_Angeles"
             zone="America/Los_Angeles" 
             -->    

</template>

<script>
    // import VueFormGenerator from "vue-form-generator";
    import { abstractField } from "vue-form-generator";
    import { Datetime } from 'vue-datetime';
    import 'vue-datetime/dist/vue-datetime.css'

    export default {
        name: 'fcdatetime',
        components: {
            datetime: Datetime
        },
        mixins: [abstractField],
        computed: {
            params() {
                return this.schema.params || {};
            },
        },
        methods: {
        },
    };
</script>

<style>
    .vdatetime {
        width: 100%;
    }
</style>