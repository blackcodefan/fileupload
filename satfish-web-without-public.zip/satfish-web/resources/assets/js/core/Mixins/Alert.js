export default {

    data() {
        return {

            disableSubmit: false,
            errors: {},
            alert: {
                type: 'success',
                show: false,
                msg: '',
            },
        }
    },
    methods: {


        showErrors(errors){
            var self = this;
            self.errors = errors;
            console.log(self.errors);
            var msg = '';

            if(typeof self.errors !== 'undefined') {

                if(typeof self.errors == 'string') {
                    msg = self.errors;
                   
                } else {
                    for (var k in self.errors) {
                        msg += '<li>' + self.errors[k] + '</li>';
                    }
                    msg = '<ul>' + msg + '</ul>';                   
                }
            } else {
                msg = 'Something went wrong';
            }


            self.alert = {
                show: true,
                type: 'danger',
                msg : msg,
            };
            self.$emit('errorCallBack');
        },
        showSuccess(response) {
            var msg = "";
            if (typeof response == 'string') {
                msg = response;
            } else if (typeof response == 'object') {
                msg = typeof response.message === 'string' ? response.message : 'Processed Successfully';
            }

            self.alert = {
                show: true,
                type: 'success',
                msg : msg,
            };

            self.$emit('successCallBack');
        },
        onReset(e) {
            e.preventDefault();
            // this.putDefault();
        },

        showAlert(){

        }

    },
    mounted() {

    },
    computed: {

    }
};