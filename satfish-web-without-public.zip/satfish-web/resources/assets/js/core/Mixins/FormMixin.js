export default {

    props: {
        formMethod: {
            type: String,
            required: false,
        },
        disableEditCase: {
            type: Boolean,
            required: false,
        },
    },
    data() {
        return {
            check:false,
            RemoveBuoysButton:true,
            editCase: 0,
            formOptions: {
                validateAfterLoad: false,
                validateAfterChanged: false
            },
            showSuccessAlert: false,
            successMsg: 'Form Updated',
            showErrors: false,
            errorMsg: '',
            disableSubmit: false,
        }
    },
    methods: {
        onSubmit(e) {
            this.errorMsg = '';
            this.showSuccessAlert = false,
            this.showErrors = false;
            this.disableSubmit = true;
            if(this.formAction==="/api/admin/trials/add"){
            this.check =moment(this.model.startDate).isAfter(this.model.endDate)
                if(this.check){
                    this.showErrors=true
                    this.disableSubmit = false;
                    this.errorMsg='End date should be greater then start date'
                    this.$emit('errorCallBack');
                }else{
                  this.postTrial()
            }
            }
            else {
                this.postTrial()
            }
        },
        showSuccess(response) {
            if (typeof response == 'string') {
                this.successMsg = response;
            } else if (typeof response == 'object') {
                this.successMsg = typeof response.message === 'string' ? response.message : 'Processed Successfully';
            }
        },
        onReset(e) {
            e.preventDefault();
            this.putDefault();
        },
        postTrial(){
            var self = this;
            //console.log('Validating', this.$refs);
            var validated = this.$refs.vfg.validate();
            var router = this.$router;
            if (validated) {
                var formAction = this.editCase ? this.formAction + '/' + this.editCase : this.formAction;
                var axiosLink = window.axios[this.autoFormMethod](formAction, this.model);
                axiosLink.then(response => {
                    self.disableSubmit = false;
                    this.showSuccess(response.data);
                    self.$emit('successCallback',response.data);
                    if(this.formAction==='/api/profile/settings'){
                        this.showSuccessAlert=true
                    }                    
                    if (typeof this.redirect !== 'undefined') {
                        router.push({ name: this.redirect});
                    }
                    // if (redirectPath && response.data.id) {
                    //     router.push({ name: redirectPath, params: { id: response.data.id }});
                    // } else if (this.redirect) {
                    //     router.push({ name: redirectPath});
                    // }    
                })
                .catch(e => {
                   // console.log(e);
                    //console.log(e.response)
                    //this.errorMsg = '';
                    this.disableSubmit = false;
                    if(typeof e.response !== 'undefined') {
                        if(typeof e.response.data.errors == 'string') {
                            this.errorMsg = (e.response.data.hasOwnProperty('message'))?  e.response.data.message:e.response.data.errors;
                        } else { 
                            for (var k in e.response.data.errors) {
                                this.errorMsg += '<li>' + e.response.data.errors[k] + '</li>';
                            }

                            this.errorMsg = '<ul>' + this.errorMsg + '</ul>';
                        }
                    }

                    else {
                        this.errorMsg = 'Something went wrong';
                    }
                
                    this.showErrors = true;
                    self.$emit('errorCallBack');
                });
            }
        },
        putDefault() {
            var self=this
            window.axios.get(this.formAction + '/' + this.editCase)
                .then(response => {
                    if(response.data.length!==0){
                        //self.$bus.emit('showLoader')
                        self.$bus.emit('OffLoader')
                        //Dynamically populate model data for forms
                    for (var i in response.data) {
                        if (typeof(this.model[i]) != 'undefined') {
                             //  if(this.model[i]='media'){
                             //   this.model.media=response.data.preview
                             //        //  response.data.image_url
                             // }
                            this.model[i] = response.data[i];
                        }  
                    }                  
                }
                })
                .catch(//e => {
                   // self.$bus.emit('showLoader')
                   self.$bus.emit('OnLoader')
                   // console.log(e);
                //});
                )
        },
        getFormTitle() {
            var item = this.$route;
            if (item.meta && item.meta.label) {
                return item.meta.label;
            }
            if (item.name) {
                return item.name;
            }

            return '';
        }
    },
    mounted() {
        //Edit casekar
         if(this.formAction==='/api/admin/buoys'){
             this.RemoveBuoysButton=false
        }
        if (this.$route.params.id > 0) {
            //Get Default Value in case of edit
            // this.putDefault();
            if(typeof this.disableEditCase !== 'undefined' && this.disableEditCase) {
                this.editCase = false;
            } else {
                this.editCase = this.$route.params.id;
                this.putDefault();
            }
        }
    },
    computed: {

        autoFormMethod() {

            if (this.formMethod) {
                return this.formMethod;
            }
            //if formMethod is on default
            if (this.editCase) {
                return 'patch';
            } else if (!this.editCase) {
                return 'post';
            }
        }
    }
};