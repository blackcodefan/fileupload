import accounting from 'accounting'
import moment from 'moment'
import 'moment-timezone';
import Vuetable from 'vuetable-2/src/components/Vuetable'
import VuetablePagination from 'vuetable-2/src/components/VuetablePagination'
import VuetablePaginationInfo from 'vuetable-2/src/components/VuetablePaginationInfo'
import Vue from 'vue'
import VueEvents from 'vue-events'
import FilterBar from '../VueTable/FilterBar'
import { assertModuleDeclaration } from 'babel-types';

Vue.use(VueEvents)
Vue.component('filter-bar', FilterBar)

export default {
    components: {
        Vuetable,
        VuetablePagination,
        VuetablePaginationInfo,
    },

    data() {
        return {
            DeleteShow:true,
            buoysCancelStatus:false,
            deleteSelected: false,
            css: {
                table: {
                    tableClass: 'table table-bordered table-striped table-hover',
                    ascendingIcon: 'glyphicon glyphicon-chevron-up',
                    descendingIcon: 'glyphicon glyphicon-chevron-down'
                },
                pagination: {
                    wrapperClass: 'pagination',
                    activeClass: 'active',
                    disabledClass: 'disabled',
                    pageClass: 'page',
                    linkClass: 'link',
                    icons: {
                        first: '',
                        prev: '',
                        next: '',
                        last: '',
                    },
                },
                icons: {
                    first: 'glyphicon glyphicon-step-backward',
                    prev: 'glyphicon glyphicon-chevron-left',
                    next: 'glyphicon glyphicon-chevron-right',
                    last: 'glyphicon glyphicon-step-forward',
                },
            },
            sortOrder: [
                { field: 'id', sortField: 'id', direction: 'desc'}
            ],
            moreParams: {}
        }
    },
    methods: {
        DeleteEntry(data, index){
            window.axios.delete(this.apiUrl + '/' + data.id)
            .then(response => {
                this.$refs.vuetable.refresh();
            })
            .catch(e => {
                console.log(e);
            }); 
        },
        itemDel (data, index) {
            if(this.apiUrl==='api/admin/buoys'){
                this.DeleteEntry(data,index)
            }
            else if (confirm('Are you sure to delete this entry?')) {
                this.DeleteEntry(data,index)
            }
        },
        renderStatus (value) {
            return (value == 1) ? 'Active':'Not active';
        },
        allcap (value) {
            return value.toUpperCase()
        },
        formatNumber (value) {
            return accounting.formatNumber(value, 2)
        },

        /**
         * @before default fmt DD-MM-YY now MMMM DD YYYY
         * @param value
         * @param fmt
         * @returns {string}
         */
        formatDate (value, fmt = 'MMM DD, YYYY') {
            value = 
            typeof value === 'object' ? value.date 
            :typeof value === 'number'? new Date(value*1000)
            :new Date(value)

            return (value == null)
                ? ''
                : moment(value).format(fmt)
        },
        formatMoney(amount, decimalCount = 2, decimal = ".", thousands = ",") {
            try {
                decimalCount = Math.abs(decimalCount);
                decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

                const negativeSign = amount < 0 ? "-" : "";

                let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
                let j = (i.length > 3) ? i.length % 3 : 0;

                return '$' + negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
            } catch (e) {
                console.log(e)
            }
        },
        formatStripeMoney(amount) {
            return this.formatMoney(amount/100);
        },
        switch (value) {
            return (value)
                ? '<span class="td-switch text-success"><i class="fa fa-check-circle "></i></span>'
                : '<span class="td-switch text-danger"><i class="fa fa-times-circle"></i></span>'
        },
        onPaginationData (paginationData) {
            this.$refs.pagination.setPaginationData(paginationData)
            if(this.$refs.hasOwnProperty('paginationInfo'))
            {
                this.$refs.paginationInfo.setPaginationData(paginationData)
            }
        },
        onChangePage (page) {
            this.$refs.vuetable.changePage(page)
        },
        onCellClicked (data, field, event) {
            // this.$refs.vuetable.toggleDetailRow(data.id)
            
            if(this.editRoute.length > 0){
                this.$router.push({ name: this.editRoute, params: { id: data.id }});
            }

        },
        myFetch(apiUrl, httpOptions) {
            // return Vue.$http.get(apiUrl, httpOptions)
            //return window.axios.get(apiUrl, httpOptions)
           var self = this;
           let check =/api\/admin\/invoices|trials|subscriptions\/[0-9]{1,7}$/
           let res =check.test(apiUrl)
           let data=window.axios.get(apiUrl, httpOptions)
            if(res)
           {
            self.$bus.emit('OffLoader')
           }else{
            data.then(function(resp){
                 if(apiUrl==='api/admin/buoys')
                    {  
                        self.DeleteShow=false
                        self.buoysCancelStatus=true
                        self.$bus.emit('OffLoader');
                }
                 else
                    { 
                      //self.$bus.emit('showLoader');
                      self.$bus.emit('OffLoader');
                }
                 }).catch(
                //self.$bus.emit('showLoader')                
                self.$bus.emit('OnLoader')
                    )
           }
           return  data
        },
        renderParent(value){
            return (value)? value:'No Parent';
        },
        checkboxClicked(){
            if(this.$refs.vuetable.selectedTo.length > 0){
                this.deleteSelected = true;
            }else{
                this.deleteSelected = false;
            }
        },
        deleteSelectedData(){
            var self = this;
            var selectedItems = this.$refs.vuetable.selectedTo;
            // alert(this.apiUrl + '/' + selectedItems);
            if (confirm('Are you sure to delete this entry?')) {
                window.axios.delete(this.apiUrl,{data:{ ids: selectedItems}})
                    .then(response => {
                        self.deleteSelected = false;
                        this.$refs.vuetable.refresh();
                    })
                    .catch(e => {
                        console.log(e);
                    });
            }
        },
        btnCallBack(callback,params){
            this.$emit(callback,params.id, params);
        }

    },
    events: {
        'filter-set' (filterText,extraParam) {
            this.moreParams = {
                filter: filterText.trim(),
            }
            if(typeof extraParam !== 'undefined'){
                this.moreParams = Object.assign(this.moreParams,{extraParam:extraParam});
            }
            Vue.nextTick( () => this.$refs.vuetable.refresh() )
        },
        'filter-reset' () {
            this.moreParams = {}
            //console.log()
            Vue.nextTick( () => this.$refs.vuetable.refresh() )
        },
        'data-reload' () {
            this.moreParams = {}
            Vue.nextTick( () => this.$refs.vuetable.reload() )
        },
    },
    mounted: function () {
        var self = this;
        this.$nextTick(function () {
            if(typeof self !== 'undefined' &&
                typeof self.$refs !== 'undefined' &&
                typeof self.$refs.vuetable !== 'undefined') {
                //Get the latest data after every 15 seconds
                this.interval = setInterval(() => self.$refs.vuetable.reload(), 15000);
            }
        })
    },
    beforeDestroy() {
        if (this.interval) {
            clearInterval(this.interval)
            this.interval = undefined
        }
    },
};
