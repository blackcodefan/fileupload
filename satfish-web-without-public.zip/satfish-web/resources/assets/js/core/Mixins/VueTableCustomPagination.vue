<template>
    <div  :class="css.wrapperClass">
        <a @click="loadPage(1)"
           :class="['btn-nav', css.linkClass, isOnFirstPage ? css.disabledClass : '']">
            <i v-if="css.icons.first != ''" :class="[css.icons.first]"></i>
            <span v-else>&laquo;</span>
        </a>
        <a @click="loadPage('prev')"
           :class="['btn-nav', css.linkClass, isOnFirstPage ? css.disabledClass : '']">
            <i v-if="css.icons.next != ''" :class="[css.icons.prev]"></i>
            <span v-else>&nbsp;&lsaquo;</span>
        </a>

         <a @click="loadPage('next')"
           :class="['btn-nav', css.linkClass, isOnLastPage ? css.disabledClass : '']">
            <i v-if="css.icons.next != ''" :class="[css.icons.next]"></i>
            <span v-else>&rsaquo;&nbsp;</span>
        </a> 
        <a @click="loadPage(totalPage)"
           :class="['btn-nav', css.linkClass, isOnLastPage ? css.disabledClass : '']">
            <i v-if="css.icons.last != ''" :class="[css.icons.last]"></i>
            <span v-else>&raquo;</span>
        </a>
    </div>
</template>

<script>

    import PaginationMixin from 'vuetable-2/src/components/VuetablePaginationMixin';
    export default {
        mixins: [PaginationMixin],
    }
</script>
