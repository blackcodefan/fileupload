<template>
    <div class="filter-bar">
        <form class="form-inline row">
            <div class="form-group col-md-5">
                <div class="input-group">
                    <input type="text" v-model="filterText" class="form-control" @keyup.enter="doFilter" placeholder="Search..." />
                    <div class="input-group-append">
                        <button class="btn btn-primary" @click.prevent="doFilter"><i class="fa fa-search"></i> <span>Filter</span></button>
                        <button class="btn" @click.prevent="resetFilter" title="Clear Filters"><i class="fa fa-times"></i> <span>Reset</span></button>
                    </div>
                </div>
            </div>
            <div class="form-group col-md-7 d-flex flex-row-reverse">
                <button class="btn btn-success " title="Reload Data" @click.prevent="reloadData"><i class="fa fa-retweet"></i> <span>Reload {{ this.$route.meta.label }}</span></button>
                <router-link :to="{ name: createRoute}" class="btn btn-primary" v-if="createRoute" title="Add New"><i class="fa fa-plus"></i> <span> {{ this.addTxt }}</span></router-link>
                <button v-if="deleteSelected" @click="deleteSelectedData"  class="btn btn-danger adm-del"><i class="icon-trash"></i> <span>Delete Selected</span></button>
                
                <div v-if="showLayerFilters">
                    <select  class="form-control" v-model="selectedRegion" @change="reloadFilters">
                        <option value="">-- Select Region --</option>
                        <option v-for="region in regions">{{region.name}}</option>
                    </select>
                    <select  class="form-control" v-model="selectedLayer" @change="reloadFilters">
                        <option value="">-- Select Layer --</option>
                        <option v-for="layer in layers">{{layer.name}}</option>
                    </select>
                </div>
            </div>
        </form>
    </div>
</template>

<script>
    export default {

        data () {
            return {
                filterText: '',
                selectedRegion: '',
                selectedLayer: '',
                layers: [],
                regions: [],
                addTxt: 'Add New'
            }
        },
        methods: {
            doFilter () {
                this.$events.fire('filter-set', this.filterText,{layers: this.selectedLayer,regions: this.selectedRegion})
            },
            resetFilter () {
                this.filterText = '';
                this.selectedLayer = '';
                this.selectedRegion = '';
                this.$events.fire('filter-reset')
            },
            reloadData() {
                this.filterText = '';
                this.selectedLayer = '';
                this.selectedRegion = '';
                this.$events.fire('data-reload')
            },
            reloadFilters(){
                this.$events.fire('filter-set', this.filterText,{layers: this.selectedLayer,regions: this.selectedRegion});
            },
            fetchRegions() {

                var self = this;
                return axios.get('/api/admin/regions/list').then(function(response){
                    self.regions = response.data;
                });
            },
            fetchLayers(){
                var self = this;
                return axios.get('/api/admin/types/children/layers').then(function(response){
                    self.layers = response.data;
                });
            },
        },
        mounted: function(){
            if(this.showLayerFilters){
                this.fetchRegions();
                this.fetchLayers();
            }

            if(this.createRoute) {
                let resolved = this.$router.resolve({name: this.createRoute});
                this.addTxt = resolved.route.meta.label ? resolved.route.meta.label : resolved.route.name;
            }

        },
        props: {
            'deleteSelected': {
                type: Boolean,
                required: true
            },
            'deleteSelectedData': {
                type: Function,
                required: true
            },
            'showLayerFilters': {
                type: Boolean,
                required: false,
            },
            'createRoute': {
                type: String,
                required: false,
                default: ''
            },
            
            // 'showLayerFilters': {
            //     type: Boolean,
            //     required: true
            // },
        },

    }
</script>
<style>
    .filter-bar {
        padding: 10px 0;
    }

    .filter-bar .btn span {
        display: none;
    }

    .filter-bar .btn:hover span {
        display: inline-block;
    }

</style>