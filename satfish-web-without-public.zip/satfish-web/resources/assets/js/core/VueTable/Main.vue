<template>
    <div>
        <filter-bar v-if="showFilterBar"
                    :deleteSelected="deleteSelected"
                    :deleteSelectedData="deleteSelectedData"
                    :showLayerFilters="showLayerFilters"
                    :createRoute="createRoute"
        ></filter-bar>
        <vuetable ref="vuetable"
                  :api-url="apiUrl"
                  :fields="fields"
                  pagination-path="meta"
                  :css="css.table"
                  :sort-order="sortOrder"
                  :multi-sort="true"
                  detail-row-component="my-detail-row"
                  :append-params="moreParams"
                  :http-fetch="myFetch"
                  @vuetable:checkbox-toggled="checkboxClicked"
                  @vuetable:checkbox-toggled-all="checkboxClicked"
                  @vuetable:cell-clicked="onCellClicked"
                  @vuetable:pagination-data="onPaginationData"
        >
        
            <template slot="actions" slot-scope="props">
                <div class="custom-actions">
                    <router-link v-if="showRoute" :to="{ name: showRoute, params: { id: props.rowData.id }}" class="btn btn-sm btn-primary"><i class="icon-eye"></i></router-link>
                    <router-link :to="{ name: editRoute, params: { id: props.rowData.id }}" title="Edit Record"  class="btn btn-warning btn-sm"><i class="icon-pencil"></i></router-link>
                    <button v-show="DeleteShow" class="btn btn-danger btn-sm" title="Delete Record" @click="itemDel(props.rowData, props.rowIndex)"><i class="icon-trash"></i></button>
                    <button v-show="buoysCancelStatus" class="btn btn-info btn-sm" title="Cancel Status" @click="itemDel(props.rowData, props.rowIndex)"><i  class="fa fa-toggle-off"></i></button>
                </div>
                
            </template>
            <template slot="customActions" slot-scope="props"><button  v-for="button in buttons"  @click="btnCallBack(button.callback, props.rowData)" :class="'btn btn-sm ' + button.className"><i :class="button.icon"></i> </button></template>


        </vuetable>
        <div class="vuetable-pagination">
            <vuetable-pagination-info v-if="!customPagination"  ref="paginationInfo"
                                      info-class="pagination-info"
            ></vuetable-pagination-info>

            <CustomPagination v-if="customPagination"  ref="pagination"
                              :css="css.pagination"
                              @vuetable-pagination:change-page="onChangePage">
            </CustomPagination>
            <vuetable-pagination v-else ref="pagination"
                                 :css="css.pagination"
                                 @vuetable-pagination:change-page="onChangePage"
            ></vuetable-pagination>



        </div>
    </div>
</template>

<script>

    import VueTableMixin from '../Mixins/VueTable';
    import CustomPagination from '../Mixins/VueTableCustomPagination';

    export default {

        mixins: [VueTableMixin],
        components: {CustomPagination},
        props: {
            'fields': {
                type: Array,
                required: true
            },
            'buttons': {
              type:Array,
              required:false,
            },

            'showFilterBar': {
              default: true,
              type:Boolean,
              required: false,
            },
            'showLayerFilters': {
                default: false,
                type: Boolean,
                required: false,
            },
            'apiUrl': {
                type: String,
                required: true
            },
            'editRoute': {
                type: String,
                required: false,
                default: ''
            },
            'createRoute': {
                type: String,
                required: false,
                default: ''
            },
            'showRoute': {
                type: String,
                required: false,
                default: ''
            },
            'customPagination' : {

                type: String,
                required: false,
                default: '',
            }
        },


    }
</script>
<style>

    .btn:focus, .btn.focus {
        box-shadow: none;
    }
    .pagination {
        margin: 0;
        float: right;
    }
    .pagination a.page {
        border: 1px solid lightgray;
        border-radius: 3px;
        padding: 5px 10px;
        margin-right: 2px;
        cursor: pointer;
    }
    .pagination a.page.active {
        color: white;
        background-color: #337ab7;
        border: 1px solid lightgray;
        border-radius: 3px;
        padding: 5px 10px;
        margin-right: 2px;
    }
    .pagination a.btn-nav {
        border: 1px solid lightgray;
        border-radius: 3px;
        padding: 5px 7px;
        margin-right: 2px;
        /**it too is added  */
        cursor: pointer;
    }
    .pagination a.btn-nav.disabled {
        color: lightgray;
        border: 1px solid lightgray;
        border-radius: 3px;
        padding: 5px 7px;
        margin-right: 2px;
        cursor: not-allowed;
    } 
    .pagination-info {
        float: left;
    }

    .pagination a.page:hover{
        background-color: #337ab7;
        color: #fff;
    }
   /**its being added to allow hover on the button of Pagination */ 
    .pagination a.btn-nav:hover{
        background-color: #337ab7;
        color: #fff;
    }
</style>