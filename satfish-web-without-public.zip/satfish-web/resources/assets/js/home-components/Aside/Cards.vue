<template>
    <div>
        <b-card v-if="card" class="bg-primary" header="Your Card">
            <div class="row">
            <span class="col-md-12 mb-1">
                ****  ****  ****  {{ card.last4 }}
            </span>
                <span class="col-md-6">
                Country: {{card.country}}
            </span>
                <div class="col-md-6">
                    
                <!-- <span class="btn btn-primary"> -->
                    <i :class="'fa fa-' + cardBrand"></i>
                <!-- </span> -->
            </div>
             <span class="col-md-12 mb-2">
                 Name: {{card.name}}
             </span>
                <b-button-group class="col-md-12">
                    <b-button variant="warning"  @click="stripeForm">Update Card</b-button>
                </b-button-group>

            </div>
        </b-card>



        <stripe-form postUrl="api/billing/card" type="card" ref="form" :showForm="showStripeForm"  :hidePlans="true" :hideCoupons="true"/>
    </div>

</template>

<script>
    import StripeForm from "../stripeForm";

    export default {
        name: "cards",
        components: {StripeForm},

        data: function () {
            return {
                card: false,
                cardBrand: '',
                showStripeForm: false,

            }
        },
        methods: {

            stripeForm: function() {
                this.$refs.form.openForm();
                this.showStripeForm = true;
            },

            getCards: function () {
                let self = this;
                window.axios.get('api/billing/card').then(function (response) {
                    self.card = response.data;
                    self.cardBrand = self.cardBrandIcon(self.card.brand);
                    console.log(self.cardBrand);
                });
            },

            cardBrandIcon: function (value) {
                let icoName = 'cc-visa';

                switch (value) {
                    case "Visa":
                    case "Diners Club" :
                    case "Discover" :
                    case "JCB" :
                    case "MasterCard" :
                        icoName = 'cc-' + this.slugify(value);
                        break;
                    case "American Express" :
                        icoName = 'cc-amex';
                        break;

                }

                return icoName;
            },

            slugify: function (string) {
                const a = 'àáäâãåăæçèéëêǵḧìíïîḿńǹñòóöôœøṕŕßśșțùúüûǘẃẍÿź·/_,:;'
                const b = 'aaaaaaaaceeeeghiiiimnnnooooooprssstuuuuuwxyz------'
                const p = new RegExp(a.split('').join('|'), 'g')

                return string.toString().toLowerCase()
                    .replace(/\s+/g, '-') // Replace spaces with -
                    .replace(p, c => b.charAt(a.indexOf(c))) // Replace special characters
                    .replace(/&/g, '-and-') // Replace & with ‘and’
                    .replace(/[^\w\-]+/g, '') // Remove all non-word characters
                    .replace(/\-\-+/g, '-') // Replace multiple - with single -
                    .replace(/^-+/, '') // Trim - from start of text
                    .replace(/-+$/, '') // Trim - from end of text
            },

            updateCard(card)
            {
                this.card = card;
                this.cardBrand = this.cardBrandIcon(card.brand);
            }
        },
        mounted: function () {
            this.getCards();
        }
    }
</script>