<template>
    <b-col sm="12" md="3">
        <menu-items />
        <br/>
        <Subscriptions ref="subscription" :subscription="subscription" :trial="trial" />
        <br />
        <cards />
    </b-col>



</template>

<script>
    import MenuItems from "./Menu";
    import Cards from "./Cards";
    import Subscriptions from "./Subscriptions";
    export default {
        props: {
            subscription: {
                type: [Object, Boolean],
                required: true,
            },
            trial: {
                type: [Object, Boolean],
                required: true,
            }
        },
        name: 'c-aside',
        components: {Subscriptions, Cards, MenuItems},

        methods: {
            openStripeForm() {
                return this.$refs.subscription.stripeForm();
            }
        }
    }
</script>
