<template>
    <b-list-group>
        <b-list-group-item v-for="(item, index) in nav" :to="item.url" v-bind:key="item.name" class="px-3">
            {{ item.name }}
        </b-list-group-item>
    </b-list-group>
</template>

<script>
    import nav from './../../_home-nav'
    export default {
        name: "c-menu",
        data() {
            return {
                nav: nav.items
            }
        },
    }
</script>