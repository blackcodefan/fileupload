<template>
    <div>
        <b-card v-if="subscription" :header="'Plan: ' + subscription.plan.name" :class="subCardColor" >
            <dl class="row text-left">
                <dt class="col-sm-5">Purchased On</dt>
                <dd class="col-sm-7">{{ this.formatDate(subscription.created) }}</dd>
                <dt class="col-sm-5">Current Period</dt>
                <dd class="col-sm-7">{{ this.formatDate(subscription.current_period_start) }} <br/> {{ this.formatDate(subscription.current_period_end) }}
                </dd>
                <dt class="col-sm-5">Status</dt>
                <dd class="col-sm-7">{{ subscription.status }}</dd>
                <dt class="col-sm-5">Auto-Renewal</dt>
                <dd class="col-sm-7" v-if="subscription.cancel_at_period_end">Off</dd>
                <dd class="col-sm-7" v-if="!subscription.cancel_at_period_end">On</dd>
                <dt v-if="subscription.canceled_at" class="col-sm-5">Cancelled On</dt>
                <dd v-if="subscription.canceled_at" class="col-sm-7">{{ this.formatDate(subscription.canceled_at) }}</dd>
                <dt v-if="subscription.ended_at" class="col-sm-5">Ended At</dt>
                <dd v-if="subscription.ended_at" class="col-sm-7">{{ this.formatDate(subscription.ended_at) }}</dd>
            </dl>
            <b-button-group>
                <b-button v-if="!subscription.canceled_at" variant="danger" @click="cancelSub"><i class="fa fa-times"></i> Turn Off Auto-Renewal</b-button>
                <b-button v-if="subscription.canceled_at && subscription.status != 'canceled'" variant="warning" @click="resumeSub"><i class="fa fa-check"></i> Turn On Auto-Renewal</b-button>
                <b-button v-if="subscription.canceled_at && subscription.status == 'canceled'" variant="warning" @click="showStripeForm = true">Renew</b-button>
                <!--<b-button variant="warning"   @click="stripeForm">Renew</b-button>-->
            </b-button-group>
        </b-card>


        <b-card v-if="trial && !subscription" header="Trial period" :class="subCardColor" >
            <dl class="row text-left">
    <!--                <dt class="col-sm-5">Start</dt>-->
    <!--                <dd class="col-sm-7">{{ this.formatDate(trial.valid_from) }}</dd>-->
                <dt class="col-sm-5">Trial Ends On:</dt>
                <dd class="col-sm-7">{{ this.formatDate(trial) }}
                </dd>


                <!--<dt v-if="subscription.ended_at" class="col-sm-5">Ended At</dt>-->
                <!--<dd v-if="subscription.ended_at" class="col-sm-7">{{ this.formatDate(subscription.ended_at) }}</dd>-->
            </dl>
            <b-button-group>
                <!--<b-button v-if="subscription.canceled_at && subscription.status == 'canceled'" variant="warning" @click="showStripeForm = true">Renew</b-button>-->
                <b-button variant="warning"  @click="stripeForm">Add Subscription</b-button>
            </b-button-group>
        </b-card>


        <b-button-group v-if="!subscription && !trial">
            <!--<b-button v-if="subscription.canceled_at && subscription.status == 'canceled'" variant="warning" @click="showStripeForm = true">Renew</b-button>-->
            <b-button variant="warning"  @click="stripeForm">Add Subscription</b-button>
        </b-button-group>



        <stripe-form postUrl="api/billing/renew" ref="form"  :showForm="showStripeForm"/>
    </div>
</template>

<script>
    import StripeForm from "../stripeForm";
    export default {

        props: {
            subscription: {
                type: [Object, Boolean],
                required: true,
            },
            trial: {
                type: [Object, Boolean],
                required: true,
            },
        },

        name: "Subscriptions",
        components: {StripeForm},
        data() {
            return {
                // subscription: false,
                loadingContent: false,
                showStripeForm: false,
                subStatus: true,
                subCardColor: 'bg-primary'
            }
        },
        methods: {

            stripeForm: function() {
                this.$refs.form.openForm();
                this.showStripeForm = true;
            },

            setSubStatus: function () {
                switch (this.subscription.status) {
                    case 'incomplete':
                    case 'incomplete_expired':
                        this.subCardColor = 'bg-danger';
                        break;

                    case 'trialing':
                        this.subCardColor = 'bg-warning';
                        break;

                    case 'active':
                        this.subCardColor = 'bg-success';
                        break;
                    case 'past_due':
                        this.subCardColor = 'bg-warning';
                        break;

                    case 'canceled':
                        this.subCardColor = 'bg-secondary';
                        break;

                    case 'unpaid':
                        this.subCardColor = 'bg-danger';
                        break;
                }
            },

            upgradeSub: function () {

            },

            cancelSub: function () {

                let targetUrl = 'api/billing/cancel';
                window.axios.get(targetUrl)
                    .then(response => {
                        this.subscription = response.data;
                        this.setSubStatus();
                    })
                    .catch(e => {

                    })
            },

            resumeSub: function () {

                let targetUrl = 'api/billing/resume';
                window.axios.get(targetUrl)
                    .then(response => {
                        this.subscription = response.data;
                        this.setSubStatus();
                    })
                    .catch(e => {

                    })
            },


            // updateSubscription(subscription)
            // {
            //     this.subscription = subscription;
            //   //  this.cardBrand = this.cardBrandIcon(card.brand);
            // },

            renewSub: function () {
                alert('renewel');
                let targetUrl = 'api/billing/renew';

                window.axios.get(targetUrl)
                    .then(response => {
                        this.subscription = response.data;
                        this.setSubStatus();
                    })
                    .catch(e => {

                    })
            },


            formatDate (value, fmt = 'MMM DD, YYYY') {

                if(typeof value == 'object')
                {
                    return window.moment(value.date).format(fmt);
                }

                //value = typeof value === 'object' ? value.date: value;


                return (value == null)
                    ? ''
                    : window.moment.unix(value).format(fmt)
            },
            formatMoney(amount, decimalCount = 2, decimal = ".", thousands = ",") {
                try {
                    decimalCount = Math.abs(decimalCount);
                    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

                    const negativeSign = amount < 0 ? "-" : "";

                    let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
                    let j = (i.length > 3) ? i.length % 3 : 0;

                    return '$' + negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
                } catch (e) {
                    console.log(e)
                }
            },

            formatStripeMoney(amount) {
                return this.formatMoney(amount/100);
            },
        },

        mounted: function () {

            if(this.subscription)
            {
                this.setSubStatus();
            }
        },




    }



</script>