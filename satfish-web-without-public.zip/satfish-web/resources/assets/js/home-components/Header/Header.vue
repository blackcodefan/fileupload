<template>
  <header class="app-header navbar">
    <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button" @click="mobileSidebarToggle">
      <span class="navbar-toggler-icon"></span>
    </button>
    <b-link :class="logoClass" to="/regions"></b-link>
      <!--<a href="/logout"></a>-->
    <b-navbar-nav class="d-md-down-none">
      <b-nav-item :href="homeLink" class="px-3">
        Home
      </b-nav-item>

      <b-nav-item v-for="(item, index) in navItems" :to="item.url" v-bind:key="item.name" class="px-3">
        {{ item.name }}
      </b-nav-item>
      <b-nav-item @click="logout" class="float-right">Logout</b-nav-item>
    </b-navbar-nav>

    <b-navbar-nav class="ml-auto">

      <b-nav-item  v-show="user"  class="px-3">{{user.name}}</b-nav-item>

    </b-navbar-nav>


    <!--<button class="navbar-toggler aside-menu-toggler d-md-down-none" type="button" @click="asideToggle">-->
      <!--<span class="navbar-toggler-icon"></span>-->
    <!--</button>-->
  </header>
</template>
<script>
  import HeaderDropdown from './HeaderDropdown.vue'
  import HeaderDropdownAccnt from './HeaderDropdownAccnt.vue'
  import HeaderDropdownTasks from './HeaderDropdownTasks.vue'
  import HeaderDropdownNotif from './HeaderDropdownNotif.vue'
  import HeaderDropdownMssgs from './HeaderDropdownMssgs.vue'

  export default {
    name: 'c-header',
    components: {
      HeaderDropdown,
      HeaderDropdownAccnt,
      HeaderDropdownTasks,
      HeaderDropdownNotif,
      HeaderDropdownMssgs
    },
    data() {
      return {
        logoClass: 'navbar-brand ' + activeBrand.slug + '-logo',
        homeLink: activeBrand.home_url
      }
    },
    methods: {

      logout() {
        this.$bus.emit('showLoader')
        window.location.href = "/logoutsso";
      },
      sidebarToggle (e) {
        e.preventDefault()
        document.body.classList.toggle('sidebar-hidden')
      },
      sidebarMinimize (e) {
        e.preventDefault()
        document.body.classList.toggle('sidebar-minimized')
      },
      mobileSidebarToggle (e) {
        e.preventDefault()
        document.body.classList.toggle('sidebar-mobile-show')
      },
      asideToggle (e) {
        e.preventDefault()
        document.body.classList.toggle('aside-menu-hidden')
      },

    },
    props: { navItems: false, user: false },
  }
</script>
