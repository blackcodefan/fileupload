<template>
    <b-modal hide-footer v-model="showStripeForm" title="User Subscription" @hidden="showStripeForm = false">

        <b-alert :show="alert.show" :variant="alert.type"><span v-html="alert.msg"></span></b-alert>
        <b-container fluid>
            <b-form ref="form">
                <b-row v-if="!hidePlans">
                    <label>Select Plan:</label>
                    <b-form-select v-model="stripeData.plan">
                        <option @click="showCurrentPlan(plan)" v-for="plan in stripePlans" :value="plan.id">
                            {{plan.name}}
                        </option>
                    </b-form-select>
                </b-row>

                <b-row class="mt-2" v-if="!hidePlans && showPlan">
                    <div class="col-12 py-2">
                        <b-card
                                class="bg-success text-center"
                                :header="subscriptionPlan"
                                :footer="subscriptionValidity"
                                footer-tag="footer"
                                footer-bg-variant="success"
                        >

                            <div>
                                <h3 class="font-size-h3 text-white align-content-center">
                                    <strong>${{subscriptionAmount/100}}</strong>
                                </h3>
                            </div>
                        </b-card>
                    </div>
                </b-row>




                <b-row class="mt-2" v-if="!hideCoupons">
                    <input  type="text" placeholder="Enter Coupon if any.." v-model="stripeData.coupon"
                           class="form-control">
                </b-row>
                <b-row class="mt-2">
                    <input id="Name" class="form-control" v-model="stripeData.name" placeholder="Name on Card" >
                    <span name="CardName"></span>
                </b-row>
              <!-- @input="checkVal($event)"    -->
                <div id="card-element" class="mt-2">
                    <div ref="card"></div>
                    <input type="hidden" v-model="stripeData.token" />
                    <b-row class="pt-2">
                        <div v-if="type == 'plan'">
                            <label>
                                <input type="checkbox" @change="disabled = !disabled"> I have read and agree to the <a :href="termsUrl" target="_blank">terms and conditions</a> and
                                <a :href="privacyUrl" target="_blank">privacy policy</a>
                            </label>
                        </div>

                        <b-button v-if="type == 'plan'" type="submit" v-on:click="purchase" :disabled=" (disabled  || stripeFormProcessing)"
                                  variant="primary">Submit
                        </b-button>

                        <b-button id="type" v-if="type == 'card'" type="submit" v-on:click="purchase"
                                  variant="primary">Submit
                        </b-button>

                    </b-row>
                    <!-- A Stripe Element will be inserted here. -->
                </div>

            </b-form>

        </b-container>

    </b-modal>
</template>

<script>
    let stripe, elements, card;
    const formType = {
        default: 'card',
        type: String,
    };
    export default {
        name: "stripeForm",
        props : {

            showForm : { type: Boolean},
            postUrl: {type: String},
            hidePlans: {type: Boolean},
            hideCoupons: {type:Boolean},
            type: {type: String, default: 'plan'},
        },
        data() {
            return {
                DisplayError:'',
                privacyUrl: activeBrand.home_url + '/support/privacy-policy/',
                termsUrl: activeBrand.home_url + '/support/terms/',
                showStripeForm: false,
                 CheckingNameValidation:false,
                disabled: true,
                alert: {
                    type: 'success',
                    show: false,
                    msg: '',
                },
                stripeData: {
                    coupon: '',
                    cvc: '',
                    cardnumber: '',
                    exp_month: '',
                    exp_year: '',
                    stripeToken: '',
                    plan: '',
                    name: '',
                },
                stripePlans: [],
                stripeKey: '',
                showPlan: false,
                subscriptionPlan: '',
                subscriptionAmount: '',
                subscriptionValidity: '',
                stripeFormProcessing: false,
                isStripePlan: false,
            }
        },
        methods: {
            purchase: function () {
                let self = this;

                self.alert.show = false;
                self.stripeFormProcessing = true; // disable button while processing
                stripe.createToken(card).then(function (result) {
                    self.$bus.emit('showLoader');
                    if (result.error) {
                        self.$bus.emit('showLoader');
                        console.log(result.error.message);
                        // self.showErrors(result.error.message);
                        self.stripeFormProcessing = false;
                        return;
                    } else {
                        // assigning token
                        self.stripeData.token = result.token.id;
                        let targetUrl = self.postUrl ? self.postUrl : '/api/admin/subscriptions/' + self.$route.params.id;
                        axios.post(targetUrl, self.stripeData)
                            .then(function (response) {
                                //calling loader off
                                self.$bus.emit('showLoader');
                                // on purchase complete
                                self.showStripeForm = false; // hiding modal
                                self.stripeFormProcessing = false; // enable button again

                                if(response.data.hasOwnProperty('last4'))
                                {
                                    self.$parent.updateCard(response.data);
                                   // self.$bus.emit('updateCard',response.data);
                                }
                                    
                                if(response.data.hasOwnProperty('subscription'))
                                {
                                    self.$bus.emit('updateSideBar', response.data);
                                    //self.$parent.updateSideBar(response.data);
                                }

                            }).catch(function (error) {
                                self.$bus.emit('showLoader');
                                console.log(error.response)
                                for(var key in error.response.data.errors){
                                    self.DisplayError += '<li>' + error.response.data.errors[key] + '</li>';

                                }

                                 // if(error.response.data.hasOwnProperty('message'))
                                 // {
                                 //        self.DisplayError += "<br>";
                                 //        self.DisplayError += error.response.data.message;
                                 // }
                                 
                                
                                self.showErrors(self.DisplayError)
                                self.DisplayError=''
                                //self.showErrors(error.response.data.errors.plan[0]);
                                self.stripeFormProcessing = false;
                        });

                    }
                });
            },

            // checkVal(e)
            // {
            //     let check =/^[a-zA-Z ]*$/;
            //     let Val=check.test(e.target.value)
            //     if(Val===false){
            //       document.getElementsByName('CardName')[0].innerHTML='Please Enter A valid Name';
            //       document.getElementsByName('CardName')[0].style.color='red';
            //       CheckingNameValidation =true
            //     }else{
            //              document.getElementsByName('CardName')[0].innerHTML='';          
            //       CheckingNameValidation=false
            //     }
            // },
            showErrors(error)
            {
                this.alert = {
                    type: 'danger',
                    show: true,
                    msg: error,
                };
            },

            getPlans: function () {
                if(this.hidePlans) {
                    return true;
                }

                let self = this,
                    $urlId = self.$route.params.id ? '/' + self.$route.params.id : "";
                window.axios.get('/api/admin/stripe-plans' + $urlId)
                    .then(function (response) {
                        self.stripePlans = response.data.plans;
                        self.stripeKey = response.data.key;
                    }).catch(function (error) {
                    console.log(error);
                });
            },
            showCurrentPlan: function (plan) {
                if (plan) {
                    this.subscriptionPlan = plan.name;
                    this.subscriptionAmount = plan.amount;
                    this.subscriptionValidity = plan.interval_count +" "+ plan.interval;
                    this.showPlan = true;
                    return;
                }
                this.showPlan = false;

            },
            openForm: function () {
                var self = this;
                self.showStripeForm = true;
            }
        },
        mounted: function () {
            // let stripeScript = document.createElement('script');
            // stripeScript.setAttribute('src', 'https://js.stripe.com/v3/');
            // document.head.appendChild(stripeScript);


            // stripe = Stripe(process.env.MIX_STRIPE_KEY);
            // elements = stripe.elements();
            // card = undefined;
            //
            // //card.mount(this.$refs.card);
            // card = elements.create('card');
            // alert(this.cardElId);
            // card.mount(this.$refs[this.cardElId]);
            // // card.mount('#' + cardElId);
        },
        beforeMount: function () {
            this.getPlans();
            return true;
        },
        watch: {
            showForm(value) {
                this.showStripeForm = value;
                // stripe = Stripe(this.stripeKey);
                let StripeKey = this.stripeKey ? this.stripeKey :  activeBrand.stripe_key;
                stripe = Stripe(StripeKey);
                elements = stripe.elements();
                card = undefined;

                card = elements.create('card');
                card.mount(this.$refs.card);
                // card.mount('#' + cardElId);
            },

        },
    }
</script>

<style scoped>
    .StripeElement {
        background-color: white;
        height: 40px;
        padding: 10px 12px;
        border-radius: 4px;
        border: 1px solid transparent;
        box-shadow: 0 1px 3px 0 #e6ebf1;
        -webkit-transition: box-shadow 150ms ease;
        transition: box-shadow 150ms ease;
    }

    #card-element .StripeElement {
        width: 437px;
        border: 1px solid #ccc;
        border-radius: 0px;
        transform: translateX(-16px);
        margin: 7px 0;
        height: auto;
    }


    .StripeElement {
        background-color: white;
        height: 40px;
        padding: 10px 12px;
        border-radius: 4px;
        border: 1px solid transparent;
        box-shadow: 0 1px 3px 0 #e6ebf1;
        -webkit-transition: box-shadow 150ms ease;
        transition: box-shadow 150ms ease;
    }

    .StripeElement--focus {
        box-shadow: 0 1px 3px 0 #cfd7df;
    }

    .StripeElement--invalid {
        border-color: #fa755a;
    }

    .StripeElement--webkit-autofill {
        background-color: #fefde5 !important;
    }

    #card-element .StripeElement {
        width: 437px;
        border: 1px solid #ccc;
        border-radius: 0px;
        transform: translateX(-16px);
        margin: 7px 0;
        height: auto;
    }

    .subscription-card {
        width: 30px;
        height: 30px;
        border-radius: 50px;
        font-size: 30px;
        position: relative;
        left: 12px;
        top: -12px;
        color: #fff;
        background: red;
        opacity: 0.8;
        background-color: red !important;
        z-index: 1000;
    }

    [type="checkbox"]
    {
        vertical-align:middle;
        margin: 5px;
    }

</style>