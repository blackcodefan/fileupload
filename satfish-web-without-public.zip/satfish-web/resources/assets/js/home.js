/* jshint esversion: 6 */

require('./bootstrap');


import Vue from 'vue';
import BootstrapVue from 'bootstrap-vue';
import Home from './Home.vue';
import router from './router/home';

Vue.component('Home', Home);
Vue.use(BootstrapVue);


/* eslint-disable no-new */
const app = new Vue({
    el: '#home',
    router,
    template: '<Home/>',
});
