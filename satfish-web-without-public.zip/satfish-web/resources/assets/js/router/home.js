import Vue from 'vue';
import Router from 'vue-router';

// Containers
import Home from '../containers/Home';

// Views
import Regions from '../views/home/regions';
import Billing from '../views/home/billing';
import Settings from '../views/home/settings';

Vue.use(Router);

export default new Router({
    mode: 'hash', // hash or hash = Demo is living in GitHub.io, so required!
    linkActiveClass: 'open active',
    scrollBehavior: () => ({ y: 0 }),
    routes: [
    {
        path: '/',
        redirect: '/regions',
        name: 'Home',
        component: Home,
        props: true,
        children: [
            {
                path: 'regions',
                name: 'Regions',
                component: Regions
            },
            {
                path: 'billing',
                name: 'Billing',
                component: Billing
            },
            {
                path: 'settings',
                name: 'Settings',
                component: Settings
            }
        ]
    }
]
});
