import Vue from 'vue';
import Router from 'vue-router';

// Containers
import Admin from '../containers/Admin';

// Views
import Dashboard from '../views/admin/Dashboard';

import Types from '../views/admin/Types/All';
import TypeForm from '../views/admin/Types/Form';
import Users from '../views/admin/Users/All';
import UsersActivity from '../views/admin/Users/UsersActivity';
import BannedUsers from '../views/admin/Users/Banned';
import UsersForm from '../views/admin/Users/Form';
import UserView from '../views/admin/Users/View';
import Regions from '../views/admin/Regions/All';
import RegionForm from '../views/admin/Regions/Form';
import Layers from '../views/admin/Layers/All';
import LayersForm from '../views/admin/Layers/Form';
import HoteBites from '../views/admin/HotBites/All';
import HotBiteForm from '../views/admin/HotBites/Form';
import Markers from '../views/admin/Markers/All';
import MarkersForm from '../views/admin/Markers/Form';
import CsvImport from '../views/admin/CSV/Import';
import ImportedFiles from '../views/admin/CSV/Imported';
import Coupons from '../views/admin/Coupons/All';
import CouponForm from '../views/admin/Coupons/Form';
import Buoys from '../views/admin/Buoys/All';
import Buoy from '../views/admin/Buoys/Single';
import MemCerts from '../views/admin/MemCert/All';
import MemCert from '../views/admin/MemCert/Form';

Vue.use(Router);

export default new Router({
    mode: 'hash', // hash or hash = Demo is living in GitHub.io, so required!
    linkActiveClass: 'open active',
    scrollBehavior: () => ({ y: 0 }),
    routes: [
    {
        path: '/',
        redirect: '/dashboard',
        name: 'Admin',
        component: Admin,
        children: [
            {
                path: 'dashboard',
                name: 'Dashboard',
                component: Dashboard
            },
            {
                path: 'regions',
                name: 'Regions',
                component: Regions
            },
            {
                path: 'regions/create',
                name: 'create-region',
                component: RegionForm,
                meta: {
                    label: 'Create Region'
                },
            },
            {
                path: 'regions/:id',
                name: 'edit-region',
                meta: {
                    label: 'Edit Region'
                },
                component: RegionForm
            },
            {
                path: 'types',
                name: 'Types',
                component: Types
            },
            {
                path: 'types/create',
                name: 'create-type',
                component: TypeForm,
                meta: {
                    label: 'Create Type'
                }
            },
            {
                path: 'types/:id',
                name: 'edit-type',
                meta: {
                    label: 'Edit Type'
                },
                component: TypeForm
            },
            {
                path: 'users/certificates/create',
                name: 'create-memcert',
                meta: {
                    label: 'Create Certificate'
                },
                component: MemCert
            },
            {
                path: 'users/certificates',
                name: 'memcert',
                meta: {
                    label: 'User Certificates'
                },
                component: MemCerts
            },
            {
                path: 'users/certificates/:id',
                name: 'edit-memcert',
                meta: {
                    label: 'Edit Membership Certificate'
                },
                component: MemCert
            },
            {
                path: 'users/coupons',
                name: 'coupons',
                meta: {
                    label: 'Coupons'
                },
                component: Coupons
            },
            {
                path: '/users/coupons/create',
                name: 'create-coupon',
                meta: {
                    label: 'Create Coupon'
                },
                component: CouponForm
            },
            {
                path: '/users/coupons/:id',
                name: 'edit-coupon',
                meta: {
                    label: 'Edit Coupon'
                },
                component: CouponForm
            },
            {
                path: 'users/activity',
                name: 'activity',
                meta: {
                    label: "User's Activity",
                },
                component: UsersActivity,
            },
            {
                path: 'users/banned',
                name: 'banned',
                meta: {
                    label: 'Banned Users'
                },
                component: BannedUsers
            },
            {
                path: 'users/create',
                name: 'create-user',
                meta: {
                    label: 'Create User'
                },
                component: UsersForm
            },
            {
                path: 'users/:id',
                name: 'edit-user',
                meta: {
                    label: 'Edit User'
                },
                component: UsersForm
            },
            {
                path: 'users/:id/show',
                name: 'show-user',
                meta: {
                    label: 'User'
                },
                component: UserView
            },
            {
                path: 'users',
                name: 'Users',
                component: Users
            },

            {
                path: 'layers',
                name: 'Layers',
                component: Layers
            },
            {
                path: 'layers/create',
                name: 'create-layer',
                meta: {
                    label: 'Create Layer'
                },
                component: LayersForm
            },
            {
                path: 'layers/:id',
                name: 'edit-layer',
                meta: {
                    label: 'Edit Layer'
                },
                component: LayersForm
            },
            {
                path: 'hot-bites',
                name: 'all-hotbites',
                meta: {
                    label: 'Hot Bites'
                },
                component: HoteBites
            },
            {
                path: 'hot-bites/create',
                name: 'create-hotbite',
                meta: {
                    label: 'Create HotBite'
                },
                component: HotBiteForm
            },
            {
                path: 'hot-bites/:id',
                name: 'edit-hotbite',
                meta: {
                    label: 'Edit HotBite'
                },
                component: HotBiteForm
            },
            {
                path: 'labels',
                name: 'all-markers',
                meta: {
                    label: 'Labels'
                },
                component: Markers
            },
            {
                path: 'labels/create',
                name: 'create-marker',
                meta: {
                    label: 'Create Label'
                },
                component: MarkersForm
            },
            {
                path: 'labels/:id',
                name: 'edit-marker',
                meta: {
                    label: 'Edit Label'
                },
                component: MarkersForm
            },
            {
                path: 'buoys',
                name: 'Buoys',
                meta: {
                    label: 'Buoys'
                },
                component: Buoys
            },
            {
                path: 'buoys/:id',
                name: 'view-buoy',
                meta: {
                    label: 'View Buoy'
                },
                component: Buoy
            },
            {
                path: 'csv-import',
                name: 'csv-import',
                meta: {
                    label: 'Import CSV'
                },
                component: CsvImport
            },
            {
                path: 'imported-files',
                name: 'imported-files',
                meta: {
                    label: 'Imported Files'
                },
                component: ImportedFiles
            }
        ]
    }
]
});
