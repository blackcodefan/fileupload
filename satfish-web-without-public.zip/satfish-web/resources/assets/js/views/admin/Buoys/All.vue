<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/buoys"
                editRoute="view-buoy"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                    {
                        name: 'sid',
                        title: 'STN#',
                        // titleClass: 'text-right',
                        // dataClass: 'text-right',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'sid',
                    },
                    // {
                    //     name: '__checkbox',
                    //     titleClass: 'text-center',
                    //     dataClass: 'text-center',
                    // },
                    {
                        name: 'name',
                        title: 'Name',
                        sortField: 'name',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'lat',
                        title: 'Latitude',
                        sortField: 'lat',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'lng',
                        title: 'Longitude',
                        sortField: 'lng',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'data_time',
                        title: 'Last Update',
                        sortField: 'data_time',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: 'status',
                        title: 'Status',
                        sortField: 'status',
                        callback: 'switch',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                       titleClass:'text-center',
                        dataClass: 'text-center'
                    }
                ]
            }
        }
    }
</script>