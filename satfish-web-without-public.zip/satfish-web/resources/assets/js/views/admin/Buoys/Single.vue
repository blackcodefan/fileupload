<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" redirect="Buoys"></create-edit-form>
</template>

<script>

    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import Pikaday from 'pikaday';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);


    export default {
        name: "layer-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {
            return {
                formAction: "/api/admin/buoys",
                types: [],
                regions: [],
                model: {
                    id: "",
                    sid: "",
                    name: "",
                    // source: "",
                    lat: '',
                    lng: 1,
                    owner: 1,
                    program: 1,
                    type: 1,
                    status: 1,
                    data_time: '',
                    data: {},
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Name",
                                    model: "name",
                                    disabled: true,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "STN#",
                                    model: "sid",
                                    disabled: true,
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Latitude",
                                    model: "lat",
                                    disabled: true,
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Longitude",
                                    model: "lng",
                                    disabled: true,
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Owner",
                                    model: "owner",
                                    disabled: true,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Program",
                                    model: "program",
                                    disabled: true,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Type",
                                    model: "type",
                                    disabled: true,
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "switch",
                                    label: "Status",
                                    model: "status",
                                    textOn: "Active",
                                    textOff: "Inactive",
                                    disabled:true,
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    label: "Data Time (PST)",
                                    model: "data_time",
                                    disabled: true,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "textArea",
                                    label: "Data",
                                    model: "data",
                                    disabled: true,
                                    rows: 8,
                                    styleClasses: ['col-md-12']
                                },
                            ]
                        }
                    ],
                }
            }
        }
    }
</script>