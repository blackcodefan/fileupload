<template>

    <div>

        <div class="card">
            <div class="card-header">
                <div>Import CSV</div>
            </div>


            <div class="card-body">
                <b-alert v-if="showAlert" :show="showAlert" :variant="alertType"><span v-html="successMsg"></span></b-alert>

                <form name="csvForm">
                    <div class="form-row">
                        <div class="col-6">
                            <label for="csvFile">System Entity</label>
                            <div class="btn-group entities">
                                <label class="btn btn-primary" :class="{active: currentEntity === 'markers'}">
                                    <input type="radio" @change="onChange('markers')" name="entity" autocomplete="off" value="markers" checked> Labels
                                </label>
                                <label class="btn btn-primary" :class="{active: currentEntity === 'hotbites'}">
                                    <input type="radio" @change="onChange('hotbites')" name="entity" autocomplete="off" value="hotbites"> HotBites
                                </label>
                                <!--<label class="btn btn-primary" :class="{active: currentEntity === 'layers'}">-->
                                    <!--<input type="radio" @change="onChange('layers')" name="entity" autocomplete="off" value="layers"> Layers-->
                                <!--</label>-->
                                <label class="btn btn-primary" :class="{active: currentEntity === 'regions'}">
                                    <input type="radio"  @change="onChange('regions')" name="entity" autocomplete="off" value="regions"> Regions
                                </label>
                            </div>
                        </div>



                        <div class="col-6">
                            <label for="csvFile">CSV File</label>
                            <input type="file" class="form-control-file" id="csvFile" name="csvFile" aria-describedby="csvFile" accept=".csv" @change="handleFileChange">
                            <small id="csvFileHelp" class="form-text text-muted">Please upload a valid csv file</small>
                        </div>

                    </div>


                </form>

                <div class="table-responsive" v-if="fileLoaded">
                    <div class="alert alert-warning" role="alert">
                        <h5>CSV Preview</h5>

                        <p>You will able to view up to 20 rows from provided CSV file. Please carefully verify the sample data before proceeding to next step.</p>

                        <button type="button" class="btn btn-success btn-lg" @click="storeCSV">Proceed <i class="fa fa-arrow-right"></i></button>
                    </div>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col" v-for="hField in table.headFields">
                                {{ hField }}
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="row in table.data">
                            <td v-for="bField in row">
                                {{ bField }}
                            </td>
                        </tr>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

</template>

<script>

    import Vue from 'vue';

    window.Papa = require('papaparse');

    export default {
        name: "csv-import",
        components: {
        },
        data() {
            return {
                fileLoaded: false,
                successMsg: '',
                showAlert: false,
                currentEntity: 'markers',
                table: {
                    'headFields': {},
                    'data': {},
                    'page': 1
                },
                alertType: 'success',
                entitiesHeader: {
                    'hotbites' : ['category_id','title','date_time','lat','lng','note','type'],
                    'layers'   : ['region_id','type_id','status','created_at'],
                    // 'regions'  : ['name','slug', 'upper_lat','left_lng','bottom_lat','right_lng','status','extra.min_zoom','extra.max_zoom','extra.default_zoom'],
                    'regions'  : ['name','slug', 'upper_lat','left_lng','bottom_lat','right_lng','brand','status','extra.min_zoom','extra.max_zoom','extra.default_zoom'],
                    'markers' :  ['name','lat','lng','extra.content', 'extra.font_size', 'extra.zoom_ctrl'],
                },
                options : [
                    {text: 'Markers',value: 'markers'},
                    {text: 'Hot Bits',value: 'hotbites'},
                    {text: 'Regions', value: 'regions'},
                    {text: 'Layers', value: 'layers' },
                ],
            }
        },
        methods: {
            handleFileChange(e) {
                var files = e.target.files;     
                if (files.length > 0)
                {
                    var self = this;
                    Papa.parse(files[0], {
                        header: true,
                        dynamicTyping: true,
                        preview: 20,
                        skipEmptyLines: true,
                        complete: function (results) {
                            //Table Header
                            self.table.headFields = self.renderHeadData(results);
                            if(!self.checkHeader()){

                                self.showAlert = true;
                                self.alertType  = 'danger';
                                self.successMsg = "Columns should be following for   " + self.currentEntity +"  ( " +self.entitiesHeader[self.currentEntity] + ")";
                            }else{
                                self.showAlert = false;
                                self.alertType  = '';
                                self.table.data = self.renderTableData(results, self.page);
                                self.fileLoaded = true;
                            }
                        },
                        error: function(error) {

                        }
                    });
                }
            },
            checkHeader(){

                // checking header mismatch error
                var self = this;
                var header = self.entitiesHeader[self.currentEntity];
                var currentHeader = self.table.headFields;


                if(header.length !== currentHeader.length)
                    return false;


                for(var i = header.length; i--;) {
                    if(!currentHeader.includes(header[i])){
                        return false;
                    }
                }
                return true;
            },
            renderHeadData(results) {

                if(typeof results.meta != 'undefined' && results.meta.fields != 'undefined') {
                    return results.meta.fields;
                }

                return [];
            },
            renderTableData(results, page) {
                console.log(results.data);

                if(typeof results.data != 'undefined') {
                    return results.data;
                }
            },
            storeCSV() {
                if(confirm('THERE IS NO RETURN AFTER THIS POINT. UNDERSTOOD?')) {
                    let form = document.forms.namedItem('csvForm');
                    let formData = new FormData(form);

                    var self = this;

                    axios.post('api/admin/csv/process', formData)
                        .then(response => {
                            if(response.data.message) {
                                self.fileLoaded = false;
                                self.alertType='success'
                                self.successMsg = response.data.message;
                                self.showAlert = true;
                            }
                        })
                        .catch(error => {
                            if(typeof error.message == 'string') {
                                alert(error.message + '. Please try again');
                            }
                        })
                }

            },
            onChange(entity) {
                this.showAlert=false
                this.currentEntity = entity;
                return;
            },
        }
    }
</script>

<style>
    .entities label input {
        display: none ;
    }
</style>