<template>

    <div>


        <div class="card">

            <div class="card-header">
                <div class="row">
                    <div class="col-md-9">Imported Files </div>
                    <div class="col-md-3">
                        <b-button v-if="showFile" size="lg" class="float-right pt-1" variant="seconday" @click="showFile = false"> <span class="fa fa-arrow-circle-left"></span></b-button>
                    </div>
                </div>

            </div>

            <div class="card-body">

                <div v-if="!showFile" class="table-responsive">
                    <h2>Files</h2>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>File</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="(file,index) in fileNames" :key="index">
                            <td>
                                {{ index }}
                            </td>
                            <td>
                                {{ file.name }}
                            </td>
                            <td>
                                <b-badge :variant="fileStaus(file.status)">{{file.status.charAt(0).toUpperCase() + file.status.slice(1)}}</b-badge>
                            </td>
                            <td>
                                <a @click="viewFile(file.name)" class="btn btn-sm"><i class="icon-eye"></i></a>
                                <a v-if="file.status == 'error'" @click="process(file)" class="btn btn-sm"><i class="icon-refresh"></i></a>
                            </td>
                        </tr>

                        </tbody>
                    </table>
                </div>

                <div v-if="table.data.length > 0 && showFile" class="table-responsive">
                    <h2>{{currentFileName}}</h2>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th v-for="header in table.headFields">{{header}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="row in table.data">
                            <td v-for="bField in row">
                                {{ bField }}
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

</template>



<script>

    import Vue from 'vue';

    window.Papa = require('papaparse');

    export default {
        name: "csv-import",
        components: {
        },
        data() {
            return {
                fileLoaded: false,
                successMsg: '',
                showSuccessAlert: false,

                table: {
                    'headFields': {},
                    'data': {},
                    'page': 1
                },

                entity: '',
                entities: {

                    'markers': ['name','lat','lng','extra.content','extra.font_size','extra.zoom_ctrl'],
                    'regions': ['name','slug', 'upper_lat','left_lng','bottom_lat','right_lng','status','extra.min_zoom','extra.max_zoom','extra.default_zoom'],
                    'layers' : ['region_id','type_id','status','created_at'],
                    'hotbites' : ['category_id','title','date_time','lat','lng','note'],
                },
                showFile:false,
                currentFileName: '',
                // successFiles: [],
                // failedFiles : [],
                // pendingFiles: [],
                fileNames: [],
                files: [],
                table: {
                    'headFields': {},
                    'data': {},
                    'page': 1
                },

            }
        },
        methods: {

            renderHeadData(results) {
                console.log(results.meta.fields);
                if(typeof results.meta != 'undefined' && results.meta.fields != 'undefined') {
                    return results.meta.fields;
                }
                return [];
            },

            getFiles() {
                var self = this;
                axios.get('/api/admin/csv-files')
                    .then(response => {
                     //   if(response.data.length!==0){
                      if(response.status===200){
                       self.$bus.emit('OffLoader')
                        var files = response.data;
                        files.forEach( function (file,key)
                        {
                            self.fileNames.push({name:file.name,status:file.status});
                            var newFile = {};
                            newFile[file.name] = file.data;
                            self.files.push(newFile);
                            return;
                        });}
                        // console.log(results.meta.fields);
                        // self.table.data = self.renderTableData(results, self.page);
                        // self.fileLoaded = true;
                    }).catch( 
                        //self.$bus.emit('showLoader')
                        self.$bus.emit('OnLoader')                    
                    )
            },
            viewFile(name){

                var self = this;
                var currentFile = '';


                self.files.forEach(function(file){
                    if(name in file){
                        currentFile = file[name];
                        self.currentFileName = name;
                    }
                });

                if(currentFile !== ''){
                    var results = Papa.parse(currentFile,{
                        header: true
                    });
                    self.table.headFields = results.meta.fields;
                    self.table.data = results.data;
                    self.showFile = true;
                }
            },

            fileStaus(status){
                switch(status){
                    case 'success':
                        return 'success';
                        break;
                    case 'error':
                        return 'danger';
                        break;
                    default:
                        return 'info';
                        break;
                }
            },
            process(file){
                var self = this;
                if(confirm('Are you sure')) {
                    axios.post('/api/admin/re-process',{file:file.name}).then(function(){
                        file.status = 'pending';
                    });
                }

            },
        },

        beforeMount(){
            this.getFiles();
        }
    }
</script>