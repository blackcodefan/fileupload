<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/coupons"
                :buttons="buttons"
                @disableCoupon="disableCoupon"
                createRoute="create-coupon"
        >
        </vue-table>

    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                params:'',
                buttons: [{
                    icon:'fa fa-check',
                    callback: 'disableCoupon'
                }],
                fields: [
                    {
                        name: 'id',
                        title: 'Sr#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'id',
                    },
                    {
                        name: 'duration',
                        title: 'Duration',
                        sortField: 'duration',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                       name: 'code',
                        title: 'Coupon',
                        sortField: 'code',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'discount',
                        title: 'Discount',
                        sortField: 'discount',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'use_count',
                        title: 'Use Count',
                        sortField: 'use_count',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'user_use_count',
                        title: 'User Count',
                        sortField: 'user_use_count',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'brand',
                        title: 'Brand',
                        sortField: 'brand',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'is_disabled',
                        title: 'Status',
                        sortField: 'status',
                        callback: 'switch',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name:'__slot:customActions',
                        title:'Actions',
                           titleClass:'text-center',
                        dataClass: 'text-center'
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                    }
                ]
            }
        },
        methods: {
            disableCoupon(couponId){

                axios.patch('/api/admin/coupons/' + couponId).then(response => function(){                  
                    // this.$refs.vuetable.refresh()
                }).catch(function(){

                });
            },
        },
    }
</script>