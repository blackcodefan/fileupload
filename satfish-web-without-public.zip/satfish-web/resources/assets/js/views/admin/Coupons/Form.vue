<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" redirect="coupons"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);

    export default {
        name: "coupon-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {

            return {
                formAction: "/api/admin/coupons",
                categories: [],

                model: {
                    code: "",
                    duration: "",
                    discount: '',
                    usage: '',
                    type: 'amount',
                    is_disabled:false,
                    plans:'',
                    duration_in_months: '',
                    brand: activeBrand,
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [

                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Code",
                                    model: "code",
                                    placeholder: "Unique Code",
                                    required: true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "select",
                                    label: "Duration",
                                    required:true,
                                    model: "duration",
                                    values: [
                                        "once",
                                        "forever",
                                        "repeating",
                                    ],
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: 'number',
                                    label: "Enter Duration (in months)",
                                    model: "duration_in_months",
                                    required: true,
                                    hideInput: true,
                                    styleClasses: ['col-md-6'],
                                    visible(model) {
                                        return model && model.duration == "repeating";
                                    }
                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Discount",
                                    model: "discount",
                                    required:true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Coupon Usage",
                                    model: "usage",
                                    required:true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "switch",
                                    label: "Type ",
                                    model: "type",
                                    textOn: "Percentage",
                                    textOff: "Amount",
                                    valueOn: 'percent',
                                    valueOf: 'amount',
                                    styleClasses: ['col-md-2']
                                },

                                {
                                    type:    "switch",
                                    label:   "Disable",
                                    model:   "is_disabled",
                                    textOn:  "Disabled",
                                    textOff: "Enabled",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "brand",
                                    label: "Select Brand",
                                    placeholder: "Type to search",
                                    required: true,
                                    styleClasses: ['col-md-3'],
                                    selectOptions: {
                                        key: "slug",
                                        label: "name",
                                    },
                                    values: brands,
                                    onChanged: function(model, newVal, oldVal, field) {
                                        console.log(`Model's name changed from ${oldVal} to ${newVal}. Model:`, model);
                                    },
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "plans",
                                    label: "Plans",
                                    placeholder: "Type to search",
                                    required: true,
                                    styleClasses: ['col-md-4'],
                                    remoteUrl: '/api/admin/plans-brand',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: [],
                                    // visible(model) {
                                    //     return model && model.brand.slug == 'fishdope';
                                    // }
                                }
                            ]
                        }
                    ],
                }
            }
        },

    }
</script>