<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/hot-bites"
                editRoute="edit-hotbite"
                createRoute="create-hotbite"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                      {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: '#',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'id',
                    },
                    {
                        name: 'title',
                        title: 'Title',
                        sortField: 'title',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'category.name',
                        title: 'Category',
                        sortField: 'category.name',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'lat',
                        title: 'Latitude',
                        sortField: 'lat',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'lng',
                        title: 'Longitude',
                        sortField: 'lng',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'date_time',
                        title: 'Time',
                        sortField: 'date_time',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                        titleClass:'text-center',
                        dataClass: 'text-center'
                        //titleClass: 'center aligned',
                        //dataClass: 'center aligned'
                    }
                ]
            }
        }
    }
</script>