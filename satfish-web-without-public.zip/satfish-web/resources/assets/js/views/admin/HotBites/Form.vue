<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" redirect="all-hotbites"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);

    export default {
        name: "hot-bite-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {

            return {
                formAction: "/api/admin/hot-bites",
                redirect: "hot-bites",
                categories: [],
                model: {
                    date_time: '',
                    category: "",
                    title: "",
                    type: "",
                    lat: '',
                    lng: '',
                    note: ''
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    model: "title",
                                    label: "Title",
                                    required:true,
                                    placeholder: "Enter title",
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "category",
                                    label: "Category ",
                                    placeholder: "Select Category",
                                    required: true,
                                    styleClasses: ['col-md-4'],
                                    remoteUrl: '/api/admin/types/children/hot_bites_categories',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },
                                {
                                    type: "switch",
                                    label: "Type",
                                    model: "type",
                                    textOn: "Fish Report",
                                    textOff: "Spotter Plane",
                                    styleClasses: ['col-md-3'],
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Latitude",
                                    model: "lat",
                                    placeholder: "Latitude",
                                    required: true,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Longitude",
                                    model: "lng",
                                    placeholder: "Longitude",
                                    required: true,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "fcdatetime",
                                    label: "Date & Time",
                                    placeholder: "YYYY-MM-DD",
                                    model: "date_time",
                                    // validator: validators.date,
                                    styleClasses: ['col-md-4'],
                                    required: true
                                },
                                {
                                    type: "textArea",
                                    label: "Note",
                                    model: "note",
                                    placeholder: "Note",
                                    styleClasses: ['col-md-12']
                                },
                            ]
                        }
                    ],
                }
            }
        }
    }
</script>