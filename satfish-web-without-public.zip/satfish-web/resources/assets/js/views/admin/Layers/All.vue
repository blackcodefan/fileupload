<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/layers"
                editRoute="edit-layer"
                :showLayerFilters=true
                createRoute="create-layer"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                      {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: '#',
                        // titleClass: 'text-right',
                        // dataClass: 'text-right',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'id',
                    },
                    {
                        name: 'region.name',
                        title: 'Region',
                        sortField: 'regions.name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'type.name',
                        title: 'Layer',
                        sortField: 'types.name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'tiled',
                        title: 'Tiled',
                        sortField: 'tiled',
                        callback: 'switch',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'preview',
                        title: 'Image',
                        callback: function(value) {
                            return '<span class="layer-thumb"><img src="' + value + '" /></span>'
                        },
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        title: 'Created At',
                        sortField: 'created_at',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                           titleClass:'text-center',
                        dataClass: 'text-center'
                    }
                ]
            }
        }
    }
</script>