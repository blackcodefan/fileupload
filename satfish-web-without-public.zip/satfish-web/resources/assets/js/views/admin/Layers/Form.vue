<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" redirect="Layers"></create-edit-form>
</template>

<script>

    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import Pikaday from 'pikaday';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);


    export default {
        name: "layer-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {
            return {
                formAction: "/api/admin/layers",
                types: [],
                regions: [],
                model: {
                    region: "",
                    type: "",
                    media: "",
                    // source: "",
                    created_at: '',
                    status: 1,
                    temp_switch: 1,
                    temp: {
                        start: 0,
                        end: 100
                    },
                    tiled: 0
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "AdvanceSelect",
                                    model: "region",
                                    label: "Region ",
                                    placeholder: "Select Region",
                                    required: true,
                                    styleClasses: ['col-md-5'],
                                    remoteUrl: '/api/admin/regions/list',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "type",
                                    label: "Layer Type",
                                    placeholder: "Type to search",
                                    required: true,
                                    styleClasses: ['col-md-5'],
                                    remoteUrl: '/api/admin/types/children/layers',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },
                                {
                                    type: "switch",
                                    label: "Status",
                                    model: "status",
                                    textOn: "Active",
                                    textOff: "Inactive",
                                    styleClasses: ['col-md-2'],
                                },
                                // {
                                //     type: "switch",
                                //     label: "Source",
                                //     model: "source",
                                //     textOn: "Image",
                                //     textOff: "Directory",
                                //     valueOn: "image",
                                //     valueOff: "directory",
                                //     styleClasses: ['col-md-3'],
                                // },
                                {
                                    type: "fcdatetime",
                                    label: "Date & Time",
                                    placeholder: "YYYY-MM-DD",
                                    model: "created_at",
                                    styleClasses: ['col-md-4'],
                                    required: true
                                },
                                {
                                    type: "switch",
                                    label: "Tiles",
                                    model: "tiled",
                                    textOn: "Generated",
                                    textOff: "Waiting",
                                    styleClasses: ['col-md-2'],
                                },
                                {
                                    type: "switch",
                                    label: "Temperature.",
                                    model: "temp_switch",
                                    styleClasses: ['col-md-2'],
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    placeholder: "51.3",
                                    label: "Temp. Start",
                                    model: "temp.start",
                                    required: false,
                                    styleClasses: ['col-md-2'],
                                    visible(model) {
                                        return model && model.temp_switch;
                                    }
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    placeholder: "61.5",
                                    label: "Temp. End",
                                    model: "temp.end",
                                    required: false,
                                    styleClasses: ['col-md-2'],
                                    visible(model) {
                                        return model && model.temp_switch;
                                    }
                                },
                                {
                                    type: "image",
                                    label: "Select Image",
                                    model: "media",
                                    //required: true,
                                    hideInput: true,
                                    styleClasses: ['col-md-12']
                                },
                            ]
                        }
                    ],
                }
            }
        }
    }
</script>