<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/markers"
                editRoute="edit-marker"
                createRoute="create-marker"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [

                    {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: '#',
                        // titleClass: 'text-right',
                        // dataClass: 'text-right',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'id',
                    },
                    {
                        name: 'name',
                        title: 'Name',
                        sortField: 'name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'lat',
                        title: 'Latitude',
                        sortField: 'lat',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'lng',
                        title: 'Longitude',
                        sortField: 'lng',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        title: 'Created At',
                        sortField: 'created_at',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                        titleClass:'text-center',
                        dataClass: 'text-center'
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                    }
                ]
            }
        }
    }
</script>