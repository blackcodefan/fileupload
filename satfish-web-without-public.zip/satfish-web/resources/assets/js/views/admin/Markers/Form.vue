<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" redirect="all-markers"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);

    export default {
        name: "markers-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {
            
            return {
                formAction: "/api/admin/markers",
                categories: [],
                model: {
                    lat: '',
                    lng: '',
                    name: '',
                    icon: '',
                    style: '',
                    cssClass: '',
                    fontSize: '',
                    zoomCtrl: '',
                    content: '',
                },
                schema: {
                    groups: [
                        {
                                styleClasses: ['row'],
                                fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Name",
                                    model: "name",
                                    placeholder: "Name",
                                    required: true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "select",
                                    label: "Style",
                                    model: "style",
                                    values:  function() {
                                        return [
                                            { id: "plain", name: "Plain Text" },
                                            { id: "popup", name: "Popup" },
                                            { id: "tooltip", name: "Tooltip" }
                                        ]
                                    },
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "select",
                                    label: "Icon Color",
                                    model: "icon",
                                    visible(model) {
                                        return model && model.style != "plain";
                                    },
                                    values:  function() {
                                        return [
                                            { id: "red", name: "Red" },
                                            { id: "darkred", name: "Red - Dark" },
                                            { id: "lightred", name: "Red - Light" },
                                            { id: "orange", name: "Orange" },
                                            { id: "beige", name: "Beige" },
                                            { id: "green", name: "Green" },
                                            { id: "darkgreen", name: "Green - Dark" },
                                            { id: "lightgreen", name: "Green - Light" },
                                            { id: "blue", name: "Blue" },
                                            { id: "darkblue", name: "Blue - Dark" },
                                            { id: "lightblue", name: "Blue - Light" },
                                            { id: "cadetblue", name: "Blue - Caded" },
                                            { id: "purple", name: "Purple" },
                                            { id: "darkpurple", name: "Purple - Dark" },
                                            { id: "pink", name: "Pink" },
                                            { id: "white", name: "White" },
                                            { id: "gray", name: "Gray" },
                                            { id: "lightgray", name: "Gray - Light" },
                                            { id: "black", name: "Black" },
                                        ]
                                    },
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "select",
                                    label: "Font Size",
                                    model: "fontSize",
                                    visible(model) {
                                        return model && model.style == "plain";
                                    },
                                    values:  function() {
                                        return [
                                            { id: 6, name: "6 px" },
                                            { id: 7, name: "7 px" },
                                            { id: 8, name: "8 px" },
                                            { id: 9, name: "9 px" },
                                            { id: 10, name: "10 px" },
                                            { id: 11, name: "11 px" },
                                            { id: 12, name: "12 px" },
                                            { id: 13, name: "13 px" },
                                            { id: 14, name: "14 px" },
                                            { id: 15, name: "15 px" },
                                            { id: 16, name: "16 px" },
                                            { id: 17, name: "17 px" },
                                            { id: 18, name: "18 px" },
                                        ]
                                    },
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Latitude",
                                    model: "lat",
                                    placeholder: "Latitude",
                                    required: true,
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Longitude",
                                    model: "lng",
                                    required: true,
                                    placeholder: "Longitude",
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "CSS Class",
                                    model: "cssClass",
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Target Zoom Range",
                                    model: "zoomCtrl",
                                    placeholder: "e.g: 3-6",
                                    required: true,
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Content",
                                    model: "content",
                                    placeholder: "Write content for popup or tooltip (HTML Supported)",
                                    styleClasses: ['col-md-12']
                                },
                            ]
                        }
                    ],
                }
            }
        }
    }
</script>