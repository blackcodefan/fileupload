<template>
    <div>
        <vue-table
            :fields="fields"
            apiUrl="api/admin/memcert"
            editRoute="edit-memcert"
            createRoute="create-memcert"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                    {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: 'Sr#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'id',
                    },
                    {
                        name: 'code',
                        title: 'Certificate Code',
                        sortField: 'code',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'use_count',
                        title: 'Use Count',
                        sortField: 'use_count',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'grace_period_no',
                        title: 'Grace Period #',
                        sortField: 'grace_period_no',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'grace_period_unit.name',
                        title: 'Grace Period Unit',
                        sortField: 'grace_period_unit',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'status',
                        title: 'Status',
                        sortField: 'status',
                        callback: 'switch',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        sortField: 'created_at',
                        title: 'Created At',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                           titleClass:'text-center',
                        dataClass: 'text-center'
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                    }
                ]
            }
        }
    }
</script>