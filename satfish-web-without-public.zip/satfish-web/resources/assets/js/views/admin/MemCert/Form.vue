<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" :redirect="redirect"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);

    export default {
        name: "memcert-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {
            return {
                formAction: "/api/admin/memcert",
                redirect: 'memcert',
                model: {
                    code: '',
                    use_count: '',
                    grace_period_no: '',
                    grace_period_unit: '',
                    status: 1,
                    // valid_from: '',
                    // valid_to: '',
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Code",
                                    model: "code",
                                    placeholder: "A5WA3",
                                    required: true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Use Count",
                                    model: "use_count",
                                    placeholder: "20",
                                    required: true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Grace Period #",
                                    model: "grace_period_no",
                                    required: true,
                                    // validator: VueFormGenerator.validators.number,
                                    // pattern: '^[1-9][0-9]*$',
                                    placeholder: "Grace period",
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "grace_period_unit",
                                    label: "Grace Period Unit",
                                    placeholder: "Type to search",
                                    required: true,
                                    styleClasses: ['col-md-6'],
                                    // remoteUrl: 'https://restcoun tries.eu/rest/v1/all',
                                    selectOptions: {
                                        key: "code",
                                        label: "name",
                                    },
                                    values: [{name: 'Day',code: 'day'},{name: 'Week',code: 'week'},{name: 'Month',code: 'month'},{name: 'Year',code: 'year'}],
                                },
                                // {
                                //     type: "fcdatetime",
                                //     label: "Valid From",
                                //     placeholder: "YYYY-MM-DD",
                                //     model: "valid_from",
                                //     styleClasses: ['col-md-4'],
                                //     required: true
                                // },
                                // {
                                //     type: "fcdatetime",
                                //     label: "Valid To",
                                //     placeholder: "YYYY-MM-DD",
                                //     model: "valid_to",
                                //     styleClasses: ['col-md-4'],
                                //     required: true
                                // },

                                {
                                    type: "switch",
                                    label: "Status",
                                    model: "status",
                                    default: true,
                                    textOn: "Active",
                                    textOff: "Inactive",
                                    styleClasses: ['col-md-2'],
                                },

                            ]
                        }
                    ],
                }
            }
        },
    }
</script>

