<template>
    <div>
        <vue-table
            :fields="fields"
            apiUrl="api/admin/regions"
            editRoute="edit-region"
            createRoute="create-region"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                     {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: '#',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        // titleClass: 'text-right',
                        // dataClass: 'text-right',
                        sortField: 'id',
                    },
                    {
                        name: 'name',
                        sortField: 'name',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'brand.name',
                        title: 'Brand',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'status',
                        sortField: 'status',
                        callback: 'switch',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        sortField: 'created_at',
                        title: 'Created At',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                        titleClass:'text-center',
                        dataClass: 'text-center'
               }
                ]
            }
        }
    }
</script>