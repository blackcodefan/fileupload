<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" :redirect="redirect" @model-updated="onModelUpdated"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);
    var locationList = [
        { id:"ACP" , name: "Acapulco, Gro." },
        { id:"BLA" , name: "Bahía de los Angeles, B.C." },
        { id:"CSL" , name: "Cabo San Lucas, B.C.S." },
        { id: "ENS" , name: "Ensenada, B.C." },
        { id:"GRN" , name: "Guerrero Negro, B.C.S." },
        { id:"GSC" , name: "Golfo de Santa Clara, Sonora" },
        { id:"GUY" , name: "Guaymas, Sonora" },
        { id:"ICD" , name: "Isla de Cedros, B.C." },
        { id:"IGP" , name: "Isla Guadalupe, B.C." },
        { id:"ISM" , name: "Isla San Marcos, B.C.S." },
        { id:"ISC" , name: "Isla Socorro, Colima" },
        { id:"LPZ" , name: "La Paz, B.C.S. " },
        { id:"LTO" , name: "Loreto, B.C.S. " },
        { id:"MNZ" , name: "Manzanillo, Colima" },
        { id:"MZT" , name: "Mazatlan, Sinaloa" },
        { id:"PTP" , name: "Puerto Peñasco, Sonora" },
        { id:"PTV" , name: "Puerto Vallarta, Jalisco" },
        { id:"SNC" , name: "San Carlos, B.C.S." },
        { id:"SCR" , name: "Salina Cruz, Oaxaca" },
        { id:"SNF" , name: "San Felipe, B.C." },
        { id:"SNQ" , name: "San Quintín, B.C." },
        { id:"STR" , name: "Santa Rosalía, B.C.S." },
        { id:"TPL" , name: "Topolobampo, Sinaloa " },
        { id:"YAV" , name: "Yavaros, Sonora " },
    ];
    var timezones = [
        { id:'(GMT-11:00) Midway Island' , name: 'Pacific/Midway' },
        { id:'(GMT-11:00) Samoa' , name: 'Pacific/Samoa' },
        { id:'(GMT-10:00) Hawaii' , name: 'Pacific/Honolulu' },
        { id:'(GMT-09:00) Alaska' , name: 'US/Alaska' },
        { id:'(GMT-08:00) Pacific Time (US &amp; Canada)' , name: 'America/Los_Angeles' },
        { id:'(GMT-08:00) Tijuana' , name: 'America/Tijuana' },
        { id:'(GMT-07:00) Arizona' , name: 'US/Arizona' },
        { id:'(GMT-07:00) Chihuahua' , name: 'America/Chihuahua' },
        { id:'(GMT-07:00) La Paz' , name: 'America/Chihuahua' },
        { id:'(GMT-07:00) Mazatlan' , name: 'America/Mazatlan' },
        { id:'(GMT-07:00) Mountain Time (US &amp; Canada)' , name: 'US/Mountain' },
        { id:'(GMT-06:00) Central America' , name: 'America/Managua' },
        { id:'(GMT-06:00) Central Time (US &amp; Canada)' , name: 'US/Central' },
        { id:'(GMT-06:00) Guadalajara' , name: 'America/Mexico_City' },
        { id:'(GMT-06:00) Mexico City' , name: 'America/Mexico_City' },
        { id:'(GMT-06:00) Monterrey' , name: 'America/Monterrey' },
        { id:'(GMT-06:00) Saskatchewan' , name: 'Canada/Saskatchewan' },
        { id:'(GMT-05:00) Bogota' , name: 'America/Bogota' },
        { id:'(GMT-05:00) Eastern Time (US &amp; Canada)' , name: 'US/Eastern' },
        { id:'(GMT-05:00) Indiana (East)' , name: 'US/East-Indiana' },
        { id:'(GMT-05:00) Lima' , name: 'America/Lima' },
        { id:'(GMT-05:00) Quito' , name: 'America/Bogota' },
        { id:'(GMT-04:00) Atlantic Time (Canada)' , name: 'Canada/Atlantic' },
        { id:'(GMT-04:30) Caracas' , name: 'America/Caracas' },
        { id:'(GMT-04:00) La Paz' , name: 'America/La_Paz' },
        { id:'(GMT-04:00) Santiago' , name: 'America/Santiago' },
        { id:'(GMT-03:30) Newfoundland' , name: 'Canada/Newfoundland' },
        { id:'(GMT-03:00) Brasilia' , name: 'America/Sao_Paulo' },
        { id:'(GMT-03:00) Buenos Aires' , name: 'America/Argentina/Buenos_Aires' },
        { id:'(GMT-03:00) Georgetown' , name: 'America/Argentina/Buenos_Aires' },
        { id:'(GMT-03:00) Greenland' , name: 'America/Godthab' },
        { id:'(GMT-02:00) Mid-Atlantic' , name: 'America/Noronha' },
        { id:'(GMT-01:00) Azores' , name: 'Atlantic/Azores' },
        { id:'(GMT-01:00) Cape Verde Is.' , name: 'Atlantic/Cape_Verde' },
        { id:'(GMT+00:00) Casablanca' , name: 'Africa/Casablanca' },
        { id:'(GMT+00:00) Edinburgh' , name: 'Europe/London' },
        { id:'(GMT+00:00) Greenwich Mean Time : Dublin' , name: 'Etc/Greenwich' },
        { id:'(GMT+00:00) Lisbon' , name: 'Europe/Lisbon' },
        { id:'(GMT+00:00) London' , name: 'Europe/London' },
        { id:'(GMT+00:00) Monrovia' , name: 'Africa/Monrovia' },
        { id:'(GMT+00:00) UTC' , name: 'UTC' },
        { id:'(GMT+01:00) Amsterdam' , name: 'Europe/Amsterdam' },
        { id:'(GMT+01:00) Belgrade' , name: 'Europe/Belgrade' },
        { id:'(GMT+01:00) Berlin' , name: 'Europe/Berlin' },
        { id:'(GMT+01:00) Bern' , name: 'Europe/Berlin' },
        { id:'(GMT+01:00) Bratislava' , name: 'Europe/Bratislava' },
        { id:'(GMT+01:00) Brussels' , name: 'Europe/Brussels' },
        { id:'(GMT+01:00) Budapest' , name: 'Europe/Budapest' },
        { id:'(GMT+01:00) Copenhagen' , name: 'Europe/Copenhagen' },
        { id:'(GMT+01:00) Ljubljana' , name: 'Europe/Ljubljana' },
        { id:'(GMT+01:00) Madrid' , name: 'Europe/Madrid' },
        { id:'(GMT+01:00) Paris' , name: 'Europe/Paris' },
        { id:'(GMT+01:00) Prague' , name: 'Europe/Prague' },
        { id:'(GMT+01:00) Rome' , name: 'Europe/Rome' },
        { id:'(GMT+01:00) Sarajevo' , name: 'Europe/Sarajevo' },
        { id:'(GMT+01:00) Skopje' , name: 'Europe/Skopje' },
        { id:'(GMT+01:00) Stockholm' , name: 'Europe/Stockholm' },
        { id:'(GMT+01:00) Vienna' , name: 'Europe/Vienna' },
        { id:'(GMT+01:00) Warsaw' , name: 'Europe/Warsaw' },
        { id:'(GMT+01:00) West Central Africa' , name: 'Africa/Lagos' },
        { id:'(GMT+01:00) Zagreb' , name: 'Europe/Zagreb' },
        { id:'(GMT+02:00) Athens' , name: 'Europe/Athens' },
        { id:'(GMT+02:00) Bucharest' , name: 'Europe/Bucharest' },
        { id:'(GMT+02:00) Cairo' , name: 'Africa/Cairo' },
        { id:'(GMT+02:00) Harare' , name: 'Africa/Harare' },
        { id:'(GMT+02:00) Helsinki' , name: 'Europe/Helsinki' },
        { id:'(GMT+02:00) Istanbul' , name: 'Europe/Istanbul' },
        { id:'(GMT+02:00) Jerusalem' , name: 'Asia/Jerusalem' },
        { id:'(GMT+02:00) Kyiv' , name: 'Europe/Helsinki' },
        { id:'(GMT+02:00) Pretoria' , name: 'Africa/Johannesburg' },
        { id:'(GMT+02:00) Riga' , name: 'Europe/Riga' },
        { id:'(GMT+02:00) Sofia' , name: 'Europe/Sofia' },
        { id:'(GMT+02:00) Tallinn' , name: 'Europe/Tallinn' },
        { id:'(GMT+02:00) Vilnius' , name: 'Europe/Vilnius' },
        { id:'(GMT+03:00) Baghdad' , name: 'Asia/Baghdad' },
        { id:'(GMT+03:00) Kuwait' , name: 'Asia/Kuwait' },
        { id:'(GMT+03:00) Minsk' , name: 'Europe/Minsk' },
        { id:'(GMT+03:00) Nairobi' , name: 'Africa/Nairobi' },
        { id:'(GMT+03:00) Riyadh' , name: 'Asia/Riyadh' },
        { id:'(GMT+03:00) Volgograd' , name: 'Europe/Volgograd' },
        { id:'(GMT+03:30) Tehran' , name: 'Asia/Tehran' },
        { id:'(GMT+04:00) Abu Dhabi' , name: 'Asia/Muscat' },
        { id:'(GMT+04:00) Baku' , name: 'Asia/Baku' },
        { id:'(GMT+04:00) Moscow' , name: 'Europe/Moscow' },
        { id:'(GMT+04:00) Muscat' , name: 'Asia/Muscat' },
        { id:'(GMT+04:00) St. Petersburg' , name: 'Europe/Moscow' },
        { id:'(GMT+04:00) Tbilisi' , name: 'Asia/Tbilisi' },
        { id:'(GMT+04:00) Yerevan' , name: 'Asia/Yerevan' },
        { id:'(GMT+04:30) Kabul' , name: 'Asia/Kabul' },
        { id:'(GMT+05:00) Islamabad' , name: 'Asia/Karachi' },
        { id:'(GMT+05:00) Karachi' , name: 'Asia/Karachi' },
        { id:'(GMT+05:00) Tashkent' , name: 'Asia/Tashkent' },
        { id:'(GMT+05:30) Chennai' , name: 'Asia/Calcutta' },
        { id:'(GMT+05:30) Kolkata' , name: 'Asia/Kolkata' },
        { id:'(GMT+05:30) Mumbai' , name: 'Asia/Calcutta' },
        { id:'(GMT+05:30) New Delhi' , name: 'Asia/Calcutta' },
        { id:'(GMT+05:30) Sri Jayawardenepura' , name: 'Asia/Calcutta' },
        { id:'(GMT+05:45) Kathmandu' , name: 'Asia/Katmandu' },
        { id:'(GMT+06:00) Almaty' , name: 'Asia/Almaty' },
        { id:'(GMT+06:00) Astana' , name: 'Asia/Dhaka' },
        { id:'(GMT+06:00) Dhaka' , name: 'Asia/Dhaka' },
        { id:'(GMT+06:00) Ekaterinburg' , name: 'Asia/Yekaterinburg' },
        { id:'(GMT+06:30) Rangoon' , name: 'Asia/Rangoon' },
        { id:'(GMT+07:00) Bangkok' , name: 'Asia/Bangkok' },
        { id:'(GMT+07:00) Hanoi' , name: 'Asia/Bangkok' },
        { id:'(GMT+07:00) Jakarta' , name: 'Asia/Jakarta' },
        { id:'(GMT+07:00) Novosibirsk' , name: 'Asia/Novosibirsk' },
        { id:'(GMT+08:00) Beijing' , name: 'Asia/Hong_Kong' },
        { id:'(GMT+08:00) Chongqing' , name: 'Asia/Chongqing' },
        { id:'(GMT+08:00) Hong Kong' , name: 'Asia/Hong_Kong' },
        { id:'(GMT+08:00) Krasnoyarsk' , name: 'Asia/Krasnoyarsk' },
        { id:'(GMT+08:00) Kuala Lumpur' , name: 'Asia/Kuala_Lumpur' },
        { id:'(GMT+08:00) Perth' , name: 'Australia/Perth' },
        { id:'(GMT+08:00) Singapore' , name: 'Asia/Singapore' },
        { id:'(GMT+08:00) Taipei' , name: 'Asia/Taipei' },
        { id:'(GMT+08:00) Ulaan Bataar' , name: 'Asia/Ulan_Bator' },
        { id:'(GMT+08:00) Urumqi' , name: 'Asia/Urumqi' },
        { id:'(GMT+09:00) Irkutsk' , name: 'Asia/Irkutsk' },
        { id:'(GMT+09:00) Osaka' , name: 'Asia/Tokyo' },
        { id:'(GMT+09:00) Sapporo' , name: 'Asia/Tokyo' },
        { id:'(GMT+09:00) Seoul' , name: 'Asia/Seoul' },
        { id:'(GMT+09:00) Tokyo' , name: 'Asia/Tokyo' },
        { id:'(GMT+09:30) Adelaide' , name: 'Australia/Adelaide' },
        { id:'(GMT+09:30) Darwin' , name: 'Australia/Darwin' },
        { id:'(GMT+10:00) Brisbane' , name: 'Australia/Brisbane' },
        { id:'(GMT+10:00) Canberra' , name: 'Australia/Canberra' },
        { id:'(GMT+10:00) Guam' , name: 'Pacific/Guam' },
        { id:'(GMT+10:00) Hobart' , name: 'Australia/Hobart' },
        { id:'(GMT+10:00) Melbourne' , name: 'Australia/Melbourne' },
        { id:'(GMT+10:00) Port Moresby' , name: 'Pacific/Port_Moresby' },
        { id:'(GMT+10:00) Sydney' , name: 'Australia/Sydney' },
        { id:'(GMT+10:00) Yakutsk' , name: 'Asia/Yakutsk' },
        { id:'(GMT+11:00) Vladivostok' , name: 'Asia/Vladivostok' },
        { id:'(GMT+12:00) Auckland' , name: 'Pacific/Auckland' },
        { id:'(GMT+12:00) Fiji' , name: 'Pacific/Fiji' },
        { id:'(GMT+12:00) International Date Line West' , name: 'Pacific/Kwajalein' },
        { id:'(GMT+12:00) Kamchatka' , name: 'Asia/Kamchatka' },
        { id:'(GMT+12:00) Magadan' , name: 'Asia/Magadan' },
        { id:'(GMT+12:00) Marshall Is.' , name: 'Pacific/Fiji' },
        { id:'(GMT+12:00) New Caledonia' , name: 'Asia/Magadan' },
        { id:'(GMT+12:00) Solomon Is.' , name: 'Asia/Magadan' },
        { id:'(GMT+12:00) Wellington' , name: 'Pacific/Auckland' },
        { id:'(GMT+13:00) Nuku\'alofa' , name: 'Pacific/Tongatapu'}
    ];
    export default {
        name: "user-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {
            return {
                formAction: "/api/admin/regions",
                redirect: 'Regions',
                model: {
                    name: '',
                    slug: '',
                    upper_lat: '',
                    left_lng: '',
                    bottom_lat: '',
                    right_lng: '',
                    status: 1,
                    station_id: '',
                    location_id: '',
                    frequency: '',
                    height_unit: '',
                    isdst: '',
                    timezone: '',
                    server: '',
                    brand: activeBrand,
                    extra: {
                        default_zoom: '',
                        max_zoom: '',
                        min_zoom: '',
                    },
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Name",
                                    model: "name",
                                    placeholder: "Region Name",
                                    required: true,
                                    styleClasses: ['col-md-7']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Slug",
                                    model: "slug",
                                    placeholder: "Slug",
                                    required: true,
                                    styleClasses: ['col-md-5']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Upper Latitude",
                                    model: "upper_lat",
                                    required: true,
                                    placeholder: "Region's Upper Latitude",
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Bottom Latitude",
                                    model: "bottom_lat",
                                    required: true,
                                    placeholder: "Region's Bottom Latitude",
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Left Longitude",
                                    model: "left_lng",
                                    required: true,
                                    placeholder: "Left Longitude",
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Right Longitude",
                                    model: "right_lng",
                                    required: true,
                                    placeholder: "Region Right Longitude",
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "brand",
                                    label: "Select Brand",
                                    placeholder: "Type to search",
                                    required: true,
                                    styleClasses: ['col-md-3'],
                                    selectOptions: {
                                        key: "slug",
                                        label: "name",
                                    },
                                    values: brands

                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Zoom Min",
                                    model: "extra.min_zoom",
                                    required: true,
                                    // validator: VueFormGenerator.validators.number,
                                    // pattern: '^[1-9][0-9]*$',
                                    placeholder: "Minimum Zoom",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Zoom Max",
                                    model: "extra.max_zoom",
                                    required: true,
                                    // validator: VueFormGenerator.validators.number,
                                    placeholder: "Maximum Zoom",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Zoom Default",
                                    model: "extra.default_zoom",
                                    required: true,
                                    // validator: VueFormGenerator.validators.number,
                                    placeholder: "Default Zoom",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "switch",
                                    label: "Status",
                                    model: "status",
                                    textOn: "Active",
                                    textOff: "Inactive",
                                    styleClasses: ['col-md-3']
                                },

                                {   
                                    type: "switch",
                                    label: "Server",
                                    model: "server",
                                    required: false,
                                    default: true,
                                    textOn: "NOAA",
                                    textOff: "CICESE",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "input",
                                    inputType: 'text',
                                    placeholder: "Station ID",
                                    label: "Station ID ",
                                    model: "station_id",
                                    required: false,
                                    styleClasses: ['col-md-3'],
                                    visible(model) {
                                        return model && model.server;
                                    }
                                },
                                {
                                    type: "select",
                                    label: "Location",
                                    model: "location_id",
                                    styleClasses: ['col-md-3'],
                                    placeholder: "Location",
                                    values:  locationList,
                                    visible(model) {
                                        return model && !model.server;
                                    }
                                },
                                {
                                    type: "select",
                                    label: "Timezone",
                                    model: "timezone",
                                    placeholder: "Timezone",
                                    values:  timezones,
                                    styleClasses: ['col-md-4']
                                },
                                {
                                    type: "switch",
                                    label: "DST",
                                    model: "isdst",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "switch",
                                    label: "Height Unit",
                                    model: "height_unit",
                                    default: true,
                                    textOn: "FT",
                                    textOff: "Meters",
                                    styleClasses: ['col-md-2']
                                },
                                {
                                    type: "input",
                                    inputType: 'number',
                                    label: "Frequency (Days)",
                                    model: "frequency",
                                    placeholder: "Frequency",
                                    required: false,
                                    styleClasses: ['col-md-2'],
                                },

                                {
                                    type: "input",
                                    inputType: "url",
                                    label: "Regions Image",
                                    model: "extra.img",
                                    placeholder: "Regions Image",
                                    // validator: VueFormGenerator.validators.number,
                                    styleClasses: ['col-md-6']
                                },

                            ]
                        }
                    ],
                }
            }
        },
        methods: {
            onModelUpdated(newVal, schema) {
                if(schema == 'name') {
                    this.model.slug = newVal.toString().toLowerCase()
                        .replace(/\s+/g, '-')           // Replace spaces with -
                        .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
                        .replace(/\-\-+/g, '-')         // Replace multiple - with single -
                        .replace(/^-+/, '')             // Trim - from start of text
                        .replace(/-+$/, ''); // Trim - from end of text
                }
            }
        }
    }
</script>