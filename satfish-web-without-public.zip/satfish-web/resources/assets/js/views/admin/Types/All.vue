<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/types"
                editRoute="edit-type"
                createRoute="create-type"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                    {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: '#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'id',
                    },
                    {
                        name: 'name',
                        sortField: 'name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'status',
                        sortField: 'status',
                        callback: 'switch',
                        sortField: 'status',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'parent.name',
                        title: 'Parent',
                        callback: 'renderParent',
                        sortField: 'parent.name',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        sortField: 'created_at',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                           titleClass:'text-center',
                        dataClass: 'text-center'
                    }
                ]
            }
        },
        methods: {
            onCellClicked(){
                alert('asdasd');
            }
        }
    }
</script>