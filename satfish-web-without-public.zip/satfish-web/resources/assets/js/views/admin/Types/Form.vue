    <template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" @model-updated="onModelUpdated" :redirect="redirect"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../core/Form/CreateEditForm";
    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    import fieldAdvanceSelect from "../../../core/Form/AdvanceSelect";

    Vue.component("fieldAdvanceSelect", fieldAdvanceSelect);
    Vue.use(VueFormGenerator);

    export default {
        name: "type-form",
        components: {
            'create-edit-form': CreateEditForm
        },
        data() {
            return {
                formAction: "/api/admin/types",
                redirect: 'Types',
                model: {
                    name: "",
                    slug: "",
                    parent: "",
                    status: 1
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [{
                                type: "input",
                                inputType: "text",
                                label: "Name",
                                model: "name",
                                placeholder: "Type Name",
                                required: true,
                                styleClasses: ['col-md-12']
                            },{
                                type: "input",
                                inputType: "text",
                                label: "Slug",
                                model: "slug",
                                placeholder: "",
                                required: true,
                                styleClasses: ['col-md-4']
                            },{
                                type: "AdvanceSelect",
                                model: "parent",
                                label: "Parent ",
                                placeholder: "Type to search",
                                styleClasses: ['col-md-4'],
                                remoteUrl: '/api/admin/types/children',
                                selectOptions: {
                                    key: "id",
                                    label: "name"
                                },
                                values: []
                            },
                            {
                                type: "switch",
                                label: "Status",
                                model: "status",
                                default: true,
                                textOn: "Active",
                                textOff: "Inactive",
                                styleClasses: ['col-md-4'],
                            }
                            ]
                        }
                    ],
                }
            }
        },
        methods: {
            onModelUpdated(newVal, schema) {
                if(schema == 'name') {
                    this.model.slug = newVal.toString().toLowerCase()
                        .replace(/\s+/g, '-')           // Replace spaces with -
                        .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
                        .replace(/\-\-+/g, '-')         // Replace multiple - with single -
                        .replace(/^-+/, '')             // Trim - from start of text
                        .replace(/-+$/, ''); // Trim - from end of text
                }
            }
        }
    }
</script>

<style>
.custom-control-input {
  position: absolute;
  z-index: 1;
  opacity: 1;
}
</style>