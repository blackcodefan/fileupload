<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/users"
                editRoute="show-user"
                createRoute="create-user"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'
    import loading from 'vue-full-loading'


    // Vue.component('vue-table', VueTable)

    export default {
        components: {
            'loading': loading,
        },
        data () {
            return {
                fields: [
                      {
                        name: '__checkbox',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'id',
                        title: '#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField:'id'
                        // titleClass: 'text-right',
                        // dataClass: 'text-right'
                    },
                    {
                        name: 'person.full_name',
                        title: 'Full Name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'name',
                        title: 'Username',
                        sortField: 'name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'email',
                        sortField: 'email',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    // {
                    //     name: 'person.phone',
                    //     title: 'Phone Number',
                    // },
                    // {
                    //     name: 'person.boat_name',
                    //     title: 'Boat',
                    // },
                    {
                        name: 'brand.name',
                        title: 'Brand',
                        sortField:'brand.name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        sortField: 'created_at',
                        title: 'Created At',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: '__slot:actions',
                        title: 'Actions',
                       titleClass:'text-center',
                        dataClass: 'text-center'
                    }
                ]
            }
        },
        methods: {
            fullname(){
                return this.person.full_name + "  "+ this.person.last_name;
            }
        }
    }
</script>