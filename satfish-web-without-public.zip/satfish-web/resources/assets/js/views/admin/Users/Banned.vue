<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/admin/users/banned"
                editRoute="edit-user"
                showRoute="show-user"
        >
        </vue-table>
    </div>
</template>

<script>

    import Vue from 'vue'
    import VueTable from '../../../core/VueTable/Main'

    Vue.component('vue-table', VueTable)

    export default {
        data () {
            return {
                fields: [
                    {
                        name: 'id',
                        title: '#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField:'id'
                        // titleClass: 'text-right',
                        // dataClass: 'text-right'
                    },
                    // {
                    //     name: '__checkbox',
                    //     titleClass: 'text-center',
                    //     dataClass: 'text-center',
                    // },
                    {
                        name: 'name',
                        sortField: 'name',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'email',
                        sortField: 'email',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        sortField: 'created_at',
                        title: 'Created At',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate|DD-MM-YYYY'
                    },
                ]
            }
        }
    }
</script>