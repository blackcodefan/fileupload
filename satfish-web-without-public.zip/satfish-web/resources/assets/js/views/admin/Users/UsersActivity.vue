<template>
    <div>
        <vue-table
                :fields="activityFields"
                :apiUrl="activityApiUrl"
                :showFilterBar="false"
        >
        </vue-table>
    </div>

</template>

<script>
    import VueTable from '../../../core/VueTable/Main'
    export default {

        name: 'useractivity',
        data(){
            return {
                activityApiUrl: '/api/admin/users-activity',
                activityFields: [
                    {
                        name: 'id',
                        title: '#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        // titleClass: 'text-right',
                        // dataClass: 'text-right'
                    },
                    {
                        name: 'client_ip',
                        title: 'Client IP',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'username',
                        title: 'Username',

                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'email',
                        title: 'Email',

                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'browser_device',
                        title: 'Device',

                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'last_activity',
                        title: 'Last Activity',

                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },

                ],
            }
        }
    }
</script>