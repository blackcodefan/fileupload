<template>
    <div id="dynamic-component" class="btn-tabs">
        <h4>{{ model.name }}</h4>
        <button
                v-for="tab in tabs"
                v-bind:key="tab.component"
                v-bind:class="['tab-button', { active: currentTab === tab.component }]"
                v-on:click="currentTab = tab.component"
        >{{ tab.title }}</button>

        <keep-alive>
            <component
                    v-bind:is="currentTabComponent"
                    class="tab"
            ></component>
        </keep-alive>

    </div>
</template>

<script>
    import VueTable from '../../../core/VueTable/Main';
    import userActivity from './subComponents/userActivity';
    import membership from './tabs/membership';
    import useractions from './subComponents/useractions';
    import editUser  from './Form.vue';
    import userOptions  from './subComponents/userOptions';


    export default {
        name: "user-form",
        components: {
            'useractivity': userActivity,
            'vue-table' :VueTable,
            'useractions': useractions,
            'membership' : membership,
            'editUser' : editUser,
            'userOptions' : userOptions,
        },
        data() {
            return {
                tabs: [
                    {component:'editUser',title:'Edit User'},
                    {component:'useractivity',title:'User Activity'},
                    {component:'membership',title:'Membership'},
                    {component:'useractions',title:'User Actions'},
                    //User Actions
                    {component:'userOptions',title:'User Options'}
                ],
                //currentTab: 'useractivity',
                currentTab:'editUser',
                userId: this.$route.params.id,
                model: {
                    name: 'ement' ,
                }
            }
        },

        computed:  {
            currentTabComponent: function() {
                return this.currentTab;
            }
        },

        beforeMount: function(){
            this.$bus.emit('showLoader');
        },
        mounted: function(){
            var self = this;
            axios.get('api/admin/users/get/'+this.$route.params.id).then(function(response){
                self.model.name = self.model.name + " - " +response.data.name;
            });


            this.$bus.emit('showLoader');
        }


    }
</script>


<style>
    .tab-button {
        padding: 6px 10px;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        border: 1px solid #ccc;
        cursor: pointer;
        background: #f0f0f0;
        margin-bottom: -1px;
        margin-right: -1px;
    }
    .tab-button:hover {
        background: #e0e0e0;
    }
    .tab-button.active {
        background: #e0e0e0;
    }
    .tab {
        border: 1px solid #ccc;
        padding: 10px;
    }

    .btn-tabs .tab-button {
        background: none;
        border: none;
        color: #73818f;
        padding: 10px 20px;
    }

    .btn-tabs .tab-button:hover {
        color: #000;
    }

    .btn-tabs .tab-button.active {
        background: #fff;
        color: #23282c;
        border: 1px solid transparent;
        border-color: #c8ced3 #c8ced3 #fff;
        border-top-left-radius: .25rem;
        border-top-right-radius: .25rem;
    }

    .btn-tabs .tab {
        background: #fff;
    }
</style>

