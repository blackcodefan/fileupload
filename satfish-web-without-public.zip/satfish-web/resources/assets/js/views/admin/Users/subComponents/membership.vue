<template>
    <div>
        <invoice-table />
        <trials-table />
    </div>

</template>

<script>

    import InvoiceTable from "./invoiceTable";
    let stripe, elements, card;
    // Custom styling can be passed to options when creating an Element.
    import General from "../../../../core/Mixins/Alert";
    import Trials from "./trials";
    import Pikaday from 'pikaday';

    import CreateEditForm from "../../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    export default {
        name: 'membership',
        components: {
            InvoiceTable,
            'create-edit-form': CreateEditForm,
            'trials-table': Trials
        },
        mixins: [General],
        data() {
            return {
                showTrialForm: false,
                showRefundForm: false,
                showRefundDetails: false,
                alert: {
                    type: 'success',
                    show: false,
                    msg: '',
                },

                showStripeForm: false,
                showPlan: false,
                subscriptionPlan: '',
                subscriptionAmount: '',
                subscriptionValidity: '',

                stripeFormProcessing: false,
                refunds: {},

                stripeData: {
                    coupon: '',
                    cvc: '',
                    cardnumber: '',
                    exp_month: '',
                    exp_year: '',
                    token: '',
                    plan: '',
                },

                stripePlans: [],
                subscriptions: [],
                trials: [],

                formAction: "/api/admin/trials/add",
                types: [],
                regions: [],
                model: {
                    startDate: '',
                    endDate: '',
                    comments: '',
                    userId: this.$route.params.id
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "fcdatetime",
                                    label: "Start Date",
                                    placeholder: "YYYY-MM-DD",
                                    model: "startDate",
                                    styleClasses: ['col-md-6'],
                                    required: true
                                },
                                {
                                    type: "fcdatetime",
                                    label: "End Date",
                                    placeholder: "YYYY-MM-DD",
                                    model: "endDate",
                                    styleClasses: ['col-md-6'],
                                    required: true
                                },
                                {
                                    type: "textArea",
                                    label: "Coments",
                                    placeholder: "",
                                    model: "comments",
                                    styleClasses: ['col-md-12'],
                                    required: false
                                }
                            ]
                        }
                    ],
                },

                refundFormTitle: 'Refund Invoice',
                formActionRefund: "/api/admin/invoice/refund",
                modelRefund: {
                    amount: '',
                    cancelAction: '',
                    invoiceId: '',
                    userId: '',
                    comments: ''
                },
                schemaRefund: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Amount",
                                    model: "amount",
                                    placeholder: "20.00",
                                    required: true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "select",
                                    label: "Cancel Membership",
                                    model: "cancelAction",
                                    values: [
                                        "Immediately",
                                        "Cancel Auto Billing",
                                        "Do Nothing",
                                    ],
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "textArea",
                                    label: "Coments",
                                    placeholder: "",
                                    model: "comments",
                                    styleClasses: ['col-md-12'],
                                    required: false
                                }
                            ]
                        }
                    ],
                }

            }
        },
        methods: {
            showCurrentPlan: function (plan) {
                if (plan) {
                    this.subscriptionPlan = plan.name;
                    this.subscriptionAmount = plan.amount;
                    this.subscriptionValidity = plan.time;
                    this.showPlan = true;
                    return;
                }
                this.showPlan = false;

            },
            subscriptionStatus: function (status) {
                switch (status) {
                    case 'expired':
                        return 'bg-danger';
                        break;
                    case 'active':
                        return 'bg-green';
                        break;
                    case 'trial':
                        return 'bg-dark';
                        break;
                    default:
                        return 'bg-primary';
                        break;
                }
            },
            trialStatus: function (status) {
                if (status) {
                    return 'bg-green';
                }

                return 'bg-dark';
            },
            cancelTrial: function (trialId) {
                var self = this;
                window.axios.get(`api/admin/trials/` + trialId + '/cancel')
                    .then(response => {
                        self.trials = response.data;
                    })
            },
            trialSuccess: function () {
                this.showTrialForm = false;
                window.axios.get(`api/admin/trials/` + trialId + '/cancel')
                    .then(response => {
                        self.trials = response.data;
                    })
            },
            userSubscriptions: function () {
                var self = this;
                window.axios.get(`api/admin/subscriptions/` + this.$route.params.id)
                    .then(response => {
                        self.subscriptions = response.data;
                    });

                window.axios.get(`api/admin/trials/` + this.$route.params.id + '/get')
                    .then(response => {
                        self.trials = response.data;
                    })
            },
            refundSuccess: function() {
                console.log('REFUND');
                this.showRefundForm = false;
            },
            purchase: function () {

                var self = this;

                self.alert.show = false;
                self.stripeFormProcessing = true; // disable button while processing
                stripe.createToken(card).then(function (result) {
                    self.$bus.emit('showLoader');
                    if (result.error) {
                        self.$bus.emit('showLoader');
                        self.showErrors(result.error.message);
                        self.stripeFormProcessing = false;
                        return;
                    } else {
                        // assigning token
                        self.stripeData.token = result.token.id;
                        axios.post('/api/admin/subscriptions/' + self.$route.params.id, self.stripeData)
                            .then(function (response) {
                                //calling loader off
                                self.$bus.emit('showLoader');
                                // on purchase complete
                                self.showStripeForm = false; // hiding modal
                                self.stripeFormProcessing = false; // enable button again

                                // adding new subscription card
                                self.subscriptions.unshift({
                                    stripe_plan: self.stripeData.plan,
                                    created_at_humanize: 'A moment ago',
                                    status: 'active',
                                    can_cancel_subscription: true,
                                });

                            }).catch(function (error) {
                            self.$bus.emit('showLoader');
                            self.showErrors(error.response.data.errors);
                            self.stripeFormProcessing = false;
                        });

                    }
                });
            },
            getPlans: function () {

                var self = this;

                axios.get('/api/admin/stripe-plans',)
                    .then(function (response) {
                        self.stripePlans = response.data;

                    }).catch(function (error) {
                    console.log(error);
                });
            },
            cancelSubscription: function (planId, index, now) {
                var self = this;
                var subscriptionIndex = index;
                let data = {
                    plan: planId,
                    now: now
                };
                let targetUrl = '/api/admin/subscriptions/' + self.$route.params.id + '/cancel';

                axios.post(targetUrl, data)
                    .then(function (response) {
                        //after cancel subscription
                        // change subscription status to expired
                        // show subsription button again
                        self.subscriptions[subscriptionIndex].status = 'expired';
                        self.subscriptions[subscriptionIndex].can_cancel_subscription = false;
                        self.canAddSubscription = true;

                        self.subscriptions = response.data;
                    })
                    .catch(function (error) {
                        //@TODO: show error that something wrong happend
                    });
            },
            checkAddSubscription: function () {
                var self = this;
                axios.get('/api/admin/subscriptions/' + self.$route.params.id + '/check-subscription')
                    .then(function (response) {
                        // if user already have active subscription then dont show button
                        self.canAddSubscription = true;
                    })
                    .catch(function (error) {
                        self.canAddSubscription = true;
                    });
            },
            formatDate (value, fmt = 'MMM DD, YYYY') {
                value = typeof value === 'object' ? value.date : value;
                return (value == null)
                    ? ''
                    : moment(value).format(fmt)
            }
        },

        beforeMount: function () {

            this.subscriptionStatus();
            this.userSubscriptions();
            this.getPlans();
            this.checkAddSubscription();
            return;
        },

        mounted: function () {

            stripe = Stripe(process.env.MIX_STRIPE_KEY);
            elements = stripe.elements();
            card = undefined;

            //card.mount(this.$refs.card);
            card = elements.create('card');
            card.mount(this.$refs.card);
        },
    }
</script>


<style>
    a.block {
        display: block;
        color: #575757;
        font-weight: 400;
        transition: all .12s ease-out;
    }

    .bg-success {
        background-color: #9ccc65 !important;
    }

    .block-content {
        transition: opacity .2s ease-out;
        margin: 0 auto;
        padding: 18px 18px 1px;
        width: 100%;
        overflow-x: visible;
    }

    .block-content.bg-black-op-5 {
        background-color: rgba(0, 0, 0, .05) !important;
    }

    .block-content .block, .block-content .items-push > div, .block-content .push, .block-content p {
        font-size: 14px;
        color: #fff;
        text-decoration: none !important;
    }

    .font-size-h3.text-white {
        font-size: 1.857143rem;
    }

    a.block:hover {
        opacity: 0.5;
        text-decoration: none;
    }

    .StripeElement {
        background-color: white;
        height: 40px;
        padding: 10px 12px;
        border-radius: 4px;
        border: 1px solid transparent;
        box-shadow: 0 1px 3px 0 #e6ebf1;
        -webkit-transition: box-shadow 150ms ease;
        transition: box-shadow 150ms ease;
    }

    .StripeElement--focus {
        box-shadow: 0 1px 3px 0 #cfd7df;
    }

    .StripeElement--invalid {
        border-color: #fa755a;
    }

    .StripeElement--webkit-autofill {
        background-color: #fefde5 !important;
    }

    .subscription-card {
        width: 30px;
        height: 30px;
        border-radius: 50px;
        font-size: 30px;
        position: relative;
        left: 12px;
        top: -12px;
        color: #fff;
        background: red;
        opacity: 0.8;
        background-color: red !important;
        z-index: 1000;
    }

    #card-element .StripeElement {
        width: 437px;
        border: 1px solid #ccc;
        border-radius: 0px;
        transform: translateX(-16px);
        margin: 7px 0;
        height: auto;
    }

</style>