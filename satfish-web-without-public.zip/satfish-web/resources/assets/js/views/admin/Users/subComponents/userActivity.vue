<template>
    <div>
        <vue-table
                :fields="activityFields"
                :apiUrl="activityApiUrl"
                :showFilterBar="false"
        >
        </vue-table>
    </div>

</template>

<script>

    export default {
        name: 'useractivity',
        data(){
            return {
                activityApiUrl: '/api/admin/user-activity/'+this.$route.params.id,
                activityFields: [
                    {
                        name: 'id',
                        title: '#',
                        titleClass: 'text-right',
                        dataClass: 'text-right'
                    },
                    {
                        name: 'client_ip',
                        title: 'Client IP',
                    },
                    {
                        name: 'browser_device',
                        title: 'Device',
                    },
                    {
                        name: 'last_activity',
                        title: 'Last Activity',
                    },

                ],
            }
        }
    }
</script>