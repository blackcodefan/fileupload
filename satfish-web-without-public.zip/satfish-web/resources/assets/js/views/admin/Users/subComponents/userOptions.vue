<template>
    <create-edit-form :formAction="formAction" :model="model" :schema="schema" redirect="show-user"></create-edit-form>
</template>

<script>
    import CreateEditForm from "../../../../core/Form/CreateEditForm";

    import Vue from 'vue';
    import VueFormGenerator from "vue-form-generator";

    Vue.use(VueFormGenerator);

    export default {
        name: "user-options-form",
        components: {
            'create-edit-form': CreateEditForm,
        },
        data() {

            return {
                formAction: "/api/admin/user-options",
                redirect: "show-user",
                categories: [],
                model: {
                   options: {},
                    person: [],
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "AdvanceSelect",
                                    model: "options.gps_format",
                                    // value: "options.gps_format",
                                    label: "GPS Format",
                                    placeholder: "Select GPS Format",
                                    required: false,
                                    styleClasses: ['col-md-3'],
                                    remoteUrl: '/api/admin/types/children/gps_format_options',
                                    selectOptions: {
                                        key: "id",
                                        label: "name",
                                    },
                                    values: []
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "options.temprature",
                                    value: "options.temprature",
                                    label: "Temprature",
                                    placeholder: "Select temprature",
                                    required: false,
                                    styleClasses: ['col-md-3'],
                                    remoteUrl: '/api/admin/types/children/temprature',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "options.distance",
                                    value: "options.distance",
                                    label: "Distance",
                                    placeholder: "Select Distance",
                                    required: false,
                                    styleClasses: ['col-md-2'],
                                    remoteUrl: '/api/admin/types/children/distance',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "options.height",
                                    label: "Height",
                                    placeholder: "Select Height",
                                    required: false,
                                    styleClasses: ['col-md-2'],
                                    remoteUrl: '/api/admin/types/children/height',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },
                                {
                                    type: "AdvanceSelect",
                                    model: "options.speed",
                                    label: "Speed",
                                    placeholder: "Select Speed",
                                    required: false,
                                    styleClasses: ['col-md-2'],
                                    remoteUrl: '/api/admin/types/children/speed',
                                    selectOptions: {
                                        key: "id",
                                        label: "name"
                                    },
                                    values: []
                                },

                                {
                                    type: "textArea",
                                    label: "Comments (Admin Only)",
                                    model: "person.comments",
                                    max: 500,
                                    required: false,
                                    placeholder: "Enter comments here if any...",
                                    styleClasses: ['col-md-12']
                                },
                            ]
                        }
                    ],
                }
            }
        },
    }
</script>