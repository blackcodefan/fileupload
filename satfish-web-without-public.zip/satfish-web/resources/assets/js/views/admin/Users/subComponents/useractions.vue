<template>
    <div>
        <b-button v-show="showUnban" @click="unban"  class="float-right" size="lg" variant="danger">Unban User</b-button>
        <div>
            <vue-table
                    :fields="fields"
                    :apiUrl="apiUrl"
                    editRoute="edit-user"
                    showRoute="show-user"
            >
            </vue-table>
        </div>


        <b-alert variant="success"
                 dismissible
                 :show="showSuccessAlert"
                 @dismissed="showSuccessAlert=false">
            {{ successMsg }}
        </b-alert>

        <b-form @submit.prevent="onSubmit" class="mt-5" v-show="!showUnban">
            <create-edit-form :formAction="formAction" formMethod="post" v-on:successCallback="successCallback" :model="model" :schema="schema"></create-edit-form>
        </b-form>

    </div>

</template>

<script>
    import CreateEditForm from "../../../../core/Form/CreateEditForm";
    export default {
        name: 'useractivity',
        components: {
            'create-edit-form': CreateEditForm,
        },
        data(){
            return {
                formAction: "/api/admin/users/ban",
                redirect: "show-user",
                showSuccessAlert: false,
                successMsg: '',
                apiUrl: "api/admin/users/ban/"+this.$route.params.id,
                showUnban: false,
                model: {
                    user: "",
                    forhow:"",
                    time: "",
                    comment: "",

                },
                fields: [
                    {
                        name: 'id',
                        title: '#',
                        titleClass: 'text-right',
                        dataClass: 'text-right'
                    },
                    {
                        name: 'comment',
                        sortField: 'comment'
                    },
                    {
                        name: 'expired_at',
                        title: 'Status',
                        callback: this.checkStatus,
                    },
                    {
                        name: 'expired_at',
                        sortField: 'expired_at',
                        title: 'Expired At',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },

                ],
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [{
                                type: "input",
                                inputType: "hidden",
                                model: "user",
                                required: true,
                            },
                                {
                                    type: "textArea",
                                    label: "Reason for banning",
                                    model: "comment",
                                    hint: "Max 500 characters",
                                    max: 500,
                                    required: false,
                                    placeholder: "Enter comments here if any...",
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "select",
                                    label: "For How",
                                    model: "forhow",
                                    values:  function() {
                                        return [
                                            { id: "min", name: "Minutes" },
                                            { id: "hour", name: "Hours" },
                                            { id: "week", name: "Weeks" },
                                            { id: "day", name: "Days" },
                                            { id: "month", name: "Month" },
                                            { id: "year", name: "Year" },
                                            { id: "forever", name: "Forever" },
                                        ]
                                    },
                                    styleClasses: ['col-md-3']
                                },
                                {
                                    type: "input",
                                    inputType: "number",
                                    label: "Time",
                                    model: "time",
                                    required: true,
                                    placeholder:"Enter count ", 
                                    //"Enter number of minutes to ban",
                                    styleClasses: ['col-md-3']
                                }
                            ]
                        }
                    ],
                }
            }
        },
        methods: {
            checkBan: function(){

                axios.get(`api/admin/users/is-banned/`+this.$route.params.id)
                    .then(response => {
                        if(response.data > 0){
                            this.showUnban = true;
                        }

                    })
                    .catch(e => {
                        this.showUnban = false;
                    })
            },

            checkStatus: function(value){

                value = window.moment(value.date);
                let diff = value.diff(moment(), 'minutes');
                if(diff > 0)
                {
                    return '<span class="btn btn-green btn-sm" title="Banned"><i class="fa fa-check"></i></span>';
                }

                return '<span class="btn btn-danger btn-sm" title="Not Banned"><i class="fa fa-times"></i></span>';

            },



            unban: function(){
                axios.post(`api/admin/users/unban/`+this.$route.params.id)
                    .then(response => {
                        this.showUnban = false;
                    })
                    .catch(e => {
                        
                    })
            },
            successCallback: function(){
                this.showUnban = true;
            }



        },
        beforeMount: function() {
            this.checkBan();
            return;
        },
    }
</script>