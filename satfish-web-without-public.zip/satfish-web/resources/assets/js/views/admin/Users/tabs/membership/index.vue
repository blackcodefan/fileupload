<template>
    <div>
        <invoice-table />
        <trial-table />
        <sub-table />
    </div>

</template>

<script>

    import InvoiceTable from "./invoiceTable";
    import TrialTable from "./trialTable";
    // Custom styling can be passed to options when creating an Element.
    import General from "../../../../../core/Mixins/Alert";

    import Vue from 'vue';
    import SubTable from "./subTable";

    export default {
        name: 'membership',
        components: {
            SubTable,
            InvoiceTable,
            TrialTable,
            // 'create-edit-form': CreateEditForm,
        },
        mixins: [General],
        data() {
            return {
            }
        },
        methods: {

            checkAddSubscription: function () {
                var self = this;
                axios.get('/api/admin/subscriptions/' + self.$route.params.id + '/check-subscription')
                    .then(function (response) {
                        // if user already have active subscription then dont show button
                        self.canAddSubscription = true;
                    })
                    .catch(function (error) {
                        self.canAddSubscription = true;
                    });
            },
            formatDate (value, fmt = 'DD-MM-YY HH:mm') {
                value = typeof value === 'object' ? value.date : value;
                return (value == null)
                    ? ''
                    : moment(value).format(fmt)
            }
        }
    }
</script>


<style>
    a.block {
        display: block;
        color: #575757;
        font-weight: 400;
        transition: all .12s ease-out;
    }

    .bg-success {
        background-color: #9ccc65 !important;
    }

    .block-content {
        transition: opacity .2s ease-out;
        margin: 0 auto;
        padding: 18px 18px 1px;
        width: 100%;
        overflow-x: visible;
    }

    .block-content.bg-black-op-5 {
        background-color: rgba(0, 0, 0, .05) !important;
    }

    .block-content .block, .block-content .items-push > div, .block-content .push, .block-content p {
        font-size: 14px;
        color: #fff;
        text-decoration: none !important;
    }

    .font-size-h3.text-white {
        font-size: 1.857143rem;
    }

    a.block:hover {
        opacity: 0.5;
        text-decoration: none;
    }

</style>