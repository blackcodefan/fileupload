<template>
    <div>

        <div class="flex-row-reverse">
            <button class="btn btn-warning float-right mb-2" title="Add Trial" @click="showTrialForm = true"
                    v-if="canAddSubscription" v-b-modal.trialForm><i class="fa fa-plus"></i>
                <span>Add Trial</span>
            </button>
            <button class="btn btn-success float-right mb-2" title="Add Subscription" @click="stripeForm" 
            v-if="canAddSubscription"  v-b-modal.stripeForm      
            ><i class="fa fa-plus"></i>
                <span>Add Subscription </span>
            </button>
        </div>

        <h4>Invoices</h4>
        <vue-table
                :fields="fields"
                :apiUrl="apiUrl"
                :buttons="buttons"
                @refundInvoice="refundInvoice"
                @refundDetails="refundDetails"
                :showFilterBar="false"    
        >
         <!-- <template>
                     <button class="btn btn-warning btn-sm" title="Refund Invoice" @click="refundInvoice"><i class="fa fa-undo"></i></button>
            </template> -->
        <!-- customPagination="true" -->
        </vue-table>

        <stripe-form ref="form" :showForm="showStripeForm"/>
        <!-- postUrl="api/billing/renew"  i have added it from the other file-->
        <trial-form :showForm="showTrialForm" />

        <refund-form :refundFormData="refundFormData" />

        <refund-details :refundId="refundId" />
    </div>
</template>

<script>
    import StripeForm from "../../../../../home-components/stripeForm";
    import RefundForm from "./refundForm";
    import RefundDetails from "./refundDetails";
    import TrialForm from "./trialForm";

    export default {
        name: "invoiceTable",
        components: {TrialForm, RefundDetails, RefundForm, StripeForm},
        data() {
            return {
                canAddSubscription: true,
                showTrialForm: false,
                showStripeForm: false,
                stripePostUrl: '/api/admin/subscriptions/' + this.$route.params.id,
                apiUrl: '/api/admin/invoices/' + this.$route.params.id,
                fields: [
                    {
                        name: 'number',
                        title: 'Invoice #',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'subscription.plan.name',
                        title: 'Plan',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'subscription',
                        title: 'Total',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: this.stripeAmount,
                    },
                    {
                        name: 'date',
                        title: 'Created At',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: this.formatDate,
                    },
                    {
                        name: 'status',
                        title: 'Status',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        sortField: 'status',
                        callback: this.subStatus
                    },
                    {
                        name:'__slot:customActions',
                        title:'Actions',
                      //  titleClass: 'center aligned',
                      //  dataClass: 'center aligned'
                     titleClass: 'text-center',
                        dataClass: 'text-center',
                   }
                ],
                buttons: [
                    {
                        icon:'fa fa-undo',
                        title:'Refund Invoice',
                        callback: 'refundInvoice',
                        className: 'btn-warning'
                    },
                    {
                        icon:'fa fa-info',
                        title:'Refund Details',
                        callback: 'refundDetails',
                        className: 'btn-secondary'
                    },
                ],
                refundFormData: {
                    showForm: false,
                    refundFormTitle: '',
                    model: {
                        amount: '',
                        cancelAction: '',
                        invoiceId: '',
                        userId: '',
                        comments: ''
                    }
                },
                refundId: null
            }
        },
        methods: {
            refundInvoice: function(invoiceId) {

                this.refundFormData.showForm = !this.refundFormData.showForm; 
                this.refundFormData.refundFormTitle = 'Refund # ' + invoiceId;
                this.refundFormData.model.invoiceId = invoiceId;
                this.refundFormData.model.userId = this.$route.params.id;
                //this.refundFormData.showForm = !this.refundFormData.showForm;
                //true;
            },
            refundDetails: function(id) {
                this.refundId = id;
                
            },
            stripeForm: function() {
                this.$refs.form.openForm();
                this.showStripeForm = true;
            },

            stripeAmount: function(value){

                let sign = '';
                if(value.currency == 'usd')
                {
                    sign = '$';
                }
                return  sign + Math.ceil(value.amount/100);
            },


            subStatus: function(value) {
                switch (value) {
                    case 'cancel':
                    case 'incomplete_expired':
                        return '<span class="btn btn-danger btn-sm" title=' +  this.uCfirst(value)  +'><i class="fa fa-times"></i></span>';
                        break;
                    case 'active':
                    case 'paid':
                        return '<span class="btn btn-green btn-sm" title=' +  this.uCfirst(value)  +'><i class="fa fa-check"></i></span>';
                        break;
                    case 'incomplete':
                        return '<span class="btn btn-dark btn-sm" title=' + this.uCfirst(value)  +'><i class="fa fa-flask"></i></span>';
                        break;
                    case 'past_due':
                    case 'unpaid':
                    case 'expired':
                        return '<span class="btn btn-dark btn-sm" title=' +  this.uCfirst(value)  +'><i class="fa fa-history"></i></span>';
                        break;
                    default:
                        return '<span class="btn btn-primary btn-sm" title=' +  this.uCfirst(value)  +'><i class="fa fa-times"></i></span>';
                        break;
                }
            },
            uCfirst: function(string)
            {

                return string.charAt(0).toUpperCase() + string.slice(1);

            },
            formatDate (value, fmt = 'MMM DD, YYYY') {

                return moment.unix(value).format(fmt);
            }
        }
    }
</script>