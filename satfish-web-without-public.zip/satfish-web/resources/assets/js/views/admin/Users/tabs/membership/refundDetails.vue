<template>
    <b-modal v-show="showCard" hide-footer v-model="showRefundDetails" title="Refund Details">
        <b-card v-show="showCard" :header="refund.refund_id" v-for="refund in refunds" :key="refund.id">
            <dl>
                <dt>Invoice # </dt>
                <dd>{{ refund.invoice_id }}</dd>

                <dt>Date</dt>
                <dd>{{ formatDate(refund.created_at) }}</dd>

                <dt>Amount </dt>
                <dd>{{ refund.amount }}</dd>

                <dt>Comments </dt>
                <dd>{{ refund.comments }}</dd>
            </dl>
        </b-card>
    </b-modal>
</template>

<script>
    export default {
        name: "refundDetails",
        showCard:false,
        props: ['refundId'],
        data() {
            return {
                showRefundDetails: false,
                refunds: {},
                id: 0
            }
        },
        methods: {
            refundDetails: function(id) {
                let self = this;
                window.axios.get(`api/admin/invoice/refunds/` + id)
                    .then(response => {
                        if(response.data.length > 0){  
                            self.showCard=true
                            self.refunds = response.data;
                            self.showRefundDetails = true;
                        } else {
                            self.showCard=false
                            alert('No Refund Details');
                        }
                    })
            },
            formatDate(value, fmt = 'DD-MM-YY HH:mm') {
                value = typeof value === 'object' ? value.date : value; 
                return (value == null)
                    ? ''
                    : moment(value).format(fmt)
            }
        },
        watch: {
            refundId(value) {
                this.showRefundDetails = true;
                this.refundDetails(value);
            }
        }
    }
</script>

<style scoped>

</style>