<template>
    <b-modal hide-footer v-model="showRefundForm" :title="refundFormTitle">

        <b-alert :show="alert.show" :variant="alert.type"><span v-html="alert.msg"></span></b-alert>
        <create-edit-form :formAction="formActionRefund" :model="model" :schema="schema"
                          :disableEditCase="true" v-on:successCallback="refundSuccess"></create-edit-form>

    </b-modal>
</template>

<script>
    import CreateEditForm from "../../../../../core/Form/CreateEditForm";
    export default {
        name: "refundForm",
        components: {CreateEditForm},
        props: ['refundFormData'],
        data() {
            return {
                showRefundForm: false,
                refundFormTitle: 'Refund Invoice',
                formActionRefund: "/api/admin/invoice/refund",
                alert: {
                    type: 'success',
                    show: false,
                    msg: '',
                },
                model: {},
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Amount",
                                    model: "amount",
                                    placeholder: "20.00",
                                    required: true,
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "select",
                                    label: "Cancel Membership",
                                    model: "cancelAction",
                                    values: [
                                        "Immediately",
                                        "Cancel Auto Billing",
                                        "Do Nothing",
                                    ],
                                    styleClasses: ['col-md-6']
                                },
                                {
                                    type: "textArea",
                                    label: "Comments",
                                    placeholder: "",
                                    model: "comments",
                                    styleClasses: ['col-md-12'],
                                    required: false
                                }
                            ]
                        }
                    ],
                }
            }
        },
        methods: {
            refundSuccess: function() {
                this.showRefundForm = false;
            },
        },
        watch: {
            'refundFormData.showForm'(value) {
                this.showRefundForm = this.refundFormData.showForm;
                this.model = this.refundFormData.model;
                this.refundFormTitle = this.refundFormData.refundFormTitle;
            }
        }
    }
</script>