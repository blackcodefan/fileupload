<template>
    <b-modal hide-footer v-model="showStripeForm" title="User Subscription" id="stripeForm">

        <b-alert :show="alert.show" :variant="alert.type"><span v-html="alert.msg"></span></b-alert>
        <b-container fluid>
            <b-form ref="form">
                <b-row>
                    <label>Select Plan:</label>
                    <b-form-select v-model="stripeData.plan">
                        <option @click="showCurrentPlan(plan)" v-for="plan in stripePlans"  :value="plan.id" >
                            {{plan.name}}
                        </option>
                    </b-form-select>
                </b-row>

                <b-row>
                    <div class="col-12 py-2" v-show="showPlan">
                        <a class="block block-transparent text-center  bg-success" href="javascript:void(0)">
                            <div class="block-content bg-black-op-5">
                                <p class="font-w600 text-white">{{subscriptionPlan}}</p>
                            </div>
                            <div class="block-content">
                                <p class="font-size-h3 text-white">
                                    <strong>${{subscriptionAmount/100}}</strong>
                                </p>
                            </div>
                            <div class="block-content bg-black-op-5">
                                <p class="font-w600 text-white-op">{{subscriptionValidity}}</p>
                            </div>
                        </a>
                    </div>
                </b-row>

                <b-row class="mt-2">
                    <input type="text" placeholder="Enter Coupon if any.." v-model="stripeData.coupon"
                           class="form-control">
                </b-row>



                <div id="card-element" class="mt-2">
                    <div ref="card"></div>
                    <input type="hidden" v-model="stripeData.token">
                    <b-row class="pt-2">
                        <b-button type="submit" v-on:click="purchase" :disabled="stripeFormProcessing"
                                  variant="primary">Submit
                        </b-button>
                    </b-row>
                    <!-- A Stripe Element will be inserted here. -->
                </div>



            </b-form>

        </b-container>

    </b-modal>
</template>

<script>
    let stripe, elements, card;
    export default {
        name: "stripeForm",
        props: ['showForm'],
        data() {
            return {
                showStripeForm: false,
                terms: false,
                alert: {
                    type: 'success',
                    show: false,
                    msg: '',
                },
                stripeData: {
                    coupon: '',
                    cvc: '',
                    cardnumber: '',
                    exp_month: '',
                    exp_year: '',
                    token: '',
                    plan: '',

                },
                stripePlans: [],
                showPlan: false,
                subscriptionPlan: '',
                subscriptionAmount: '',
                subscriptionValidity: '',
                stripeFormProcessing: false,
            }
        },
        methods: {
            purchase: function () {

                var self = this;

                self.alert.show = false;
                self.stripeFormProcessing = true; // disable button while processing
                stripe.createToken(card).then(function (result) {
                    self.$bus.emit('showLoader');
                    console.log(result)
                    if (result.error) {
                        self.$bus.emit('showLoader');
                        self.showErrors(result.error.message.plan);
                        console.log(result.error.message)
                        self.stripeFormProcessing = false;
                        return;
                    } else {
                        // assigning token
                        self.stripeData.token = result.token.id;
                        axios.post('/api/admin/subscriptions/' + self.$route.params.id, self.stripeData)
                            .then(function (response) {
                                //calling loader off
                                self.$bus.emit('showLoader');
                                // on purchase complete
                                self.showStripeForm = false; // hiding modal
                                self.stripeFormProcessing = false; // enable button again

                                // adding new subscription card
                                self.subscriptions.unshift({
                                    stripe_plan: self.stripeData.plan,
                                    created_at_humanize: 'A moment ago',
                                    status: 'active',
                                    can_cancel_subscription: true,
                                });

                            }).catch(function (error) {

                            self.$bus.emit('showLoader');
                            self.showErrors(error.response.data);
                            self.stripeFormProcessing = false;
                        });

                    }
                });
            },
            getPlans: function () {
                let self = this;
                window.axios.get('/api/admin/stripe-plans')
                    .then(function (response) {
                        self.stripePlans = response.data;

                    }).catch(function (error) {
                    console.log(error);
                });
            },
            showCurrentPlan: function (plan) {
                if (plan) {
                    this.subscriptionPlan = plan.name;
                    this.subscriptionAmount = plan.amount;
                    this.subscriptionValidity = plan.time;
                    this.showPlan = true;
                    return;
                }
                this.showPlan = false;

            }
        },
        mounted: function () {
            // stripe = Stripe(process.env.MIX_STRIPE_KEY);
            // elements = stripe.elements();
            // card = undefined;
            //
            // //card.mount(this.$refs.card);
            // card = elements.create('card');
            // card.mount(this.$refs.card);
        },
        beforeMount: function () {
            this.getPlans();
            console.log('now mounting :)')
            return true;
        },
        watch: {
            showForm(value) {
                this.showStripeForm = value;
            }
        }
    }
</script>

<style scoped>

    #card-element .StripeElement {
        width: 437px;
        border: 1px solid #ccc;
        border-radius: 0px;
        transform: translateX(-16px);
        margin: 7px 0;
        height: auto;
    }


    .StripeElement {
        background-color: white;
        height: 40px;
        padding: 10px 12px;
        border-radius: 4px;
        border: 1px solid transparent;
        box-shadow: 0 1px 3px 0 #e6ebf1;
        -webkit-transition: box-shadow 150ms ease;
        transition: box-shadow 150ms ease;
    }

    .StripeElement--focus {
        box-shadow: 0 1px 3px 0 #cfd7df;
    }

    .StripeElement--invalid {
        border-color: #fa755a;
    }

    .StripeElement--webkit-autofill {
        background-color: #fefde5 !important;
    }

</style>