<template>
    <div>
        <h4>Subscription</h4>
        <vue-table
                :fields="fields"
                :apiUrl="apiUrl"
                :buttons="buttons"
                @cancelRenewel="cancelRenewel"
                @cancelAccount="cancelAccount"
                :showFilterBar="false">
        </vue-table>
    </div>
</template>

<script>


    export default {
        name: "subTable",
        components: {},
        data() {
            return {
                apiUrl: `api/admin/subscriptions/` +  this.$route.params.id,
                fields: [
                    {
                        name: 'id',
                        title: '#',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'stripe_plan',
                        title: 'Plan',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name: 'created_at',
                        title: 'From',
                        sortField: 'created_at',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: 'ends_at',
                        title: 'Auto Renewal',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: this.autoRenewal,
                    },
                    {
                        name: 'status',
                        title: 'Status',
                        sortField: 'status',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: this.subStatus
                    },
                    {
                        name: 'on_grace',
                        title: 'Grace Period',
                        sortField: 'on_grace',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'switch',
                    },
                    {
                        name:'__slot:customActions',
                        title:'Actions',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                      //  titleClass: 'center aligned',
                      //  dataClass: 'center aligned'
                    }
                ],
                buttons: [
                    {
                        icon:'fa fa-calendar',
                        title:'Cancel Renewel',
                        callback: 'cancelRenewel',
                        className: 'btn-warning'
                    },
                    {
                        icon:'fa fa-ban',
                        title:'Cancel Account',
                        callback: 'cancelAccount',
                        className: 'btn-danger'
                    },
                ]
            }
        },
        methods: {
            cancelRenewel: function(subId, subData) {
                this.cancelSubscription(subData);
            },
            cancelAccount: function(subId, subData) {
                this.cancelSubscription(subData, true);
            },
            cancelSubscription: function (subData, now) {
                let self = this;
                let data = {
                    sub_id: subData.id,
                    now: now
                };
                let targetUrl = '/api/admin/subscriptions/' + self.$route.params.id + '/cancel';
                ////subscriptions/{user}/cancel
                window.axios.post(targetUrl, data)
                    .then(function (response) {
                        console.log(response) 
                        console.log('success')
                        //Subscription Action performed successfully
                    })
                    .catch(function (error) {
                        console.log(error.response)
                        //@TODO: show error that something wrong happend
                    });
            },
            autoRenewal: function(value){

                if(!value)
                {
                    return '<span class="btn btn-green btn-sm" title="On"><i class="fa fa-check"></i></span>'
                }

                return '<span class="btn btn-danger btn-sm" title="Off"><i class="fa fa-times"></i></span>';

            },

            subStatus: function(value) {
                switch (value) {
                    case 'expired':
                        return '<span class="btn btn-danger btn-sm" title="Expired"><i class="fa fa-times"></i></span>';
                        break;
                    case 'active':
                        return '<span class="btn btn-green btn-sm" title="Active"><i class="fa fa-check"></i></span>';
                        break;
                    case 'trial':
                        return '<span class="btn btn-dark btn-sm" title="Trial"><i class="fa fa-flask"></i></span>';
                        break;
                    default:
                        return '<span class="btn btn-primary btn-sm" title="Unkown"><i class="fa fa-times"></i></span>';
                        break;
                }
            }

        }
    }
</script>