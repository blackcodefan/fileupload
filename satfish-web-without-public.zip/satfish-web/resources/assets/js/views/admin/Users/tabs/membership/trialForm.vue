<template>
    <b-modal hide-footer v-model="showTrialForm" id="trialForm" title="User Trial"  @hidden="resetModal">

        <b-alert :show="alert.show" :variant="alert.type"><span v-html="alert.msg"></span></b-alert>
        <create-edit-form 
        :formAction="formAction" :model="model" :schema="schema"
        :disableEditCase="true" v-on:successCallback="trialSuccess">
        </create-edit-form>
    </b-modal>
</template>

<script>
    import CreateEditForm from "../../../../../core/Form/CreateEditForm";
    export default {
        name: "trialForm",
        props: ['showForm'],
        components: {CreateEditForm},
        data() {
            return {
                showTrialForm: false,
                alert: {
                    type: 'success',
                    show: false,
                    msg: '',
                },
                formAction: "/api/admin/trials/add",
                model: {
                    startDate: '',
                    endDate: '',
                    comments: '',
                    userId: this.$route.params.id
                },
                schema: {
                    groups: [
                        {
                            styleClasses: ['row'],
                            fields: [
                                {
                                    type: "fcdatetime",
                                    label: "Start Date",
                                    placeholder: "YYYY-MM-DD",
                                    model: "startDate",
                                    styleClasses: ['col-md-6'],
                                    required: true
                                },
                                {
                                    type: "fcdatetime",
                                    label: "End Date",
                                    placeholder: "YYYY-MM-DD",
                                    model: "endDate",
                                    styleClasses: ['col-md-6'],
                                    required: true
                                },
                                {
                                    type: "textArea",
                                    label: "Comments",
                                    placeholder: "",
                                    model: "comments",
                                    styleClasses: ['col-md-12'],
                                    required: false
                                }
                            ]
                        }
                    ],
                },
            }
        },
        methods: {
            trialSuccess: function (trialId) {
                this.showTrialForm = false;
                window.axios.get(`api/admin/trials/` + trialId + '/cancel')
                    .then(response => {
                        console.log(response)
                        self.trials = response.data;
                    }).catch(error=>{
                        console.log(error.response)
                    })
            }
            ,

            resetModal: function() {
               return this.model = {
                    startDate: '',
                        endDate: '',
                    comments: '',
                    userId: this.$route.params.id
                };
            }
        },
        watch: {
            showForm(value) {
                this.showTrialForm = value;
            }
        }
    }
</script>

<style scoped>

</style>