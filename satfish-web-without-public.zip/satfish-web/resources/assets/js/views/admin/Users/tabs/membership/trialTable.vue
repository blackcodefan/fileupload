<template>
    <div>
        <h4>Trials</h4>
        <vue-table
                :fields="fields"
                :apiUrl="apiUrl"
                :buttons="buttons"
                @cancelTrialNow="cancelTrialNow"
                :showFilterBar="false"
        >
        </vue-table>
    </div>
</template>

<script>
    export default {
        name: "trialTable",
        data () {
            return {
                apiUrl: "api/admin/trials/" + this.$route.params.id,
                fields: [
                    {
                        name: 'id',
                        title: '#',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        // titleClass: 'text-right',
                        // dataClass: 'text-right'
                    },
                    {
                        name: 'valid_from',
                        sortField: 'valid_from',
                        title: 'Valid From',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: 'valid_to',
                        sortField: 'valid_to',
                        title: 'Valid To',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: 'status',
                        title: 'Status',
                        sortField: 'status',
                        callback: 'switch',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                    },
                    {
                        name:'__slot:customActions',
                        title:'Actions',
                          titleClass: 'text-center',
                        dataClass: 'text-center',
                        // titleClass: 'center aligned',
                        // dataClass: 'center aligned'
                    }
                ],
                buttons: [
                    {
                        icon:'fa fa-times',
                        callback: 'cancelTrialNow',
                        className: 'btn-danger'
                    }
                ]
            }
        },
        methods: {
            cancelTrialNow: function(trialId) {
                let self = this;
                window.axios.get(`api/admin/trials/` + trialId + '/cancel')
                    .then(response => {
                        self.trials = response.data;
                    })
            }
        }
    }
</script>
