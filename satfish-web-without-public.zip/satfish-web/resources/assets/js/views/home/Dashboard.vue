<template>
    <div>
        <b-card v-if="!loadingContent" v-for="report in fishReports" :report="report" :key="report.id">
            <h5>{{ report.title.rendered }}</h5>
            <hr/>
            <span v-html="report.content.rendered"></span>
        </b-card>
        <div class="sk-double-bounce" v-if="loadingContent">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
        <b-pagination align="center" :total-rows="100" v-model="currentPage" :per-page="10">
        </b-pagination>
    </div>

</template>

<script>

    export
     default {
        name: 'dashboard',
        components: {},
        data: function () {
            return {
                currentPage: 1,
                fishReports: {},
                loadingContent: true
            }
        },
        methods: {
            getFishReports: function(pageNum){
                this.loadingContent = true;
                let targetUrl = 'https://www.fishdope.com/wp-json/wp/v2/posts?categories=11';
                if(pageNum) {
                    targetUrl += '&page=' + pageNum;
                }

                window.axios.get(targetUrl)
                    .then(response => {
                        this.fishReports = response.data;
                        this.loadingContent = false;
                        window.scrollTo(0, 0);
                    })
                    .catch(e => {
                        // fishReports = {}
                    })
            }
        },
        watch: {
            currentPage: function(val, oldVal) {
                this.getFishReports(val);
            }
        },
         beforeMount() {
            var self = this;
            console.log('before mount')
            self.$bus.emit('OnLoader')

        },
        mounted() {
            console.log('mounted now')
            self.bus.emit('OffLoader')
        }
    }
</script>


