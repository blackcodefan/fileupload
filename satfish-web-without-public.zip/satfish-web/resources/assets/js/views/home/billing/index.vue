<template>
    <div>
        <vue-table
                :fields="fields"
                apiUrl="api/billing/invoices"
                :showFilterBar="false"
        >
        </vue-table>
    </div>
</template>

<script>
    import Vue from 'vue';
    import VueTable from '../../../core/VueTable/Main';

    Vue.component('vue-table', VueTable);

    export default {
        name: "invoices",
        components: {},
        data: function () {
            return {
                invoices: false,
                loadingContent: true,
                fields: [
                    {
                        name: 'number',
                        title: '#',
                        sortField: 'id',
                    },
                    {
                        name: 'subscription.plan.name',
                        title: 'Plan',
                        sortField: 'plan.name',
                    },
                    {
                        name: 'amount_paid',
                        title: 'Amount',
                        sortField: 'amount_paid',
                        callback: 'formatStripeMoney'
                    },
                    {
                        name: 'date',
                        title: 'Date',
                        sortField: 'date',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: 'formatDate'
                    },
                    {
                        name: 'status',
                        title: 'Status',
                        sortField: 'status',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: this.invoiceStatus
                    },
                    {
                        name: 'invoice_pdf',
                        title: 'Download',
                        titleClass: 'text-center',
                        dataClass: 'text-center',
                        callback: this.invoicePdf
                    }
                ]
            }
        },
        methods: {
            setStatus: function(status) {
                switch(status) {
                    case 'draft':
                        return 'secondary'
                        break;

                    case 'open' :
                        return 'primary'
                        break;

                    case 'paid' :
                        return 'success'
                        break;

                    case 'uncollectible' :
                        return 'danger'
                        break;

                    case 'void' :
                        return 'secondary'
                        break;

                    default :
                        return 'secondary'
                        break;
                }
            },
            invoicePdf: function(value) {
                return '<a href="' + value + '" class="btn btn-sm bg-primary" download><i class="fa fa-download"></i></a>'
            },
            invoiceStatus: function(value) {
                let color = this.setStatus(value);
                return '<span class="badge badge-' + color + '">' + value + '</span>'
            }
        }
    }
</script>