<template>
    <div>
        <b-row>
            <b-col sm="6" md="4" lg="3" v-for="region in regions" :key="region.id">
                <div @click="loadRegion(region.id)" class="region-card">
                    <img v-if="region.extra.img" :src="region.extra.img" />
                    <h5>{{ region.name }}</h5>
                </div>
            </b-col>
        </b-row><!--/.row-->
        <div class="sk-double-bounce" v-if="loadingContent">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'regions',
        data: function () {
            return {
                regions: 1,
                loadingContent: true
            }
        },
        methods: {
            getRegions: function(pageNum){
                this.loadingContent = true;
                let targetUrl = 'api/billing/regions';
                window.axios.get(targetUrl)
                    .then(response => {
                        this.regions = response.data;
                       this.loadingContent = false;
                    })
                    .catch(e => {
                this.loadingContent = true;
                        console.log('nothing')
                        // fishReports = {}
                    })
            },
            loadRegion: function(id) {
                window.location.href = "/regions/" + id;
            }
        },
        mounted: function () {
            this.getRegions();
        }
    }
</script>
